<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

class Profile extends BaseController {

	public function __construct()
    {
        parent::__construct();
		
        date_default_timezone_set('asia/kolkata');  
		$this->load->model('Profile_model');
		$this->load->helper('url', 'form');
        
    }
	 public function index()
	{
		
		$this->load->library('form_validation');
        $this->load->library('session');
		
		if (!$this->session->userdata('u_id')){
            redirect('login');
            
        }
        else{
            
            $this->load->view('profile');

        }



	}

	public function logout()
    {
         
        session_destroy();
        redirect('login');

    }

	public function register(){

		$update = $this->input->post('id');
		$name = $this->input->post('name');
		$fathername = $this->input->post('fathername');
		$mothername = $this->input->post('mothername');
		$nickname = $this->input->post('nickname');
		
		$street = $this->input->post('street');
		
		$area = $this->input->post('area');
		$city = $this->input->post('city');
		$birth = $this->input->post('birth');
		$state = $this->input->post('state');
		$landmark = $this->input->post('landmark');
		$pcode = $this->input->post('pcode');		
		
		$age = $this->input->post('age');
		$date = date('Y-m-d', strtotime($age));
		
		$number = $this->security->xss_clean($this->input->post('phone'));
		$a_number = $this->security->xss_clean($this->input->post('anumber'));
		
		if(empty($update)){
			
			$profileInfo = array('name'=>$name,'fathername'=>$fathername,'mothername'=>$mothername, 'nickname'=>$nickname,'age'=>$age,'number'=>$number,'a_number'=>$a_number, 'created_date'=>date('Y-m-d H:i:s'));
			$profileId = $this->Profile_model->addNewProfile($profileInfo);

			$basePath = "uploads/".$profileId;
			$imagePath = "uploads/".$profileId."/images";
			$audioPath = "uploads/".$profileId."/audio";
			$videoPath = "uploads/".$profileId."/video";
			$docPath = "uploads/".$profileId."/documents";
			$profilePath = "uploads/".$profileId."/profile";

			if (!file_exists($basePath)) {
				mkdir($basePath, 0777, true);
			}
			if (!file_exists($imagePath)) {
				mkdir($imagePath, 0777, true);
			}
			if (!file_exists($audioPath)) {
				mkdir($audioPath, 0777, true);
			}
			if (!file_exists($videoPath)) {
				mkdir($videoPath, 0777, true);
			}
			if (!file_exists($docPath)) {
				mkdir($docPath, 0777, true);
			}
			if (!file_exists($profilePath)) {
				mkdir($profilePath, 0777, true);
			}

		}

		else{
			
			$profilePath = "uploads/".$update."/profile";

			$profileInfo = array('name'=>$name,'fathername'=>$fathername,'mothername'=>$mothername, 'nickname'=>$nickname,'age'=>$age,'number'=>$number,'a_number'=>$a_number, 'updated_date'=>date('Y-m-d H:i:s'));
			$profileId = $this->Profile_model->updateProfile($profileInfo, $update);
	
		}
		

		$fileTmpPath = $_FILES['imageUpload']['tmp_name'];
		$fileName = $_FILES['imageUpload']['name'];
		$fileSize = $_FILES['imageUpload']['size'];
		$fileType = $_FILES['imageUpload']['type'];
		$fileNameCmps = explode(".", $fileName);
		$fileExtension = strtolower(end($fileNameCmps));
		$newFileName = md5(time() . $fileName) . '.' . $fileExtension;

		$config['upload_path'] = $profilePath;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 2000;
		$config['file_name'] = $newFileName;

        $this->load->library('upload', $config);


        if ($this->upload->do_upload('imageUpload')) {
			
		   $data = array('image_metadata' => $this->upload->data());
			
			if(empty($update)){
				$imageInfo = array('id'=> $profileId, 'image_name' => $newFileName);
				$result = $this->Profile_model->updateImageInfo($imageInfo, $profileId);
			}
			else{
				$imageInfo = array('id'=> $update, 'image_name' => $newFileName);
				$result = $this->Profile_model->updateImageInfo($imageInfo, $update);
			}

			
        }
		
		if(empty($update)){
			
			$contactInfo = array('birth'=>$birth,'street'=>$street,'landmark'=>$landmark, 'area'=>$area,'city'=>$city,'state'=>$state,'pcode'=>$pcode,'profile_id'=>$profileId);
        	
			$result = $this->Profile_model->addContactInfo($contactInfo);
			
			
			if($result == TRUE){
				
           		redirect('addProfile/'.$profileId);
			}
		}
		else{
			
			$sql = "SELECT id FROM profile_address where profile_id	= '".$update."'" ;
			$query = $this->db->query($sql);
			$user = $query->row();
					
			$contactId = $user->id;

			$contactInfo = array('birth'=>$birth,'street'=>$street,'landmark'=>$landmark, 'area'=>$area,'city'=>$city,'state'=>$state,'pcode'=>$pcode);
        	
			$result = $this->Profile_model->updateContact($contactInfo, $contactId);
			
			
			if($result == TRUE){
				
				//$data['contact'] = $this->Profile_model->Contact($contactInfo, $contactId);
           		redirect('addProfile/'.$profileId);
			}
		}


		//redirect('profile');
    
	}

	public function editProfile($profileId = NULL){

		
	}

	public function addProfile($profileId = NULL){

		$data['id'] = $profileId;
		$this->load->view('addProfile', $data);
	}


	public function uploadImage() {  

		//$id = $this->input->post('id');
		$id = 5;
		$vdetails = $this->input->post('vdetails');
		$pdetails = $this->input->post('pdetails');
		$plocation = $this->input->post('plocation');
		$linkwith = $this->input->post('linkwith');

		if(empty($vdetails) && empty($pdetails) && empty($plocation) && empty($linkwith))
		{

		}
		else{
			$otherInfo = array('vehicle_no'=>$vdetails, 'property_details'=>$pdetails,'property_location'=>$plocation,'	linkwith'=>$linkwith, 'profile_id'=>$id, 'created_date'=>date('Y-m-d H:i:s'));
			$result = $this->Profile_model->otherRecords($otherInfo);
		}
			
		
		
		$imagePath = "uploads/".$id."/images";
		$videoPath = "uploads/".$id."/video";	
		$audioPath = "uploads/".$id."/audio";				
     	$data = [];  
     
      $count = count($_FILES['files']['name']);  
      
      for($i=0;$i<$count;$i++){  
      
        if(!empty($_FILES['files']['name'][$i])){  
      
          $_FILES['file']['name'] = $_FILES['files']['name'][$i];  
          $_FILES['file']['type'] = $_FILES['files']['type'][$i];  
          $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];  
          $_FILES['file']['error'] = $_FILES['files']['error'][$i];  
          $_FILES['file']['size'] = $_FILES['files']['size'][$i];  
    
          $config['upload_path'] = $imagePath;  
          $config['allowed_types'] = 'jpg|jpeg|png|gif';  
          $config['max_size'] = '5000'; 
		
		$fileName = $_FILES['files']['name'][$i];   
		$fileNameCmps = explode(".", $fileName);
		$fileExtension = strtolower(end($fileNameCmps));
		$newFileName = md5(time() . $fileName) . '.' . $fileExtension;
		  
          $config['file_name'] = $newFileName;  
     
          $this->load->library('upload',$config);   
      
          if($this->upload->do_upload('file')){  
            $uploadData = $this->upload->data();  
            $filename = $uploadData['file_name'];
            $data['totalFiles'][] = $filename;  
          }
		    
        }
		
		$imageData[$i]['name'] = $filename;
		$imageData[$i]['profile_id'] = $id;
		$imageData[$i]['created_date'] = date('Y-m-d H:i:s');			
     
      }

	  	$this->Profile_model->imageRecords($imageData);   
	  
	  	$configVideo['upload_path'] = $videoPath; # check path is correct
		$configVideo['max_size'] = '102400';
		$configVideo['allowed_types'] = 'mp4'; # add video extenstion on here
		$configVideo['overwrite'] = FALSE;
		$configVideo['remove_spaces'] = TRUE;

		$videoName = $_FILES['videoUpload']['name'];   
		$videoExtension = pathinfo($videoName, PATHINFO_EXTENSION);
		$newVideoName = md5(time() . $videoName) . '.' . $videoExtension;
		$configVideo['file_name'] = $newVideoName;  		

		$this->load->library('upload', $configVideo);
		$this->upload->initialize($configVideo);

		if (!$this->upload->do_upload('videoUpload')) # form input field attribute
		{
			# Upload Failed	
			$this->session->set_flashdata('error', $this->upload->display_errors());
			//redirect('profile');
		}
		else
		{
			
			$videoData = array('name'=>$newVideoName, 'profile_id'=>$id, 'created_date'=>date('Y-m-d H:i:s'));
			$result = $this->Profile_model->videoRecords($videoData);
		}
		
		$configAudio['upload_path'] = $audioPath;
		$configAudio['allowed_types'] = 'mp3';
		$configAudio['max_size'] = '30000';
		$configAudio['file_ext_tolower'] = 'TRUE';
		$configAudio['remove_spaces'] = TRUE;

		$audioName = $_FILES['audioUpload']['name'];   
		$audioExtension = pathinfo($audioName, PATHINFO_EXTENSION);
		$newAudioName = md5(time() . $audioName) . '.' . $audioExtension;
		$configAudio['file_name'] = $newAudioName;  

		$this->load->library('upload', $configAudio);
		$this->upload->initialize($configAudio);
		

		if (!$this->upload->do_upload('audioUpload')) # form input field attribute
		{
			# Upload Failed
			$this->session->set_flashdata('error', $this->upload->display_errors());
			redirect('login');
		}
		else
		{
			$audioData = array('name'=>$newAudioName, 'profile_id'=>$id, 'created_date'=>date('Y-m-d H:i:s'));        	
			$result = $this->Profile_model->audioRecords($audioData); 
		}
		redirect('profile');
	

 
   }  


   public function userList(){
    // POST data
    $postData = $this->input->post();
	//$new_str = str_replace(' ', '', $postData);
	
	$data = $this->Profile_model->getUsers($postData);

    echo json_encode($data);
  }



}