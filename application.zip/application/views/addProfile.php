<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<HTML>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900"
        rel="stylesheet">

    <title>Form Validation</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/frontend/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/vendor/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/vendor/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/vendor/css/owl.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/vendor/css/lightbox.css">

    <link rel="stylesheet" type="text/css"
        href="<?php echo base_url(); ?>assets/frontend/login/css/montserrat-font.css">
    <link rel="stylesheet" type="text/css"
        href="<?php echo base_url(); ?>assets/frontend/login/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <!-- Main Style Css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/login/css/style.css" />


    <style>
    label {
        color: #fff;
        display: block;
        font-family: 'Montserrat', sans-serif;
        font-size: 12px;
        font-weight: normal;

    }

    img {
        max-width: 180px;
    }

    input[type=file] {
        padding: 10px;
        background: #2d2d2d;
    }

    body {
        margin: 0px;
        height: 100vh;
        background: #1283da;
    }

    .center {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;

    }

    .form-input {
        width: 350px;
        padding: 20px;
        background: #fff;
        box-shadow: -3px -3px 7px rgba(94, 104, 121, 0.377),
            3px 3px 7px rgba(94, 104, 121, 0.377);
    }

    .form-input input {
        display: none;

    }

    .form-input label {
        display: block;
        width: 45%;
        height: 45px;
        margin-left: 25%;
        line-height: 50px;
        text-align: center;
        background: #1172c2;

        color: #fff;
        font-size: 15px;
        font-family: "Open Sans", sans-serif;
        text-transform: Uppercase;
        font-weight: 600;
        border-radius: 5px;
        cursor: pointer;
    }

    .form-input img {
        width: 100%;
        display: none;

        margin-bottom: 30px;
    }
    </style>

</head>

<body class="form-v10">


    <!--header-->

    <header class="main-header clearfix" role="header">
        <div class="logo">

            <div class="pull-right">
                <a href="<?php echo base_url(); ?>uploadImage" class="btn btn-default btn-flat">Sign
                    out</a>
            </div>
        </div>
        <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
        <nav id="menu" class="main-nav" role="navigation">
            <ul class="main-menu">
                <li><a href="#section1">Home</a></li>
                <li class="has-submenu"><a href="#section2">About Us</a>
                    <ul class="sub-menu">
                        <li><a href="#section2">Who we are?</a></li>
                        <li><a href="#section3">What we do?</a></li>
                        <li><a href="#section3">How it works?</a></li>
                        <li><a href="https://templatemo.com/about" rel="sponsored" class="external">External URL</a>
                        </li>
                    </ul>
                </li>
                <li><a href="#section4">Courses</a></li>
                <!-- <li><a href="#section5">Video</a></li> -->
                <li><a href="#section6">Contact</a></li>
                <li><a href="https://templatemo.com" class="external">External</a></li>
            </ul>
        </nav>
    </header>


    <div class="page-content">
        <div class="form-v10-content">
            <form class="form-detail" action="<?php echo base_url(); ?>uploadImage" method="post" id="myform"
                enctype="multipart/form-data">

                <div class="form-left">
                    <h2>Other Details</h2>

                    <div class="form-row">
                        <input type="text" name="anumber" class="vnumber" id="vnumber" placeholder="Vechile Number">
                        <input type="hidden" name="id" class="anumber" id="id" placeholder="Adhaar Number"
                            value="<?php echo $id;?>">
                    </div>


                    <div class="form-row">

                        <input type="text" name="vdetails" id="vdetails" placeholder="Vechile Details">
                    </div>

                    <div class="form-row">

                        <input type="text" name="pdetails" id="pdetails" placeholder="Property Details">
                    </div>

                    <div class="form-row">

                        <input type="text" name="plocation" id="plocation" placeholder="Property Location">
                    </div>

                    <div class="form-row">

                        <input type="text" name="linkwith" id="linkwith" placeholder="Link With">

                    </div>

                </div>
                <div class="form-right">
                    <h2>Media Details</h2>

                    <div class="form-row">
                        <label>Choose images to upload (PNG, JPG)</label>
                        <input type='file' name='files[]' multiple="" id="image_uploads"> <br /><br />
                    </div>

                    <div class="form-row">
                        <label>Choose Video to upload (Mp4)</label>
                        <input type='file' name='videoUpload'> <br /><br />
                    </div>
                    <div class="form-row">
                        <label>Choose Audio to upload (Mp3)</label>
                        <input type='file' name='audioUpload'> <br /><br />
                    </div>

                    <div class="form-row-last">
                        <input type="submit" name="Submit" class="register" value="Submit">
                        <input type="reset" id="reset" name="Reset" class="register" value="Reset" />
                    </div>
                </div>
            </form>


        </div>
        <link rel="stylesheet"
            href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
        <script src="<?php echo base_url(); ?>assets/frontend/js/jquery-3.6.0.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/frontend/js/bootstrap.bundle.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- jQuery UI -->
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>


</body>

</html>