<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model
{
    
    function loginMe($username, $password)
    {
  
        $this->db->select('BaseTbl.u_id, BaseTbl.username, BaseTbl.password, Roles.roleId, Emp.emp_name, Roles.rolename, Emp.branch_id');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_emp_details as Emp','Emp.emp_id = BaseTbl.u_id'); 
        $this->db->join('cct_roles as Roles','Roles.roleId = Emp.role_id');
        $this->db->where('BaseTbl.username', $username);
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
       $user = $query->row();
        
        if(!empty($user)){
            if(verifyHashedPassword($password, $user->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
       
    }


    function resetPasswordUser($data)
    {
        $result = $this->db->insert('tbl_reset_password', $data);

        if($result) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


    function checkActivationDetails($email, $activation_id)
    {
        $this->db->select('id');
        $this->db->from('tbl_reset_password');
        $this->db->where('email', $email);
        $this->db->where('activation_id', $activation_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function createPasswordUser($email, $password)
    {
        $this->db->where('email', $email);
        $this->db->where('isDeleted', 0);
        $this->db->update('tbl_users', array('password'=>getHashedPassword($password)));
        $this->db->delete('tbl_reset_password', array('email'=>$email));
    }


    function lastLogin($loginInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_last_login', $loginInfo);
        $this->db->trans_complete();
    }


    function lastLoginInfo($u_id)
    {
        $this->db->select('BaseTbl.created_date');
        $this->db->where('BaseTbl.emp_id', $u_id);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get('cct_emp_details as BaseTbl');

        return $query->row();
    }
}

?>