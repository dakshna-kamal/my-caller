<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Volunteer extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    //var $email;
     public function __construct()
    {
        parent::__construct();
        $this->load->model('volunteer_model');
        date_default_timezone_set('asia/kolkata');  
        
    }

    /**
     * Index Page for this controller.
     */
    public function index()
    {
        $this->load->view('volunteer');
        session_destroy();
       
        //global $res;
    }
    

    function isVolunteer(){

        $this->load->library('form_validation');
        $this->load->library('session');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[60]');

        //global $email;
        $email= $this->security->xss_clean($this->input->post('email'));
        
       

        $result = $this->volunteer_model->checkEmailExist($email);
        

  
        if($result == FALSE)
        {
        
        $this->session->set_userdata('email',$email);     
        redirect('signUp');
               
        }

        else{

            $this->session->set_flashdata('error', 'Your Email id is already registered');
            redirect('Volunteer');
            session_destroy();
        }    
        //checkEmailExist


    }


    function signUp(){

        
        if (!$this->session->userdata('email')){
            redirect('Volunteer');
            session_destroy();
        }
        else{
            
            $this->load->view('signUp');
        }
        
    }


    function otpCheck(){

        $email = $this->session->email;
        $fname = $this->session->fname;
        
        $sql = 'SELECT v_id FROM cct_volunteer_details ORDER BY v_id DESC LIMIT 1';
        $query = $this->db->query($sql);
        $user = $query->row();
        $data = ($user->v_id);
        $v_id1 = $data;
        $this->session->set_userdata('v_id',$v_id1);
        
        $v_id = $this->session->v_id;


        
        $result = $this->volunteer_model->sendEmail($email, $fname, $v_id);
         
        if($result == TRUE){


            redirect('verifyOTP1');
        }
       
        
    }

    function verifyOTP1(){

        if (!$this->session->userdata('email')){
            redirect('Volunteer');
            session_destroy();
        }
        else{
        $this->load->view('otpCheck');
        }    
    }



    function verifyOTP(){

        $OTP =  $_POST['OTP'];
        $email = $this->session->v_id;

        $result = $this->volunteer_model->verifyOTP($email, $OTP);

        if($result == TRUE){

            redirect('http://www.childrencharitabletrust.org', 'refresh');
        }
        else{
            $this->session->set_flashdata('error', 'Enter Valid OTP number!');
            redirect('verifyOTP1');
            
        }

    }



    function insertSignature()
	{
    
   // $this->session->unset_userdata('email'); 
        
   
   //$email=  $this->session->userdata('email');
    $this->load->library('email');
    $email =  $_POST['email']; 
    $mobile =  $_POST['phone'];
    $fname =  $_POST['fname'];
    $address =  $_POST['address'];

    
    

    $this->session->set_userdata('fname', $fname);
                
               
    $status = 1;
	$img = $_POST['image'];
	$img = str_replace('data:image/png;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
    
    


	$data = base64_decode($img);
	//$file = 'signature-image/' . uniqid() . '.png';
	//$success = file_put_contents($file, $data);

    //$data2 = file_get_contents($_FILES[$file][$data]);

	//$image=str_replace('./','',$file);

    //$this->volunteer_model->insert_single_signature($image);
	 //echo '<img src="'.base_url().$image.'">';
     //echo $file;
     $userInfo = array('v_name'=>$fname, 'v_email'=>$email, 'v_phone'=>$mobile, 'v_address'=>$address, 'imageData'=>$data, 'status'=>$status,  'created_date'=>date('Y-m-d H:i:s'));
     
     //$this->volunteer_model->updateVolunteer($userInfo);
     //$this->volunteer_model->addVolunteer($userInfo);
    $this->volunteer_model->addVolunteer($userInfo);
    /*if($result == TRUE){

        redirect('http://www.childrencharitabletrust.org', 'refresh');
    }/*/
    //$this->session->set_userdata('v_id', $insert_id);
         /*if($this->volunteer_model->sendEmail($email, $fname)){
             if(TRUE){
                redirect('otpCheck');
             }
         }*/
     

     //$this->session->unset_userdata('email'); 
     //session_destroy();
     //redirect('http://www.yahoo.com', 'refresh');
        
    
          
	}

  
    function deleteVolunteer()
    {
        
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>1);
            
            $result = $this->volunteer_model->deleteVolunteer($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        
    }
    
}

?>