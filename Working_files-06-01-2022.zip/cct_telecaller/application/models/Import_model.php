<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Import_model extends CI_Model
{
	
    public function importData($data) {
  
        $res = $this->db->insert_batch('import',$data);
        if($res){
            return TRUE;
        }else{
            return FALSE;
        }
  
    }
    

    function pushSuccessUserRecords($successRecords)
	{
		$this->db->trans_start();
		$this->db->insert_batch("cct_login", $successRecords);
        
		$this->db->trans_complete();
	}
    function pushSuccessUserRecords1($successRecords1)
	{
		$this->db->trans_start();
		$this->db->insert_batch("cct_emp_details", $successRecords1);
        
		$this->db->trans_complete();
	}
    
    function pushSuccessTaskRecords($successRecords)
	{
		$this->db->trans_start();
		$this->db->insert_batch("cct_task_details", $successRecords);
        
		$this->db->trans_complete();
	}

    function pushSuccessUserRecords3($inserdata3)
	{
		$this->db->trans_start();
	       
        $this->db->update_batch("cct_login", $inserdata3, 'u_id');
        
		$this->db->trans_complete();
	}



    private $table = 'cct_login';

    public function getFields() {
 
        return $this->db->list_fields($this->table);

    }
    
    public function getCol() {

        return $this->db->get($this->table)->num_fields();
     }
    
    public function getAll() {

        return $this->db->get($this->table);
    }

    function paymentStatusDownload()
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        //$this->db->where('TaskTbl.branch_id' , $branchId);
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
       
        return $this->db->get();
      
        
    }

      
}