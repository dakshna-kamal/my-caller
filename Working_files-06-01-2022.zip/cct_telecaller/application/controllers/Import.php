<?php if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' );

require APPPATH . '/libraries/BaseController.php';

require FCPATH . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Html;

ini_set("include_path", '/home/vtsy76lcgz4r/php:' . ini_get("include_path") );
ini_set('session.cache_limiter','public');
session_cache_limiter(false);


class Import extends BaseController {

	public function __construct() {
		parent::__construct ();
		$this->load->library ( 'user_agent' );
		$this->load->model ( 'import_model' );
		$this->load->model ( 'User_model' );
		$this->isLoggedIn ();
		date_default_timezone_set('asia/kolkata');
	}
	
	function importUserExcel() {
		if ($this->isManager () == TRUE) {
			$this->loadThis ();
	} 
	else {

		$this->global ['pageTitle'] = 'CCT | Upload TeleCaller Data';

		$this->loadViews("userImporting", $this->global, NULL, NULL);
		}
	}

	function uploadUserData() {
		set_time_limit ( 0 );
		
		if ($this->isManager () == TRUE) {
			$this->loadThis ();
		} else {
			
		set_time_limit ( 0 );
		
		$date = date ( "Y-m-d H:i:s" );
		$date1 = date ( "Y-m-d H:i:s" );

		$branchId = $this->session->branchId;

		$emp_id = 1;
		
		$this->load->library ( "form_validation" );
  
			$path = 'uploads/';
			require_once APPPATH . "/third_party/PHPExcel.php";
			$config['upload_path'] = $path;
			$config['allowed_types'] = 'xlsx|xls|csv';
			$config['remove_spaces'] = TRUE;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);            
			if (!$this->upload->do_upload('impfile')) {
				$error = array('error' => $this->upload->display_errors());
			} else {
				$data = array('upload_data' => $this->upload->data());
			}
			if(empty($error)){
			  if (!empty($data['upload_data']['file_name'])) {
				$import_xls_file = $data['upload_data']['file_name'];
			} else {
				$import_xls_file = 0;
			}
			$inputFileName = $path . $import_xls_file;
			
			 
			try {

				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				$allDataInSheet1 = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				$flag = true;
				$flag1 = true;
				$i=0;
				$j=0;

				foreach ($allDataInSheet1 as $value1) {
				  if($flag){
					$flag =false;
					continue;
				  }

				  $inserdata1[$i]["username"] = 'CCT_';
				  $inserdata1[$i]["password"] = getHashedPassword('admin');
				  $inserdata1[$i]["created_date"] = $date;
				  $i++;
				}               
				
				$this->import_model->pushSuccessUserRecords($inserdata1);

				$sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
				$query = $this->db->query($sql);
				$user = $query->row();

				$data1 = (($user->u_id) + 1)  - $i ;
				$data2 = (($user->u_id) + 1)  - $i ;

				foreach ($allDataInSheet as $value) {
					if($flag1){
					  $flag1 =false;
					  continue;
					}
					
					
					$inserdata3[$j]["username"] = 'CCT_'.$data2;
					$inserdata3[$j]["u_id"] = $data2;
					

					$inserdata[$j]["emp_id"] = $data1++;
					$inserdata[$j]["created_date"] = $date1;

					$inserdata[$j]['emp_name'] = $value['A'];
					$inserdata[$j]['mobile_num'] = $value['B'];
					$inserdata[$j]['gender'] = $value['C'];
					$inserdata[$j]['role_id'] = 3;
					if($this->isManager () == TRUE){
					
						$inserdata[$j]['branch_id'] = $value['D'];
					}
					else{
						$inserdata[$j]['branch_id'] = $branchId;
					}
					$data2++;
					$j++;

					

				}

				$this->import_model->pushSuccessUserRecords3($inserdata3);  

				$this->import_model->pushSuccessUserRecords1($inserdata);    
				
				if(!empty($inserdata)){

					$this->session->set_flashdata ( 'success', ' User Data imported successfully' );
					
					unlink($inputFileName);
				}else{
					$this->session->set_flashdata ( 'error', 'Data import failed' );
				}             
  
		  } catch (Exception $e) {
			   die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
						. '": ' .$e->getMessage());
			}
		  }else{
			  echo $error['error'];
			
		  }
		  redirect ( 'importUserExcel' );

		
	}

	}

	function importManagerExcel() {
		
		if ($this->isAdmin () == TRUE) {
			$this->loadThis ();
		} else {
			$this->global ['pageTitle'] = 'CCT | Import Manager Data';
			$this->loadViews("managerImporting", $this->global, NULL, NULL);
		}
		}
	
		function uploadManagerData() {
			set_time_limit ( 0 );
			
			if ($this->isAdmin () == TRUE ) {
				$this->loadThis ();
			} else {
				
			set_time_limit ( 0 );
			
			$date = date ( "Y-m-d H:i:s" );
			$date1 = date ( "Y-m-d H:i:s" );
	
			$branchId = $this->session->branchId;
	
			$emp_id = 1;
			
			$this->load->library ( "form_validation" );
	  
				$path = 'uploads/';
				require_once APPPATH . "/third_party/PHPExcel.php";
				$config['upload_path'] = $path;
				$config['allowed_types'] = 'xlsx|xls|csv';
				$config['remove_spaces'] = TRUE;
				$this->load->library('upload', $config);
				$this->upload->initialize($config);            
				if (!$this->upload->do_upload('impfile')) {
					$error = array('error' => $this->upload->display_errors());
				} else {
					$data = array('upload_data' => $this->upload->data());
				}
				if(empty($error)){
				  if (!empty($data['upload_data']['file_name'])) {
					$import_xls_file = $data['upload_data']['file_name'];
				} else {
					$import_xls_file = 0;
				}
				$inputFileName = $path . $import_xls_file;
				
				 
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
					$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
					$allDataInSheet1 = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
					$flag = true;
					$flag1 = true;
					$i=0;
					$j=0;
					foreach ($allDataInSheet1 as $value1) {
					  if($flag){
						$flag =false;
						continue;
					  }

					  $inserdata1[$i]["username"] = 'CCT_';
					  $inserdata1[$i]["password"] = getHashedPassword('admin');
					  $inserdata1[$i]["created_date"] = $date;
					  $i++;
					}               
					
					$this->import_model->pushSuccessUserRecords($inserdata1);
	
					$sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
					$query = $this->db->query($sql);
					$user = $query->row();
	
					$data1 = (($user->u_id) + 1)  - $i ;
					$data2 = (($user->u_id) + 1)  - $i ;

	
					foreach ($allDataInSheet as $value) {
						if($flag1){
						  $flag1 =false;
						  continue;
						}
						
						
						$inserdata3[$j]["username"] = 'CCT_'.$data2;
						$inserdata3[$j]["u_id"] = $data2;
						
	
						$inserdata[$j]["emp_id"] = $data1++;
						$inserdata[$j]["created_date"] = $date1;
	
						$inserdata[$j]['emp_name'] = $value['A'];
						$inserdata[$j]['mobile_num'] = $value['B'];
						$inserdata[$j]['gender'] = $value['C'];
						$inserdata[$j]['role_id'] = 2;
						$inserdata[$j]['branch_id'] = $value['D'];
						$data2++;
						$j++;

					}

					$this->import_model->pushSuccessUserRecords3($inserdata3);  
	
					$this->import_model->pushSuccessUserRecords1($inserdata);    
					
					if(!empty($inserdata)){
	
						$this->session->set_flashdata ( 'success', ' Manager Data imported successfully' );
						
						unlink($inputFileName);
					}else{
						$this->session->set_flashdata ( 'error', 'Data import failed' );
					}             
	  
			  } catch (Exception $e) {
				   die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
							. '": ' .$e->getMessage());
				}
			  }else{
				  echo $error['error'];
				
			  }
			  redirect ( 'importManagerExcel' );
	
			
		}
	
	}


	
		
	function importBranchTask(){
		
		if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){
			
			$this->loadThis ();
		} 
		else {

			$this->global ['pageTitle'] = 'CCT | Upload Task Data';
			$this->loadViews("taskUploading", $this->global, NULL, NULL);
		}

	}

	function uploadTaskData2() {
		set_time_limit ( 0 );
		
		if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){

			$this->loadThis ();

		} 
		else {
			
			$submitted = "Submitted";

			$sql2 = "SELECT c_id FROM call_status where c_status = 'Submitted'";
			$query2 = $this->db->query($sql2);
			$user2 = $query2->row();
			$subData= $user2->c_id; 
			$this->load->library ( "form_validation" );

			$path = 'uploads/';
		require_once APPPATH . "/third_party/PHPExcel.php";
		$config['upload_path'] = $path;
		$config['allowed_types'] = 'xlsx|xls|csv';
		$config['remove_spaces'] = TRUE;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);            
		if (!$this->upload->do_upload('impfile')) {
			$error = array('error' => $this->upload->display_errors());
		} else {
			$data = array('upload_data' => $this->upload->data());
		}
		if(empty($error)){
		  if (!empty($data['upload_data']['file_name'])) {
			$import_xls_file = $data['upload_data']['file_name'];
		} else {
			$import_xls_file = 0;
		}
		$inputFileName = $path . $import_xls_file;
		
		 
		try {
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader->load($inputFileName);
			$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
			$flag = true;
			$i=0;
			foreach ($allDataInSheet as $value) {
			  if($flag){
				$flag =false;
				continue;
			  }

			  $inserdata[$i]["call_status"] = $subData;
			 

			  $inserdata[$i]['branch_id'] = $value['A'];
			  $inserdata[$i]['customer_number'] = $value['B'];

			$date1 = str_replace("/", ".", $value['C']);
			$dates = date("Y-m-j", strtotime($date1));
			$inserdata[$i]['submitted_date']  = $dates;
      		$i++;
			}               
			
			$this->import_model->pushSuccessTaskRecords($inserdata);
			   
			
			if(!empty($inserdata)){
				$this->session->set_flashdata ( 'success', ' Task details are successfully uploaded' );
				
				unlink($inputFileName);
			}else{
				$this->session->set_flashdata ( 'error', 'Data import failed' );
			}             

	  } catch (Exception $e) {
		   die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
					. '": ' .$e->getMessage());
		}
	  }else{
		  echo $error['error'];
		
	  }

	  redirect ( 'importBranchTask' );
		}
	}
	
  
   public function getLetters($num_col) {
    $letters = [];
    for($i=1; $i <= $num_col; $i++) {
      $char = $this->generateChar($i);
      array_push($letters, $char);
    }

    return $letters;
  }

  public function generateChar($num) {
    $numeric = ($num - 1) % 26;
    $letter = chr(65 + $numeric);
    $div = ($num - 1) / 26;
    $num2 = (int)$div;
    if ($num2 > 0) {
        return $this->generateChar($num2) . $letter;
    } else {
        return $letter;
    }
  }

   public function downloadPaymmentData($b_id){
	
	$getDate = date('Y-m-d');
	
	$fields = $this->import_model->getFields();
    $num_col = 8;
	$getdata = $this->import_model->paymentStatusDownload()->result_array();
	

    $alphabet = $this->getLetters($num_col);

    $xlsx = new Spreadsheet();
    $sheet = $xlsx->getActiveSheet();


    $style = [
      'font' => [
        'bold' => true
      ], 
      'alignment' => [
        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
        'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
      ],
      'borders' => [
        'bottom' => [
          'borderstyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
          'color' => [ 'rgb' => 333333 ]
        ]
      ],
      'fill' => [
        'type'       => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'rotation'   => 90,
        'startcolor' => array('rgb' => '0d0d0d'),
        'endColor'   => array('rgb' => 'f2f2f2'),
      ]
    ];

    $xlsx->getActiveSheet()->getStyle($alphabet[0].'1:'.$alphabet[$num_col-1].'1')->applyFromArray($style);

    foreach(range($alphabet[0], $alphabet[$num_col-1]) as $columnID) {
      $xlsx->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
    }

    $x=0;
    
      $sheet->setCellValue('A1', 'Task Id');
	  $sheet->setCellValue('B1', 'Employee Name');
	  $sheet->setCellValue('C1', 'Customer Number');
	  $sheet->setCellValue('D1', 'Payment Id');
	  $sheet->setCellValue('E1', 'Payment Details');
	  $sheet->setCellValue('F1', 'Payment date');
	  $sheet->setCellValue('G1', 'Payment Status');
	  $sheet->setCellValue('H1', 'Remarks');
 
    $i = 2;
	$j = 0; 
    foreach($getdata as $get) {
      
        $sheet->setCellValue('A'.$i, $get['t_id']);
		$sheet->setCellValue('B'.$i, $get['emp_name']);
		$sheet->setCellValue('C'.$i, $get['customer_number']);
		$sheet->setCellValue('D'.$i, $get['payment_id']);
		$sheet->setCellValue('E'.$i, $get['payment_info']);
		$sheet->setCellValue('F'.$i,  date("d-m-Y", strtotime($get['payment_date'])));
		$sheet->setCellValue('G'.$i, $get['p_status']);
		$sheet->setCellValue('H'.$i, $get['remarks']);
    
      $i++;
    }

    $write = new Xlsx($xlsx);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="PaymentData.xlsx"');
    $write->save('php://output');
       
    }


}
