<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Task_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    
    function taskListing($searchText)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        
        
        //$this->db->where('TaskTbl.branch_id', $branchId);
        //$this->db->where('TaskTbl.assigned_date >= ', $getDate);
        $this->db->where('call.c_status', 'Submitted');
              


        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        //$this->db->limit($page, $segment);

        $query = $this->db->get();
        $result = $query->result();   
        return $result;
        
        
    }


    function taskListingCount($searchText, $branchId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
       // $this->db->where('Emp.branch_id', $branchId);
        //$this->db->where('TaskTbl.assigned_date >= ', $getDate);
        $this->db->where('call.c_status', 'Submitted');
        $this->db->where('TaskTbl.branch_id', $branchId);
       

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $query = $this->db->get();

        return $query->num_rows();
        
    }

        




    function taskListingYesterdayCount($searchText, $searchOption, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date < ', $getDate); 

        $this->db->where('call.c_id !=', 3);
        $this->db->where('call.c_id !=', 7);
        $this->db->where('call.c_id !=', 6);

        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }}
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.t_id  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }}
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
         else if($searchOption == 4){
                if(!empty($searchText)) {
                $likeCriteria = "(call.c_status  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

    function taskListingYesterday($searchText, $searchOption, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
       
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date < ', $getDate);
        $this->db->where('call.c_id !=', 3);
        $this->db->where('call.c_id !=', 7);
        $this->db->where('call.c_id !=', 6);


        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }}
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.t_id  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }}
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
         else if($searchOption == 4){
                if(!empty($searchText)) {
                $likeCriteria = "(call.c_status  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
        
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }
    
    function reminderTaskListingToday($searchText, $page, $segment, $branchId, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
       // $this->db->where('TaskTbl.assigned_date >= ', $getDate);

       $this->db->where('call.c_id', 3);
       //$this->db->where('call.c_id !=', 7);
       
       $this->db->where( "TaskTbl.isDeleted", 0 );
       

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);

        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;

          

    }


    function reminderTaskListingTodayCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
       // $this->db->where('TaskTbl.assigned_date >= ', $getDate);

        $this->db->where('call.c_id', 3);
        
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
       
            $query = $this->db->get();
            return $query->num_rows();
       



        
    }


    function escalatedTask($searchText, $page, $segment, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, b_name, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        //$this->db->where('Emp.branch_id', $branchId);
       // $this->db->where('TaskTbl.assigned_date >= ', $getDate);

       $this->db->where('call.c_id', 3);
       
       $this->db->where( "TaskTbl.isDeleted", 0 );
       

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
       

    }


    function escalatedTaskCount($searchText, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        //$this->db->where('Emp.branch_id', $branchId);
       // $this->db->where('TaskTbl.assigned_date >= ', $getDate);

        $this->db->where('call.c_id', 3);
       
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        return $query->num_rows();


        
    }


    function taskListingToday($searchText,$searchOption, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date >= ', $getDate);
        $this->db->where('call.c_id !=', 3);
        $this->db->where('call.c_id !=', 7);
        $this->db->where('call.c_id !=', 6);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }}
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.t_id  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }}
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
         else if($searchOption == 4){
                if(!empty($searchText)) {
                $likeCriteria = "(call.c_status  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function taskListingTodayCount($searchText,$searchOption, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date >= ', $getDate);
        $this->db->where('call.c_id !=', 3);
        $this->db->where('call.c_id !=', 7);
        $this->db->where('call.c_id !=', 6);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }}
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.t_id  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }}
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
         else if($searchOption == 4){
                if(!empty($searchText)) {
                $likeCriteria = "(call.c_status  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
                }}
        
      
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function taskTeleListingTodayCount($searchText,$branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where( "TaskTbl.isDeleted", 0 ); 
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date >= ', $getDate);
        $where = "call.c_id != 3 AND call.c_id != 7 AND call.c_id != 6";
        $this->db->where($where);


        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function teleTaskListingToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
 
      

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        //$where1 = 'DATE(call_on_date)';
        
        $this->db->where('TaskTbl.assigned_date' , $getDate);
            
        $where = "call.c_id != 3 AND call.c_id != 7 AND call.c_id != 6";
        $this->db->where($where);
        


        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskListingTodayCount($searchText, $branchId, $getDate, $userId)
    {
 
      

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        //$where1 = 'DATE(call_on_date)';
        
        $this->db->where('TaskTbl.assigned_date >=' , $getDate);
            
        $where = "call.c_id != 3 AND call.c_id != 7 AND call.c_id != 6";
        $this->db->where($where);
        


        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        //$this->db->where('TaskTbl.assigned_date >= ', $getDate);
        
        $this->db->where( "call.c_id", 7 ); 


        $this->db->where( "TaskTbl.isDeleted", 0 );
        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskInCompletedTodayCount($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date <', $getDate);
        $where = "call.c_id != 3 AND call.c_id != 7 AND call.c_id != 6";
        $this->db->where($where);
  

        $this->db->where( "TaskTbl.isDeleted", 0 );
        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskInCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date <', $getDate);
        $where = "call.c_id != 3 AND call.c_id != 7 AND call.c_id != 6";
        $this->db->where($where);
  

        $this->db->where( "TaskTbl.isDeleted", 0 );
        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function teleTaskReminderToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);

        
        $myDate = date("Y-m-d H:i:s");
        
        //$this->db->where('TaskTbl.call_on_date', $myDate);
        $this->db->where( "call.c_id ", 3 ); 
        


        $this->db->where( "TaskTbl.isDeleted", 0 );
        if(!empty($searchText)) {
            $likeCriteria = "(call.c_status  LIKE '%".$searchText."%'
                            OR  TaskTbl.customer_number  LIKE '%".$searchText."%'
                            OR  Emp.emp_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function taskListingCount1($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date ', $getDate);


        $this->db->where( "TaskTbl.isDeleted", 0 );
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '% ".$searchText." %' 
                            OR call.c_status LIKE '% ".$searchText."%' )";
            $this->db->where($likeCriteria);
        }
        

        $query = $this->db->get();
        
        return $query->num_rows();
        
    }
    
 


    /*$this->db->select('BaseTbl.userId, BaseTbl.email, BaseTbl.name, BaseTbl.mobile, Role.role');
    $this->db->from('tbl_users as BaseTbl');
    $this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/

  //  SELECT t1.b_id, t1.b_name, t2.address, t2.phone_number FROM tbl_branches t1 INNER JOIN tbl_branch_details t2 ON t1. b_id = t2. b_id;

    
    /**
     * This function is used to get the user roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getUserRoles1()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }


    function getUserBranches()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
       
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function userNameCreation()
    {
        $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
        $query = $this->db->query($sql);
        $user = $query->row();
        return $user;
    }


    function getManagerUsersCount() {
		$this->db->select ( "emp_id" );
		//$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 3 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getEmployeeUsersCount() {
		$this->db->select ( "emp_id" );
		//$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 2 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}



    /**
     * This function is used to check whether email id is already exist or not
     * @param {string} $email : This is email id
     * @param {number} $userId : This is user id
     * @return {mixed} $result : This is searched result
     */
    function checkEmailExists($email, $userId = 0)
    {
        $this->db->select("email");
        $this->db->from("tbl_users");
        $this->db->where("email", $email);   
        $this->db->where("isDeleted", 0);
        if($userId != 0){
            $this->db->where("userId !=", $userId);
        }
        $query = $this->db->get();

        return $query->result();
    }
    
    
    /**
     * This function is used to add new user to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('cct_task_details', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

   

   
    
    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getUserInfo($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
		$this->db->where('role_id !=', 1);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getBranchInfo($branchId)
    {
        $this->db->select('b_name, b_address, b_id, b_phonenum');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo($branchId)
    {
        $this->db->select('emp_id, emp_name');
        $this->db->from('cct_emp_details');
        $this->db->where('role_id !=', 1);
        $this->db->where('role_id !=', 2);
        $this->db->where('branch_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo2($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, Emp.emp_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'TaskTbl.emp_id  = Emp.emp_id ','inner');  
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskAdminInfo($taskId){
        $this->db->select('TaskTbl.t_id,  TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        
        $this->db->join('cct_branch_details as Branch', 'TaskTbl.branch_id  = Branch.b_id ','inner');    
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    

    function getTaskInfo3($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, TaskTbl.assigned_date, TaskTbl.call_status, TaskTbl.call_on_date, TaskTbl.receipt_no');
        $this->db->from('cct_task_details as TaskTbl');
        //$this->db->join('call_status as Call', 'Call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo4()
    {
        $this->db->select('c_id, c_status');
        $this->db->from('call_status');
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo5()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
        $query = $this->db->get();
        
        return $query->result();

    }




    function getBranchName($branchId){
        $this->db->select('b_name');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }
    
    
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editUser($userInfo, $userId)
    {
        $this->db->where('emp_id', $userId);
        $this->db->update('cct_emp_details', $userInfo);
        
        return TRUE;
    }

    function editBranch($branchInfo, $b_Id)
    {
        $this->db->where('b_id', $b_Id);
        $this->db->update('cct_branch_details', $branchInfo);
        
        return TRUE;
    }

    function editTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }

    

    function editAdminTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }

    
    

    
    
    
    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */

    function deleteTask($t_id, $taskInfo)
    {
        $this->db->where('t_id', $t_id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return $this->db->affected_rows();
    }


    /**
     * This function is used to match users password for change password
     * @param number $userId : This is user id
     */
    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('u_id, password');
        $this->db->where('u_id', $userId);        
        //$this->db->where('isDeleted', 0);
        $query = $this->db->get('cct_login');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    
    /**
     * This function is used to change users password
     * @param number $userId : This is user id
     * @param array $userInfo : This is user updation info
     */
    function changePassword($userId, $userInfo)
    {
        $this->db->where('u_id', $userId);
        //$this->db->where('isDeleted', 0);
        $this->db->update('cct_login', $userInfo);
        
        return $this->db->affected_rows();
    }


    /**
     * This function is used to get user login history
     * @param number $userId : This is user id
     */
    function loginHistoryCount($userId, $searchText, $fromDate, $toDate)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->from('tbl_last_login as BaseTbl');
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    /**
     * This function is used to get user login history
     * @param number $userId : This is user id
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function loginHistory($userId, $searchText, $fromDate, $toDate, $page, $segment)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        $this->db->from('tbl_last_login as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    function getUserInfoById($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    function branchInfo($branchId)
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->row();

    }


    function getUsers($postData=null){

        $response = array();
  
        ## Read value
        $draw = $postData['draw'];
        $start = $postData['start'];
        $rowperpage = $postData['length']; // Rows display per page
        $columnIndex = $postData['order'][0]['column']; // Column index
        $columnName = $postData['columns'][$columnIndex]['data']; // Column name
        $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
        $searchValue = $postData['search']['value']; // Search value
  
        // Custom search filter 
        $searchCity = $postData['searchCity'];
        //$searchGender = $postData['searchGender'];
        $searchName = $postData['searchName'];
  
        ## Search 
        $search_arr = array();
        $searchQuery = "";
        
        
      if($searchValue != ''){
          $search_arr[] = " (t_id like '%".$searchValue."%' or 
          customer_number like '%".$searchValue."%'  or b_name like '%".$searchValue."%') ";
      }
      
      if($searchCity != ''){
          $search_arr[] = "branch_id='".$searchCity."' ";
      }
  
      if($searchName != ''){
          $search_arr[] = "customer_number like '%".$searchName."%' ";
      }
      if(count($search_arr) > 0){
          $searchQuery = implode(" and ",$search_arr);
      }

        $this->db->select('count(*) as allcount');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $query = $this->db->get();
        $totalRecords = $query->num_rows();
  
        ## Total number of record with filtering
        $this->db->select('count(*) as allcount');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        
        if($searchQuery != '')
        $this->db->where($searchQuery);
        $query = $this->db->get();
        $totalRecordwithFilter = $query->num_rows();
  
        ## Fetch records
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->where( "TaskTbl.isDeleted", 0 );
        if($searchQuery != '')
        $this->db->where($searchQuery);
        $this->db->order_by($columnName, $columnSortOrder);
        $this->db->limit($rowperpage, $start);
  
        $query = $this->db->get();
        $records = $query->result();   
  
        
  
        $data = array();
  
        foreach($records as $record ){
           
            $data[] = array( 
                "t_id"=>$record->t_id,
                "b_name"=>$record->b_name,
                "customer_number"=>$record->customer_number,
                "assigned_date" => date("d-m-Y", strtotime($record->assigned_date)) ,
                
            ); 
        }
  
        ## Response
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordwithFilter,
            "aaData" => $data
        );
  
        return $response; 
    }
  

    public function getCities(){
  

        $this->db->select('b_id, b_name');

        $this->db->from('cct_branch_details');
  
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
  
    }
    

}

  