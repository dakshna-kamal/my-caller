<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('Volunteer_model');
        //$this->load->model('cms_model');
        $this->isLoggedIn();   
        date_default_timezone_set('asia/kolkata');
        //$this->session->keep_flashdata('success');
    }



    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        $this->global['pageTitle'] = 'CCT | Dashboard';


        


       /* $sql = 'UPDATE cct_task_details SET isPending = 1 WHERE call_status = 1 AND DATE(assigned_date) < CURDATE()';
        $query = $this->db->query($sql);*/
		/*$data ["finalizeCount"] = $this->cms_model->getCustomerCountByStatus ( FINALS, $this->role, $this->vendorId );
		$data ["processedCount"] = $this->cms_model->getCustomerCountByStatus ( PROCESSED, $this->role, $this->vendorId );
		$data ["rawCount"] = $this->cms_model->getCustomerCountByStatus ( RAW, $this->role, $this->vendorId );
		$data ["deadCount"] = $this->cms_model->getCustomerCountByStatus ( DEAD, $this->role, $this->vendorId );
		
		$data ["notAssignedCount"] = $this->cms_model->getCustomerCountByAssignement ( 0, 0 );
		$data ["assignedCount"] = $this->cms_model->getCustomerCountByAssignement ( 1, 0 );
		$data ["totalCount"] = $this->cms_model->getCustomerCountByAssignement ( 1, 1 );
		
		$data["followupCount"] = $this->cms_model->getFollowupCount($this->vendorId, $this->role);
		
		$data ["adminUserCount"] = $this->cms_model->getAdminUsersCount ();*/

        $branchId = $this->session->branchId;
        

        $data ["managerUserCount"] = $this->user_model->getManagerUsersCount ();
        $data ["employeeUserCount"] = $this->user_model->getEmployeeUsersCount ();
        
        $data ["totalbranches"] = $this->user_model->branchListingCount();

        $data ["volunteerCount"] = $this->Volunteer_model->volunteerListingCount1();
        
        $getDate = date('Y-m-d');
        $userId= $this->session->u_id;

        $d = strtotime("14:01:00");
        
        $getTime = date("H:i:s");
        $d2 = strtotime($getTime);
       //$d3 = strtotime($d);

        if($d2 > $d){

            $getTime1 = date("H:i:s");  
        }
        else{
            
            $getTime1 = "no data";  
        }
        
        $data['branchTelecallerInfo'] = $this->user_model->getTelecallerCount($branchId);
        $data['taskCountYesterday'] = $this->user_model->getTaskCountYesterday($branchId, $getDate);
        $data['taskCountToday'] = $this->user_model->getTaskCountToday($branchId, $getDate);
        $data['teleTaskCountToday'] = $this->user_model->getTeleTaskCountToday($branchId, $getDate, $userId);
        $data['teleTaskCompleteToday'] = $this->user_model->getTeleTaskCompleteToday($branchId, $getDate, $userId);
        $data['teleTaskInCompleteToday'] = $this->user_model->getTeleTaskInCompleteToday($branchId, $getDate, $userId);
        
        $data['teleTaskReminderToday'] = $this->user_model->getTeleTaskReminderToday($branchId, $getDate, $userId);

        $data['taskReminderToday'] = $this->user_model->getTaskReminderToday($branchId, $getDate);
        $data['escalatedTask'] = $this->user_model->getescalatedTask($getDate);

        $data['teleTaskCount'] = $this->user_model->getTeleTaskCount();

        //$data['taskReminderToda'] = $this->user_model->getTeleTaskReminderToday;
  
    
        $data ["branchName"] = $this->user_model->getBranchName($branchId);

        $this->loadViews("dashboard", $this->global, $data, NULL);


        
       // session_start();
    //$timeout = 30; // Set timeout minutes
    //$logout_redirect_url = "index.php"; // Set logout URL

   

    
       

       // $this->session->keep_flashdata('item');

       /* if( isset($_SESSION['last_acted_on']) && (time() - $_SESSION['last_acted_on'] > 60*1) ){
            echo '<script>alert("Welcome")</script>';
            session_unset();     // unset $_SESSION variable for the run-time
            session_destroy();   // destroy session data in storage
            redirect('login');
        }else{
            session_regenerate_id(true);
            $_SESSION['last_acted_on'] = time();
        }*/




    }


    function dashboard1(){
        $this->loadViews("dashboard1");
    }
    
    /**
     * This function is used to load the user list
     */


    function branchListing(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->branchListingCount($searchText);

			$returns = $this->paginationCompress ( "branchListing/", $count, 10 );
            
            $data['branchRecords'] = $this->user_model->branchListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT | Branch Details';
            
            $this->loadViews("branches", $this->global, $data, NULL);

        }
    }

    function volunteerListing()
    {
       
                
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->Volunteer_model->volunteerListingCount($searchText);

			$returns = $this->paginationCompress( "volunteerListing/", $count, 10 );
            
            
            $data['volunteerRecords'] = $this->Volunteer_model->volunteerListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT | Volunteer Details';
            
            $this->loadViews("volunteerList", $this->global, $data, NULL);
        
    }


    function viewPdf($v_id = NULL)
	{
            $this->load->library('pdf');
			//header('Content-type : image/png');
			
			$html_content = "<div><br><h1 align='center'>Volunteer Agreement Details</h2>
            <p>This Volunteer Agreement is a description of the arrangement between us, (AnyOrg), and you (the volunteer) in relation to your voluntary work.  The intention of this agreement is to assure you that we appreciate your volunteering with us and to indicate our commitment to do the best we can to make your volunteer experience with us a positive and rewarding one.<p>
            <h2 align='center'>Part 1 AnyOrg</h2>
            <p>We, AnyOrg, accept the voluntary service of (name of volunteer) beginning (date).</p>
            <p>Your role as a volunteer is (state nature and components of the work).  This work is designed to (state purpose of work in relation to its benefit to the organisation).</p>
            <p>We commit to the following:</p>
            
            <p><b>1. Induction and training</b></p>
            <ul><li>To provide thorough induction on the work of AnyOrg, its staff, your volunteering role and the training necessary to assist you in meeting the responsibilities of your volunteering role, The Volunteers Handbook provides full details of the organisation.
            </li></ul>

            <p><b>2. Supervision, support and flexibility</b></p>
            <ul><li>To define appropriate standards of our services, to communicate them to you, and to encourage and support you to achieve and maintain them as part of your voluntary work
            </li><li>To provide a personal supervisor who will meet with you regularly to discuss your volunteering and any associated problems</li></ul>
            

            <div>";
			$html_content .= $this->Volunteer_model->volunteerPdf($v_id);
            $this->pdf->setPaper('A4', 'portrait');
			$this->pdf->loadHtml($html_content);
			$this->pdf->render();
			$this->pdf->stream("".$v_id.".pdf", array("Attachment"=>0));
		
	}

    





    /*function branchDetails(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->branchListingCount($searchText);

			$returns = $this->paginationCompress ( "branchListing/", $count, 10 );
            
            $data['branchRecords'] = $this->user_model->branchListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'ATC : User Listing';
            
            $this->loadViews("branchesDetails", $this->global, $data, NULL);

        }
    }*/



    function userListing()
    {
        
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE) 
        {
            $this->loadThis();
            

        }
        else
        {   
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }   

            $role = 3; 
            
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText, $role);

			$returns = $this->paginationCompress ( "userListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->userListing($searchText, $returns["page"], $returns["segment"], $role);
            
            $this->global['pageTitle'] = 'CCT | TeleCaller Details';
            
            $this->loadViews("users", $this->global, $data, NULL);
        }
    }

    function teleCallerListing()
    {
        
        if($this->isManager() == TRUE) 
        {
            $this->loadThis();
            

        }
        else
        {   
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            
            $role = 3; 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            
            $branchId = $this->session->branchId;

            $count = $this->user_model->teleCallerListingCount($searchText, $role, $branchId);

			$returns = $this->paginationCompress ( "teleCallerListing/", $count, 10 );

            $branchId = $this->session->branchId;
            
            $data['teleCallerRecords'] = $this->user_model->teleCallerListing($searchText, $returns["page"], $returns["segment"], $role, $branchId);


            
            $this->global['pageTitle'] = 'CCT | TeleCaller Details';
            
            $this->loadViews("telecallers", $this->global, $data, NULL);
        }
    }


    
    function managerListing()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE) 
        {
            $this->loadThis();
           
        }
        else
        {   
         
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
        
            $role = 2;         
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->managerListingCount($searchText);

			$returns = $this->paginationCompress ( "mangerListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->managerListing($searchText, $returns["page"], $returns["segment"], $role);
            
            $this->global['pageTitle'] = 'CCT | User Details';
            
            $this->loadViews("managers", $this->global, $data, NULL);
        }
    }



    function logout1()
    {
         
        session_destroy();
        redirect('login');

    }

    /**
     * This function is used to load the add new form
     */
    function addNew()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['branches'] = $this->user_model->getUserBranches();
            $data['roles'] = $this->user_model->getUserRoles();
            //$this->session->unset_userdata('success');
            
            $this->global['pageTitle'] = 'CCT | Add New User';

            $this->loadViews("addNew", $this->global, $data, NULL);
        }
    }


    function addNewManager()
    {
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            //$this->load->model('user_model');
            $data['branches'] = $this->user_model->getUserBranches();
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'CCT | Add New Manager';
            

            $this->loadViews("addNewManager", $this->global, $data, NULL);
        }
    }

    


    /**
     * This function is used to check whether email already exist or not
     */
    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addNewUser()
    {
        if($this->isManager() == TRUE && $this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
           
           /// $this->form_validation->set_rules('role','Role','trim|required|numeric');
            //$this->form_validation->set_rules('branches','Branches','trim|required|numeric');
            //$this->form_validation->set_rules('gender','Gender','trim|required|numeric');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else

            {
                 //SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1;

                $username = 'CCT_';
                $password = 'admin';
               
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                $fname = $this->input->post('fname');
                $roleId = 3;
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');
                
                $userInfo1 = array('username'=>$username, 'password'=>getHashedPassword($password), 'created_date'=>date('Y-m-d H:i:s'));
                
                
                 /*$userInfo2 = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId, 'name'=> $name,
                                    'mobile'=>$mobile, 'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:s'));*/

                //$this->load->model('user_model');
                $result1 = $this->user_model->addNewUser($userInfo1);
               

                
                if($result1 > 0)
                {
                    
                    $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
                    $query = $this->db->query($sql);
                    $user = $query->row();
                    $data = ($user->u_id);
                    $emp_id = $data;

                    $username = 'CCT_'.$data;
                   // $userId = $data;
                    $userInfo3 = array('username'=>$username);
                    $result3 = $this->user_model->updateUserName($userInfo3, $emp_id);

                    
                    $userInfo2 = array('emp_id'=>$emp_id,'emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches,  'created_date'=>date('Y-m-d H:i:s'));
                    $result2 = $this->user_model->addUserDetails($userInfo2);

                   $this->session->set_flashdata('success', 'New User created successfully');

                    //print "<script> alert('User Created Successfully')</script>";
                    
                    //$startTime = date("Y-m-d H:i:s");
                    //$cenvertedTime = date('Y-m-d H:i:s',strtotime('+1 hour +30 minutes +45 seconds',strtotime($startTime)));

                }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }
                
                redirect('addNew');
            }
        }
    }


    function addNewManager1()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
           
           /// $this->form_validation->set_rules('role','Role','trim|required|numeric');
            //$this->form_validation->set_rules('branches','Branches','trim|required|numeric');
            //$this->form_validation->set_rules('gender','Gender','trim|required|numeric');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else

            {
                 //SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1;

                $username = 'CCT_';
                $password = 'admin';
               
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                $result3 = $this->user_model->checkManagerList($roleId, $branches);

                if($result3 == 0)
                {
                        
                //$this->session->set_flashdata('success', 'New my created successfully');    
  
                $userInfo1 = array('username'=>$username, 'password'=>getHashedPassword($password), 'created_date'=>date('Y-m-d H:i:s'));
                
                
                 /*$userInfo2 = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId, 'name'=> $name,
                                    'mobile'=>$mobile, 'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:s'));*/

                $this->load->model('user_model');
                $result1 = $this->user_model->addNewUser($userInfo1);
               
                 
               
                
                
                if($result1 > 0)
                {
                    
                    $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
                    $query = $this->db->query($sql);
                    $user = $query->row();
                    $data = ($user->u_id);
                    $emp_id = $data;

                    $username = 'CCT_'.$data;
                   // $userId = $data;
                    $userInfo3 = array('username'=>$username);
                    $result3 = $this->user_model->updateUserName($userInfo3, $emp_id);

                    
                    $userInfo2 = array('emp_id'=>$emp_id,'emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches,  'created_date'=>date('Y-m-d H:i:s'));
                    $result2 = $this->user_model->addUserDetails($userInfo2);

                    $this->session->set_flashdata('success', 'New Manager created successfully');               }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }

            }

            else{
                $this->session->set_flashdata('error', 'This Branch Manager already created, Please check Manager Listing Page'); 
            }
                
                redirect('addNewManager');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOld($userId = NULL)
    {
        if($this->isAdmin() == TRUE &&  $this->isManager() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($userId == null)
            {
                redirect('userListing');
            }
            
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['branches'] = $this->user_model->getUserBranches();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);

            
            
            $this->global['pageTitle'] = 'CCT | Edit User';
            
            $this->loadViews("editOld", $this->global, $data, NULL);
        }
    }


    function editOldManager($userId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($userId == null)
            {
                redirect('managerListing');
            }
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['branches'] = $this->user_model->getUserBranches();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);

            
            
            $this->global['pageTitle'] = 'CCT | Edit User';
            
            $this->loadViews("editOldManager", $this->global, $data, NULL);
        }
    }


    function editManager()
    {
        
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            $rollId = $this->session->role;
     
            
            
                echo '<script> new </script>';
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                $result3 = $this->user_model->checkManagerList($roleId, $branches);

               
              
                $userInfo = array('emp_name'=>$fname,'role_id'=>$roleId, 'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches, 'updated_date'=>date('Y-m-d H:i:s'));
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Manager updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Manager updation failed');
                }
               
                 
             
            
                redirect('editOldManager');
            
                
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function editUser()
    {
        
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            $rollId = $this->session->role;
     
            
            
                echo '<script> new </script>';
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                
               
                $userInfo = array('emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches, 'updated_date'=>date('Y-m-d H:i:s'));
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'User updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User updation failed');
                }
                
                if($this->isAdmin() == FALSE )
                {
                    redirect('userListing'); 
                }
                else{
                    
                    redirect('teleCallerListing');
                }
            
        
    }


    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>1);
            
            $result = $this->user_model->deleteUser($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    

    
    /**
     * This function is used to load the change password screen
     */
    function loadChangePass()
    {
        $this->global['pageTitle'] = 'CCT | Change Password';
        
        $this->loadViews("changePassword", $this->global, NULL, NULL);
    }
    
    
    /**
     * This function is used to change the password of the user
     */
    function changePassword()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('oldPassword','Old password','required|max_length[20]');
        $this->form_validation->set_rules('newPassword','New password','required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword','Confirm new password','required|matches[newPassword]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->loadChangePass();
        }
        else
        {
            $u_id = $this->session->u_id;
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');
            
            $resultPas = $this->user_model->matchOldPassword($u_id, $oldPassword);
            
            if(empty($resultPas))
            {
                $this->session->set_flashdata('nomatch', 'Your old password not correct');
                redirect('loadChangePass');
            }
            else
            {
                $usersData = array('password'=>getHashedPassword($newPassword)
                                );
                
                $result = $this->user_model->changePassword($u_id, $usersData);
                
                if($result > 0) { $this->session->set_flashdata('success', 'Password updation successful'); }
                else { $this->session->set_flashdata('error', 'Password updation failed'); }
                
                redirect('loadChangePass');
            }
        }
    }

    /**
     * Page not found : error 404
     */
    function pageNotFound()
    {
        $this->global['pageTitle'] = 'CodeInsect : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }

    /**
     * This function used to show login history
     * @param number $userId : This is user id
     */
    function loginHistoy($userId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $userId = ($userId == NULL ? $this->session->userdata("userId") : $userId);

            $searchText = $this->input->post('searchText');
            $fromDate = $this->input->post('fromDate');
            $toDate = $this->input->post('toDate');

            $data["userInfo"] = $this->user_model->getUserInfoById($userId);

            $data['searchText'] = $searchText;
            $data['fromDate'] = $fromDate;
            $data['toDate'] = $toDate;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->loginHistoryCount($userId, $searchText, $fromDate, $toDate);

            $returns = $this->paginationCompress ( "login-history/".$userId."/", $count, 5, 3);

            $data['userRecords'] = $this->user_model->loginHistory($userId, $searchText, $fromDate, $toDate, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : User Login History';
            
            $this->loadViews("loginHistory", $this->global, $data, NULL);
        }        
    }

    

}

?>