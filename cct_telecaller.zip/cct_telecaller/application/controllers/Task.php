<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Task extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Task_model');
        $this->load->model('User_model');
        
        $this->isLoggedIn(); 
        date_default_timezone_set('asia/kolkata');
        //$this->session->unset_userdata('success');
        //$this->session->unset_userdata('error');
        $branchId = 0;
        
    }
    
    /**
     * This function used to load the first screen of the user
     */
    
    
    /**
     * This function is used to load the user list
     */


    function taskListing(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            $branchId = $this->input->post('branch_Id');

            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
 
            //$data['branch_Id'] = $branchId;
                         
            $this->load->library('pagination');

            //$branchId = $this->session->set_userdata('branch_Id');
            
           
            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
            
           // $count = $this->Task_model->taskListingCount($searchText, $branchId);

			//$returns = $this->paginationCompress("taskListing/", $count, 10);
            
            $data['branch'] = $this->Task_model->getCities();
            
            //$data['taskRecords'] = $this->Task_model->taskListing($searchText, $branchId);

            //$data['branchRecords'] = $this->User_model->branchListing1();
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("taskList", $this->global, $data, NULL);

        }
    }

    public function taskList(){

        // POST data
        $postData = $this->input->post();
    
        // Get data
        $data = $this->Task_model->getUsers($postData);
    
        echo json_encode($data);
      }


    




    function taskListingYesterday(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->taskListingYesterdayCount($searchText, $searchOption, $branchId,$getDate);

			$returns = $this->paginationCompress ( "taskListingYesterday/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->taskListingYesterday($searchText, $searchOption, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Deatils';
            
            $this->loadViews("yeasterdayTasks", $this->global, $data, NULL);

        }
    }

    function taskListingToday(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->taskListingTodayCount($searchText,$searchOption, $branchId,  $getDate);

			$returns = $this->paginationCompress ( "taskListingToday/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->taskListingToday($searchText,$searchOption, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("todayTasks", $this->global, $data, NULL);

        }
    }


    function reminderTaskListingToday(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');


            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->reminderTaskListingTodayCount($searchText, $branchId,  $getDate);

			$returns = $this->paginationCompress ( "reminderTaskListingToday/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->reminderTaskListingToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate);

            //$data['taskRecords'] = $data['taskRecords1'];
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("todayReminderTasks", $this->global, $data, NULL);

        }
    }

    function escalatedTask(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->escalatedTaskCount($searchText, $getDate);

			$returns = $this->paginationCompress ( "escalatedTask/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->escalatedTask($searchText, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("escalatedTask", $this->global, $data, NULL);

        }
    }


    function teleTaskListingToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());
                
            //$this->session->set_userdata('teleTaskListingToday', );
            
            $count = $this->Task_model->teleTaskListingTodayCount($searchText, $branchId, $getDate, $userId);
            //echo $count;

			$returns = $this->paginationCompress ( "teleTaskListingToday/", $count, 10 );
            
            $data['teleTaskReminderToday'] = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            
            $data['taskRecords'] = $this->Task_model->teleTaskListingToday($searchText, $returns["page"], $returns["segment"], $branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedTasks", $this->global, $data, NULL);
        }

    } 


    function teleTaskCompletedToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
            
            $count = $this->User_model->getTeleTaskCompleteToday($branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "teleAssignedCompleted/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskCompletedToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedCompleted", $this->global, $data, NULL);
        }

    }


    function telePendingTask(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());

            /*$sql = 'UPDATE cct_task_details SET isPending = 1 WHERE call_status = 1 AND DATE(assigned_date) < CURDATE()';
            $query = $this->db->query($sql);*/
            //$user = $query->row();
            
            $count = $this->Task_model->teleTaskInCompletedTodayCount($searchText, $branchId, $getDate, $userId);
            //echo $count;

			$returns = $this->paginationCompress ( "telePendingTask/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskInCompletedToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("telePendingTask", $this->global, $data, NULL);
        }

    }

    function teleTaskReminderToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            //echo $count;

			$returns = $this->paginationCompress ( "teleAssignedReminder/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedReminder", $this->global, $data, NULL);
        }

    }


    function teleTaskReports(){

        if($this->isManager() == TRUE){
            $this->loadThis();
        }
        else{
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
            
            $count = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            //echo $count;

			$returns = $this->paginationCompress ( "teleTaskReports/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleTaskReports", $this->global, $data, NULL);
        }

    }


    

    function branchDetails(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 

            $branchId = $this->session->branchId;
            
           // $data['branchRecords'] = $this->Task_model->branchInfo($branchId);

            $data['branchInfo'] = $this->Task_model->getBranchInfo($branchId);
            
            $this->global['pageTitle'] = 'CCT | Branch Details';

           // $data['branchRecords'] = $this->Task_model->getBranchInfo($branch);
            
            $this->loadViews("branchesDetails", $this->global,  $data, NULL);

        }
    }

    function addNewTask()
    {
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Task_model');
            $branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo5();
                        
            $this->global['pageTitle'] = 'CCT | Add New Branch';

            $this->loadViews("addNewTask", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
   

    /**
     * This function is used to check whether email already exist or not
     */
    
     
    function addingTasks()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            //$this->form_validation->set_rules('emp_id','Employee Id','trim|required|max_length[128]');
            $this->form_validation->set_rules('customer_number','Customer Number','trim|required|max_length[128]');
           // $this->form_validation->set_rules('assignDate','Assigned Date','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewTask();
            }
            else
            {
                $branch_id = $this->input->post('b_id');
                $customer_number = $this->security->xss_clean($this->input->post('customer_number'));
                $assignDate = $this->input->post('assignDate');
                $date = date('Y-m-d', strtotime($assignDate));

                $sql2 = "SELECT c_id FROM call_status where c_status = 'Submitted'";
                $query2 = $this->db->query($sql2);
                $user2 = $query2->row();
                   
                $call_status = $user2->c_id;

                /*$date = date_create($assigned_date,timezone_open("Indian/Kerguelen"));
                //$newDate = date_format($assignDate,"Y-m-d H:i:sP");
                $myDate = new DateTime(strtotime($date)); 
                $newDate =  $myDate->format('Y-m-d H:i:sP');*/

               // echo date_format($date,"Y-m-d H:i:sP");

                $taskInfo = array('branch_id'=> $branch_id,'customer_number'=>$customer_number, 'assigned_Date'=>$date, 'call_status'=> $call_status );

               
                
                $this->load->model('Task_model');
                $result = $this->Task_model->addNewTask($taskInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Task created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task creation failed');
                }
                
                redirect('addNewTask');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldTask($taskId = NULL)
    {
        if($this->isManager() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('taskListing');
            }
            
            //$data['roles'] = $this->Task_model->getUserRoles();
            //$data['branchInfo'] = $this->Task_model->getBranchInfo($branchId);
            $branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo($branchId);
            $data['taskInfo2'] = $this->Task_model->getTaskInfo2($taskId);
            
            $this->global['pageTitle'] = 'CCT | Edit Task';
            
            $this->loadViews("editOldTask", $this->global, $data, NULL);
        }
    }


    function editAdminTask($taskId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('taskListing');
            }
            
            //$data['roles'] = $this->Task_model->getUserRoles();
            //$data['branchInfo'] = $this->Task_model->getBranchInfo($branchId);
            //$branchId = $this->session->branchId;
            $data['branchRecords'] = $this->User_model->branchListing1();
            $data['taskRecords'] = $this->Task_model->getTaskAdminInfo($taskId);
            
            $this->global['pageTitle'] = 'CCT | Edit Task';
            
            $this->loadViews("editAdminTask", $this->global, $data, NULL);
        }
    }

    function editAdminTask2(){

        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');

            
            $this->form_validation->set_rules('b_id','b_id','trim|required|max_length[128]');
            //$this->form_validation->set_rules('customer_number	','customer_number','trim|required|max_length[2000]');
            //$this->form_validation->set_rules('assigned_date','assigned_date','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editAdminTask($t_id);
            }
            else
            {
                $b_id = $this->input->post('b_id');
                


                $taskInfo = array('branch_id'=> $b_id);
                
                $this->load->model('Task_model');

                $result = $this->Task_model->editAdminTask($taskInfo, $t_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
            }
        }

    }
    
    function editOldCallTask($taskId = NULL)
    {
        if($this->isEmployee() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('teleAssignedTasks');
            }
            
            //$data['roles'] = $this->Task_model->getUserRoles();
            //$data['callStatus'] = $this->Task_model->getCallInfo($branchId);
            
            $data['taskInfo3'] = $this->Task_model->getTaskInfo3($taskId);
            $data['taskInfo4'] = $this->Task_model->getTaskInfo4();
            
            

            
            $this->global['pageTitle'] = 'CCT |  Edit Task';
            
            $this->loadViews("editOldCallTask", $this->global, $data,NULL);
        }
    }

    
    /**
     * This function is used to edit the user information
     */
    function editTask()
    {
        if($this->isManager() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');

            
            $this->form_validation->set_rules('emp_id','emp_id','trim|required|max_length[128]');
            //$this->form_validation->set_rules('customer_number	','customer_number','trim|required|max_length[2000]');
            //$this->form_validation->set_rules('assigned_date','assigned_date','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editOldTask($t_id);
            }
            else
            {
                $emp_id = $this->input->post('emp_id');
                $customer_number = $this->input->post('customer_number');
                $assigned_date = $this->input->post('assigned_date');

                //$date1 = strtr($_REQUEST['assigned_date'], '/', '-');

                //$myDate = date($assigned_date);

                $date = date('Y-m-d', strtotime($assigned_date));


                $taskInfo = array('emp_id'=> $emp_id,'customer_number'=>$customer_number, 'assigned_date'=>$date);
                
                $this->load->model('Task_model');
                $result = $this->Task_model->editTask($taskInfo, $t_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
            }
        }
    }

    function editTeleCallTask(){

        if($this->isManager() == FALSE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');

            
            $this->form_validation->set_rules('t_id','t_id','trim|required|max_length[128]');
            //$this->form_validation->set_rules('call_status	','call_status','trim|required|max_length[1]');
            //$this->form_validation->set_rules('assigned_date','assigned_date','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editOldTask($t_id);
            }
            else
            {

                $assigned_date = $this->input->post('assigned_date');
                $call_status = $this->input->post('call_status');
                $date1 = $this->input->post('callDate');
                $payment = $this->input->post('payment');
                

                $complete =  date('Y-m-d H:i:sP');
                
                $callDate = date('Y-m-d H:i:sP', strtotime($date1));
                
                if($call_status == 3){

                $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status, 'call_on_date'=>$callDate);
                }
                else if( $call_status == 1  || $call_status == 2  || ($call_status >= 4 && $call_status < 7)) {
                   
                    $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status);
                }
                else if($call_status == 7) {

                    $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status, 'completed_date'=>$complete);
                }
                else if($call_status == 8) {

                    $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status, 'receipt_no'=>$payment);
                }

                
                else{
                    $this->session->set_flashdata('error', 'change the call status');
                }
                
                $this->load->model('Task_model');
                $result = $this->Task_model->editTask($taskInfo, $t_id);


                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                /*$this->load->library('user_agent');
                    if ($this->agent->is_referral())
                        {
                        redirect( $this->agent->referrer());
                        }*/
                //redirect($_SERVER['HTTP_REFERER']);
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
                  
            }
        }

    }


    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteTask()
    {
        if($this->isManager() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $t_id = $this->input->post('taskid');
            $taskInfo = array('isDeleted'=>1);
            
            $result = $this->Task_model->deleteTask($t_id, $taskInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }


    

    
   
}

?>