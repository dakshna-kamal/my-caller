<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<HTML>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/fontawesome.css" rel="stylesheet">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900"
        rel="stylesheet">

    <title>Form Validation</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/css/owl.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/css/lightbox.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/frontend/css/montserrat-font.css">
    <link rel="stylesheet" type="text/css"
        href="<?php echo base_url(); ?>assets/frontend/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <!-- Main Style Css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/frontend/css/style.css" />

</head>

<body class="form-v10">


    <!--header-->

    <header class="main-header clearfix" role="header">
        <div class="logo">


        </div>
        <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
        <nav id="menu" class="main-nav" role="navigation">
            <ul class="main-menu">
                <li><a href="#section1">Home</a></li>
                <li class="has-submenu"><a href="#section2">About Us</a>
                    <ul class="sub-menu">
                        <li><a href="#section2">Who we are?</a></li>
                        <li><a href="#section3">What we do?</a></li>
                        <li><a href="#section3">How it works?</a></li>
                        <li><a href="https://templatemo.com/about" rel="sponsored" class="external">External URL</a>
                        </li>
                    </ul>
                </li>
                <li><a href="#section4">Courses</a></li>
                <!-- <li><a href="#section5">Video</a></li> -->
                <li><a href="#section6">Contact</a></li>
                <li><a href="https://templatemo.com" class="external">External</a></li>
            </ul>
        </nav>
    </header>


    <div class="page-content">
        <div class="form-v10-content">
            <form class="form-detail" action="#" method="post" id="myform">
                <div class="form-left">
                    <h2>General Infomation</h2>
                    <div class="form-row">
                        <select name="title">
                            <option class="option" value="title">Title</option>
                            <option class="option" value="businessman">Businessman</option>
                            <option class="option" value="reporter">Reporter</option>
                            <option class="option" value="secretary">Secretary</option>
                        </select>
                        <span class="select-btn">
                            <i class="zmdi zmdi-chevron-down"></i>
                        </span>
                    </div>
                    <div class="form-group">
                        <div class="form-row form-row-1">
                            <input type="text" name="first_name" id="first_name" class="input-text"
                                placeholder="First Name" required>
                        </div>
                        <div class="form-row form-row-2">
                            <input type="text" name="last_name" id="last_name" class="input-text"
                                placeholder="Last Name" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <select name="position">
                            <option value="position">Position</option>
                            <option value="director">Director</option>
                            <option value="manager">Manager</option>
                            <option value="employee">Employee</option>
                        </select>
                        <span class="select-btn">
                            <i class="zmdi zmdi-chevron-down"></i>
                        </span>
                    </div>
                    <div class="form-row">
                        <input type="text" name="company" class="company" id="company" placeholder="Company" required>
                    </div>
                    <div class="form-group">
                        <div class="form-row form-row-3">
                            <input type="text" name="business" class="business" id="business"
                                placeholder="Business Arena" required>
                        </div>
                        <div class="form-row form-row-4">
                            <select name="employees">
                                <option value="employees">Employees</option>
                                <option value="trainee">Trainee</option>
                                <option value="colleague">Colleague</option>
                                <option value="associate">Associate</option>
                            </select>
                            <span class="select-btn">
                                <i class="zmdi zmdi-chevron-down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-right">
                    <h2>Contact Details</h2>
                    <div class="form-row">
                        <input type="text" name="street" class="street" id="street" placeholder="Street + Nr" required>
                    </div>
                    <div class="form-row">
                        <input type="text" name="additional" class="additional" id="additional"
                            placeholder="Additional Information" required>
                    </div>
                    <div class="form-group">
                        <div class="form-row form-row-1">
                            <input type="text" name="zip" class="zip" id="zip" placeholder="Zip Code" required>
                        </div>
                        <div class="form-row form-row-2">
                            <select name="place">
                                <option value="place">Place</option>
                                <option value="Street">Street</option>
                                <option value="District">District</option>
                                <option value="City">City</option>
                            </select>
                            <span class="select-btn">
                                <i class="zmdi zmdi-chevron-down"></i>
                            </span>
                        </div>
                    </div>
                    <div class="form-row">
                        <select name="country">
                            <option value="country">Country</option>
                            <option value="Vietnam">Vietnam</option>
                            <option value="Malaysia">Malaysia</option>
                            <option value="India">India</option>
                        </select>
                        <span class="select-btn">
                            <i class="zmdi zmdi-chevron-down"></i>
                        </span>
                    </div>
                    <div class="form-group">
                        <div class="form-row form-row-1">
                            <input type="text" name="code" class="code" id="code" placeholder="Code +" required>
                        </div>
                        <div class="form-row form-row-2">
                            <input type="text" name="phone" class="phone" id="phone" placeholder="Phone Number"
                                required>
                        </div>
                    </div>
                    <div class="form-row">
                        <input type="text" name="your_email" id="your_email" class="input-text" required
                            pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}" placeholder="Your Email">
                    </div>
                    <div class="form-checkbox">
                        <label class="container">
                            <p>I do accept the <a href="#" class="text">Terms and Conditions</a> of your site.</p>
                            <input type="checkbox" name="checkbox">
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <div class="form-row-last">
                        <input type="submit" name="register" class="register" value="Register Badge">
                    </div>
                </div>
            </form>
        </div>
    </div>




    <script src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>
</body>



</html>