<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Import_model extends CI_Model
{

    function importdata($inserdata)
	{
		$this->db->trans_start();
		$this->db->insert_batch("import_data", $inserdata);
        
		$this->db->trans_complete();
	}

}    