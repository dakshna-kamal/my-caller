<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Html;

class Import extends CI_Controller {

	
    public function __construct(){
        
        parent::__construct();
        $this->load->model ( 'import_model' );
    }

    public function index(){
        $this->load->view('spreadsheet');
        $this->load->helper('form');
        $this->load->helper('url');
    }

    public function importData(){

        $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    
        if(isset($_FILES['upload_file']['name']) && in_array($_FILES['upload_file']['type'], $file_mimes)) {
        
            $arr_file = explode('.', $_FILES['upload_file']['name']);
            $extension = end($arr_file);
            
            if('csv' == $extension){
                
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            }
            elseif('xls' == $extension){
                
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();

            }else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();

    
            }

            $spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
            $sheetData = $spreadsheet->getActiveSheet()->toArray();

            if (!empty($sheetData)) {

                for ($i=1; $i<count($sheetData); $i++) {

                    $inserdata[$i]['name'] = $sheetData[$i][0];
                    $inserdata[$i]['phone'] = $sheetData[$i][1];
                    $inserdata[$i]['email']= $sheetData[$i][2];
                    $inserdata[$i]['address']= $sheetData[$i][3];
                    $inserdata[$i]['status']= $sheetData[$i][4];

                    $date = str_replace("/", ".", $sheetData[$i][5]);
                    $created_date = date("Y-m-j", strtotime($date));

                    $inserdata[$i]['createdOn']  = $created_date;

                }
            }

            $this->import_model->importdata($inserdata);

            if(!empty($inserdata)){
            echo("<script>alert('Data Uploaded successfully')</script> ");

            }else{
                echo("<script>alert('Data Uploaded Error')</script> ");
            } 
        
        }   
            
    } 
}
