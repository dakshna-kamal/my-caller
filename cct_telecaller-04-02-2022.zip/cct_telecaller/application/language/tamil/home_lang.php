<?php
$lang['tele_caller_application'] = 'தொலைபேசி அழைப்பாளர் விண்ணப்பம்';
$lang['signIn'] = 'உள்நுழையவும்';
$lang['username'] = 'பயனர்பெயர்';
$lang['password'] = 'கடவுச்சொல்';


?>