<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Volunteer_model extends CI_Model
{
    
    /**
     * This function used to check the login credentials of the user
     * @param string $email : This is email of the user
     * @param string $password : This is encrypted password of the user
     */



    //SELECT cct_login.username,cct_login.password, cct_emp_details.emp_name, cct_roles.rolename FROM ((cct_login INNER JOIN cct_emp_details ON cct_emp_details.emp_id = cct_login.u_id) INNER JOIN cct_roles ON cct_emp_details.role_id = cct_roles.roleId);

    /**
     * This function used to check email exists or not
     * @param {string} $email : This is users email id
     * @return {boolean} $result : TRUE/FALSE
     */
    function checkEmailExist($email)
    {
        $this->db->select('v_id');
        $this->db->where('v_email', $email);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get('cct_volunteer_details');

        if ($query->num_rows() > 0){
            return TRUE;
        } else {
            return FALSE;
        }
    }

   function insert_signature($image)
{

	$check=$this->get_signs();
	if($check==0)
	{
		$data=array(
			'name'=>$_POST['signname'],
			'img'=>$image,
			'rowno'=>$_POST['rowno'],
			'append'=>$_POST['appendcount']
			);

		$this->db->insert('signature', $data);
	}
	else
	{

		$data=array(
			'name'=>$_POST['signname'],
			'img'=>$image,		
			);

		$this->db
		      ->where('rowno',$_POST['rowno'])
		      ->where('append',$_POST['appendcount'])
		     ->update('signature', $data);



	}

	return ($this->db->affected_rows()!=1)?false:true;
}



function insert_single_signature($image)
{

	$check=$this->get_single_signs();
	if($check==0)
	{
		$data=array(			
			'img'=>$image,
			'rowno'=>$_POST['rowno']		
			);

		$this->db->insert('signature', $data);
	}
	else
	{

		$data=array('img'=>$image);

		$this->db
		      ->where('rowno',$_POST['rowno'])		
		     ->update('signature', $data);



	}

	return ($this->db->affected_rows()!=1)?false:true;
}





 function get_signs()
{
	$datas=array(
			'rowno'=>$_POST['rowno'],
			'append'=>$_POST['appendcount']
		);

	return $this->db->get_where('signature',$datas)->num_rows();
	

}

 function get_single_signs()
{
	$datas=array(
			'rowno'=>$_POST['rowno']			
		);

	return $this->db->get_where('signature',$datas)->num_rows();
	

}


    /**
     * This function used to insert reset password data
     * @param {array} $data : This is reset password data
     * @return {boolean} $result : TRUE/FALSE
     */
 
     
function updateVolunteer($file){

        $this->db->where('v_id', '1');
        $this->db->update('cct_volunteer_details', $file);
        
        return TRUE;
}

function addVolunteer($userInfo){

	$this->db->trans_start();
	$this->db->insert('cct_volunteer_details', $userInfo);
	$insert_id = $this->db->insert_id();
	$this->db->trans_complete();
	return $insert_id;
		
	
}

function verifyOTP($v_id, $OTP){

	$this->db->select('id');
	$this->db->from('otp_auth');
    $this->db->where('v_id', $v_id);
	$this->db->where('token', $OTP);
	$query = $this->db->get();
    $count1 =  count ( $query->result () );
    //return count ( $query->result () );

    if($count1 > 0){
       
        $status = array('status' => '1');
        $this->db->where('v_id', $v_id);
        $this->db->update('cct_volunteer_details', $status);
        return TRUE;
    }

}




function sendEmail($email, $fname, $v_id){

		$from = "kamalakannan.cct@gmail.com";    
        $digits = 6;
        $token =  rand(pow(10, $digits-1), pow(10, $digits)-1);

        $subject = 'Verify Your OTP: '.$token;
        
        //sending confirmEmail($receiver) function calling link to the user, inside message body
        $message = 'Dear: '.$fname.' <br> Thank your registered our portal. <br> Your OTP Number: '.$token .'</a><br><br>Thanks<br> Team Management';
        
        
        
        //config email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.gmail.com';
        $config['smtp_port'] = '465';
        $config['smtp_user'] = $from;
        $config['smtp_pass'] = 'K@mal543';  //sender's password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = 'TRUE';
        $config['newline'] = "\r\n"; 
        
        $this->load->library('email', $config);
		$this->email->initialize($config);
        //send email
        $this->email->from($from);
        $this->email->to($email);
        $this->email->subject($subject);
        $this->email->message($message);
        
        if($this->email->send()){
			//for testing
           /* echo "sent to: ".$receiver."<br>";
			echo "from: ".$from. "<br>";
			echo "protocol: ". $config['protocol']."<br>";
			echo "message: ".$message;*/

         $data1 = array(
                'v_id' => $v_id,
                'token' => $token
             
        );
                
        $this->db->insert('otp_auth',$data1);

        return true;
        }else{
            echo "email send failed";
            return false;
        }

}

function volunteerListingCount1(){

    $this->db->select ( "v_id" );
    $this->db->where ( "isDeleted", 0 );
    //$this->db->where ( "status", 1 );
  
    $query = $this->db->get ( "cct_volunteer_details" );
    
    return count ( $query->result () );

}


function volunteerListingCount($searchText)
    {
        
        $this->db->select('v_id, v_name, v_email, v_phone, v_address, Created_date, status');
        $this->db->from('cct_volunteer_details');
       
        if(!empty($searchText)) {
            $likeCriteria = "(v_name  LIKE '%".$searchText."%'
                            OR  v_email  LIKE '%".$searchText."%'
                            OR  v_phone  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('isDeleted', 0);
        //$this->db->where('status', 1);
       
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function volunteerListing($searchText, $page, $segment)
    {
        /*$this->db->select('BaseTbl.u_id, BaseTbl.username, BaseTbl.name, BaseTbl.mobile, Role.role');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/

        $this->db->select('v_id, v_name, v_email, v_phone, v_address, Created_date, status');
        $this->db->from('cct_volunteer_details');
       
        if(!empty($searchText)) {
            $likeCriteria = "(v_name  LIKE '%".$searchText."%'
                            OR  v_email  LIKE '%".$searchText."%'
                            OR  v_phone LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('isDeleted', 0);
        //$this->db->where('status', 1);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function volunteerPdf($v_id)
	{
		$this->db->where('v_id', $v_id);
		$data = $this->db->get('cct_volunteer_details');
		$output = '<table width="100%" cellspacing="5" cellpadding="5">';
        $base = '<?php echo base_url()?>';
		foreach($data->result() as $row)
		{
			$myDate = $row->Created_date;
            $rdate = date("d-m-Y", strtotime($myDate));
            $output .= '
			<tr>
				
               
				<td width="75%">
					<p><b>ID : </b>'.$row->v_id.'</p>
					<p><b>Name : </b>'.$row->v_name.'</p>
					
                    <p><b>Phone : </b>'.$row->v_phone.'</p>
                    <p><b>Registered Date : </b>'.$rdate.'</p>
                    
                    
					
				</td>
                
                <td width="25%"><p><b>Yours Faithfully,</b><p><img src= "data:image/png;base64,'.base64_encode($row-> imageData).'" width=75%; /> </td>
			</tr>
			';
		}
		
		$output .= '</table>';
		return $output;
	}

    function deleteVolunteer($userId, $userInfo)
    {
        $this->db->where('v_id', $userId);
        $this->db->update('cct_volunteer_details', $userInfo);
        
        return $this->db->affected_rows();
    }


}



?>