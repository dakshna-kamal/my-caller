<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Profile_model extends CI_Model
{
    function addNewProfile($profileInfo)
    {
        $this->db->trans_start();
        $this->db->insert('profile', $profileInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

}