<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

class Profile extends BaseController {

	public function __construct()
    {
        parent::__construct();
		
        date_default_timezone_set('asia/kolkata');  
		$this->load->model('Profile_model');
		$this->load->helper('url'); 
        
    }
	 public function index()
	{
		
		$this->load->library('form_validation');
        $this->load->library('session');
		
		if (!$this->session->userdata('u_id')){
            redirect('login');
            
        }
        else{
            
            $this->load->view('profile');

        }



	}

	public function logout()
    {
         
        session_destroy();
        redirect('login');

    }

	public function register(){

		$name = 'Siva';
		$fathername = 'Kalaiyamurthy';
		$mothername = 'Sarawathy';
		$DOB = date('Y-m-d');
		$number = '9876543210';
		$a_number = '123456789811';

		$profileInfo = array('name'=>$name,'fathername'=>$fathername,'mothername'=>$mothername, 'DOB'=>$DOB,'number'=>$number, 'a_number'=>$a_number, 'created_date'=>date('Y-m-d H:i:s'));
        $profileId = $this->Profile_model->addNewProfile($profileInfo);
		//$basePath = "uploads/".$profileId;
		$basePath = "uploads/".$profileId;
		$imagePath = "uploads/".$profileId."/images";
		$audioPath = "uploads/".$profileId."/audio";
		$videoPath = "uploads/".$profileId."/video";
		$docPath = "uploads/".$profileId."/documents";
		
		if (!file_exists($basePath)) {
    		mkdir($basePath, 0777, true);
		}
		if (!file_exists($imagePath)) {
    		mkdir($imagePath, 0777, true);
		}
		if (!file_exists($audioPath)) {
    		mkdir($audioPath, 0777, true);
		}
		if (!file_exists($videoPath)) {
    		mkdir($videoPath, 0777, true);
		}
		if (!file_exists($docPath)) {
    		mkdir($docPath, 0777, true);
		}

	}

	public function uploadImage() {   
     
      $data = [];  
     
      $count = count($_FILES['files']['name']);  
      
      for($i=0;$i<$count;$i++){  
      
        if(!empty($_FILES['files']['name'][$i])){  
      
          $_FILES['file']['name'] = $_FILES['files']['name'][$i];  
          $_FILES['file']['type'] = $_FILES['files']['type'][$i];  
          $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];  
          $_FILES['file']['error'] = $_FILES['files']['error'][$i];  
          $_FILES['file']['size'] = $_FILES['files']['size'][$i];  
    
          $config['upload_path'] = 'uploads/';   
          $config['allowed_types'] = 'jpg|jpeg|png|gif';  
          $config['max_size'] = '5000';  
          $config['file_name'] = $_FILES['files']['name'][$i];  
     
          $this->load->library('upload',$config);   
      
          if($this->upload->do_upload('file')){  
            $uploadData = $this->upload->data();  
            $filename = $uploadData['file_name'];  
     
            $data['totalFiles'][] = $filename;  
          }  
        }  
     
      } 
	  
	  	$configVideo['upload_path'] = 'uploads/'; # check path is correct
		$configVideo['max_size'] = '102400';
		$configVideo['allowed_types'] = 'mp4'; # add video extenstion on here
		$configVideo['overwrite'] = FALSE;
		$configVideo['remove_spaces'] = TRUE;
		$video_name = 'sample';
		$configVideo['file_name'] = $video_name;

		$this->load->library('upload', $configVideo);
		$this->upload->initialize($configVideo);

		if (!$this->upload->do_upload('uploadan')) # form input field attribute
		{
			# Upload Failed
			$this->session->set_flashdata('error', $this->upload->display_errors());
			redirect('profile');
		}
		else
		{
			# Upload Successfull
			/*$url = 'assets/gallery/images'.$video_name;
			$set1 =  $this->Model_name->uploadData($url);
			$this->session->set_flashdata('success', 'Video Has been Uploaded');
			redirect('controllerName/method');*/
			//$this->load->view('profile', $data);   
		}
		
		$configAudio['upload_path'] = 'uploads/';
		$configAudio['allowed_types'] = 'mp3';
		$configAudio['max_size'] = '30000';
		$configAudio['file_ext_tolower'] = 'TRUE';
		$configAudio['remove_spaces'] = TRUE;
		$audio_name = 'sample1';
		$configAudio['file_name'] = $audio_name;
		$this->load->library('upload', $configAudio);
		$this->upload->initialize($configAudio);
		

		if (!$this->upload->do_upload('audioUpload')) # form input field attribute
		{
			# Upload Failed
			$this->session->set_flashdata('error', $this->upload->display_errors());
			redirect('login');
		}
		else
		{
			# Upload Successfull
			/*$url = 'assets/gallery/images'.$video_name;
			$set1 =  $this->Model_name->uploadData($url);
			$this->session->set_flashdata('success', 'Video Has been Uploaded');
			redirect('controllerName/method');*/
			$this->load->view('profile', $data);   
		}
      //$this->load->view('profile', $data);   
   }  




}