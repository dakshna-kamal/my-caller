<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = "login";
$route['profile'] = "profile";
$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['logout'] = 'profile/logout';

$route['register'] = 'profile/register';
$route['uploadImage'] = 'profile/uploadImage';

$route['uploadImage/post']['post'] = "profile/uploadImage";  





$route['404_override'] = 'error';