<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Donor_model extends CI_Model
{
    
    /**
     * This function used to check the login credentials of the user
     * @param string $email : This is email of the user
     * @param string $password : This is encrypted password of the user
     */



    //SELECT cct_login.username,cct_login.password, cct_emp_details.emp_name, cct_roles.rolename FROM ((cct_login INNER JOIN cct_emp_details ON cct_emp_details.emp_id = cct_login.u_id) INNER JOIN cct_roles ON cct_emp_details.role_id = cct_roles.roleId);

    /**
     * This function used to check email exists or not
     * @param {string} $email : This is users email id
     * @return {boolean} $result : TRUE/FALSE
     */
    function checkEmailExist($email)
    {
       
        $this->db->select('id, fname');
        $this->db->from('cct_donor_details');

        $this->db->where('email ', $email);
        $this->db->where('isDeleted', 0);
        //$this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
   
        $result = $query->row();
        
        return $result;
        //return array();
           

     
    }

    function sendEmail2($email, $donorId, $donorName){

		$from = "kamalakannan.cct@gmail.com";    
        $digits = 6;
        $token =  rand(pow(10, $digits-1), pow(10, $digits)-1);

        $subject = 'Verify Your OTP: '.$token;
        $date =  date("Y-m-d h:i:sa");
        
        //sending confirmEmail($receiver) function calling link to the user, inside message body
        $message = 'Dear: '.$donorName. '<br> Thank your registered our portal. <br> Your OTP Number: '.$token .'</a><br><br>Thanks<br> Team Management';
        
        
        
        //config email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.gmail.com';
        $config['smtp_port'] = '465';
        $config['smtp_user'] = $from;
        $config['smtp_pass'] = 'K@mal543';  //sender's password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = 'TRUE';
        $config['newline'] = "\r\n"; 
        
        $this->load->library('email', $config);
		$this->email->initialize($config);
        //send email
        $this->email->from($from);
        $this->email->to($email);
        $this->email->subject($subject);
        $this->email->message($message);
        
        if($this->email->send()){
			//for testing
           /* echo "sent to: ".$receiver."<br>";
			echo "from: ".$from. "<br>";
			echo "protocol: ". $config['protocol']."<br>";
			echo "message: ".$message;*/

         $data1 = array(
                'token' => $token,
                'createdDate' => $date,
                'd_id' => $donorId
           
        );
                
        $this->db->insert('donor_otp_auth',$data1);

        return true;
        }else{
            echo "email send failed";
            return false;
        }

}

function checkOTP($v_id, $OTP){

	$this->db->select('id');
	$this->db->from('donor_otp_auth');
    $this->db->where('d_id', $v_id);
	$this->db->where('token', $OTP);
	$query = $this->db->get();
    $count1 =  count ( $query->result () );
    //return count ( $query->result () );
    if($count1 > 0){
    
    return TRUE;}
    else{
        return FALSE;
    }

}

function donationListing($donorId){

    $this->db->select('amount, name, creditDate, mode, id');
    $this->db->from('donor_amount');
       
        /*if(!empty($searchText)) {
            $likeCriteria = "(v_name  LIKE '%".$searchText."%'
                            OR  v_email  LIKE '%".$searchText."%'
                            OR  v_phone LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('isDeleted', 0);
        //$this->db->where('status', 1);
        $this->db->limit($page, $segment);*/

        $this->db->where('d_id', $donorId);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;

}

function donorPdf($v_id)
{
    $this->db->where('id', $v_id);
    $data = $this->db->get('donor_amount');
    $output = '<table width="100%" cellspacing="5" cellpadding="5">';
    $base = '<?php echo base_url()?>';
    foreach($data->result() as $row)
    {
        $myDate = $row->creditDate;
        $rdate = date("d-m-Y", strtotime($myDate));
        $output .= '
        <tr>
            
           
            <td width="75%">
                <p><b>ID : </b>'.$row->id.'</p>
                <p><b>Name : </b>'.$row->name.'</p>
                
                <p><b>Phone : </b>'.$row->amount.'</p>
                <p><b>Registered Date : </b>'.$rdate.'</p>
                
                
                
            </td>
            
            
        </tr>
        ';
    }
    
    $output .= '</table>';
    return $output;
}

  


}



?>