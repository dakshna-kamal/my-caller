-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2021 at 06:05 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ociuproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(30) NOT NULL,
  `menu_title` varchar(50) NOT NULL,
  `menu_description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`, `menu_title`, `menu_description`) VALUES
(1, 'Home', 'Home content', 'home.html'),
(2, 'About', 'About content', 'About.html'),
(3, 'Services', 'Services content', 'services.html'),
(4, 'Portfoio', 'Portfolio content', 'portfolio.html'),
(5, 'Contact us', 'Contact us content', 'Contact.html');

-- --------------------------------------------------------

--
-- Table structure for table `original_users`
--

CREATE TABLE `original_users` (
  `ousers_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `original_users`
--

INSERT INTO `original_users` (`ousers_id`, `email`, `phone`) VALUES
(1, 'dakshan.kamal@gmail.com', 6374245092),
(2, 'kamal.pothys@gmail.com', 9042964656);

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `submenu_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_name` varchar(30) NOT NULL,
  `submenu_description` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`submenu_id`, `menu_id`, `submenu_name`, `submenu_description`) VALUES
(1, 2, 'Department', 'department.html'),
(2, 3, 'Information', 'Information.html'),
(3, 2, 'Crime', 'crime.html'),
(4, 2, 'LAD', 'lad.html');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  `phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `department`, `created_date`, `phone`) VALUES
(3, 'kamal', 'kk@gmail.com', 'kamal123', 'Designer', '2021-03-16', '123456'),
(4, 'kamalakannan', 'kamal.pothys@gmail.com', '123466', 'manager', '2021-03-26', '123456'),
(5, 'Kamalakannan', 'kk@gmail.com', 'Media001', 'designer', '2021-03-26', '7296479684'),
(6, 'Kannan', 'kkkk2@gg.com', 'kkka;sd', 'manager', '2021-03-26', '7296479684'),
(7, 'Kannan', 'kkkk2@gg.com', 'kkka;sd', 'manager', '2021-03-26', '7296479684'),
(8, 'Kamalakannan', 'K@ggmp-a', 'sdfsdf', 'manager', '2021-03-26', '7296479684'),
(9, 'fgdfg', 'kk@gmail.com', '133456', 'Select job type', '2021-03-26', '7296479684'),
(10, 'fgdfg', 'kk@gmail.com', '133456', 'Select job type', '2021-03-26', '7296479684'),
(11, 'fgdfg', 'kk@gmail.com', '133456', 'Select job type', '2021-03-26', '7296479684'),
(12, 'fgdfg', 'kk@gmail.com', '123', 'manager', '2021-03-26', '7296479684'),
(13, 'Kamalakannan', 'kk@gmail.com', '123456', 'manager', '2021-03-26', '7844798'),
(14, 'Kamalakannan', 'kk@gmail.com', '123456', 'manager', '2021-03-26', '7844798'),
(15, 'kama', 'sd@dd.cof', 'kamal134', 'designer', '2021-03-26', '7296479684'),
(16, 'kama', 'sd@dd.cof', 'kamal134', 'designer', '2021-03-26', '7296479684'),
(17, 'kama', 'K@ggmp-a', 'vfmQNbvvDzySB35', 'manager', '2021-03-26', '7296479684'),
(18, 'kama', 'K@ggmp-a', 'vfmQNbvvDzySB35', 'manager', '2021-03-26', '7296479684'),
(19, 'Kamalakannan', 'dakshna.kamal@gmail.com', 'kama12345', 'designer', '2021-03-26', '133789'),
(20, 'Kamalakannan', 'dakshna.kamal@gmail.com', 'kama12345', 'designer', '2021-03-26', '133789'),
(21, 'Kamalakannan', 'kk@gmail.com', 'kamal123', 'accounting', '2021-03-26', '12334589'),
(22, 'kamal', 'kk@gmail.com', '4b22df6c69959c91fd89b512d0d1f4f7', 'manager', '2021-03-26', '145566'),
(23, 'rajesh', 'kk@gmail.com', 'cac5ff630494aa784ce97b9fafac2500', 'designer', '2021-03-26', '7844798'),
(24, 'kkannn', 'k@gg.com', '7f58341b9dceb1f1edca80dae10b92bc', 'designer', '2021-03-27', '7844798'),
(25, 'Guna', 'gg@gmail.com', '937eae9b0ee86a37fa75dbb5cf94abd1', 'manager', '2021-03-27', '12346788'),
(26, 'Mano', 'mm@gmail.com', 'd1e6b917e2b99d7e4a94d0390b84e304', 'accounting', '2021-03-30', '726489987');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `original_users`
--
ALTER TABLE `original_users`
  ADD PRIMARY KEY (`ousers_id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`submenu_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `original_users`
--
ALTER TABLE `original_users`
  MODIFY `ousers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `submenu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
