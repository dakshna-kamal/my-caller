<?php
#defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function __construct(){
        parent::__construct();
    }
    
    public function designation()
	{
		$this->db->select("*");
		$this->db->from("designation");
		$q=$this->db->get();
		$res=$q->result();
		return $res;
		
		//$this->load->view('register');
	}

    public function user(){
        
        
		
		$q=$this->db->query("select username from users");
		$res=$q->result();
		return $res;
		
		//$this->load->view('register');
	
    }
	
}
