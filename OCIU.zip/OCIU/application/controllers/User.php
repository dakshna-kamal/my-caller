<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __constuct(){

        parent::__construct();
        if($_SESSION['user_logged'] == FALSE){
            redirect("auth/login");
            $this->session->set_flashdata("error", "Please login first to view this page!!");
        }
    }
    
    public function profile(){
        $this->load->view('profile');

        if($_SESSION['user_logged'] == FALSE){
            redirect("auth/login");
        }

        /*session_start();
        if($_SESSION['user_logged'] == TRUE){
            
            if(time()-$_SESSION['login_time_stamp'] > 600){
                unset($_SESSION);
                session_destroy();
                redirect("auth/login", "refresh");
            }
        }*/

    }

    public function logout(){
        
        unset($_SESSION);
        session_destroy();
        redirect("auth/login", "refresh");
    }



}
