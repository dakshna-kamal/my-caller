<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {


    public function logout(){
        
        unset($_SESSION);
        session_destroy();
        redirect("auth/login", "refresh");
    }



	public function login()
	{
		
        $this->form_validation->set_rules('username','Username', 'required');
        $this->form_validation->set_rules('password','Password', 'required|min_length[6]');
        
        if($this->form_validation->run() == TRUE){
            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $this->db->select('*');
            $this->db->from('users');
            $this->db->where(array ('username'=>$username, 'password'=>$password));
            $query = $this->db->get();
            
            $user = $query->row();

            if($user->email){
              $this->session->set_flashdata("success", 'You are loggged in '); 
              
              $_SESSION['user_logged'] = TRUE;
              $_SESSION['username'] = $user->username;

              redirect('user/profile', 'refresh');
              
            }else{
                $this->session->set_flashdata('error', "No such account details exits in database");
                redirect('auth/login', 'refresh');
            }

        }

        $this->load->view("login");


	}

    public function register()
	{   

        if(isset($_POST['register'])){
            $this->form_validation->set_rules('username','Username', 'required');
            $this->form_validation->set_rules('email','Email', 'required');
            $this->form_validation->set_rules('password','Password', 'required|min_length[6]');
            $this->form_validation->set_rules('password2','Cofirm password', 'required|min_length[6]|matches[password]');
            $this->form_validation->set_rules('phone','Phone', 'required');

            $data = array(

                'username'=>$_POST['username'],
                'password'=>md5($_POST['password']),
                'email'=>$_POST['email'],
                'phone'=>$_POST['phone'],
                'department'=>$_POST['department'],
                'created_date'=>date('Y-m-d')
            );

          /*  $username = $_POST['username'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];

            $this->db->select('*');
            $this->db->from('users');
            $this->db->where(array('username'=> $username));
            $query1 = $this->db->get();

            $this->db->select('*');
            $this->db->from('orgial_users');
            $this->db->where(array('email'=> $email, 'phone'=>$phone));
            $query2 = $this->db->get();

            echo "query2";*/
            
            //if form validation true  

            if($this->form_validation->run() == TRUE){
                echo "form validated";
                
                
                $this->db->insert('users', $data);
                $this->session->set_flashdata("success", "Your account has been registerd, You can Login now");
                redirect("auth/register","refresh");
                
                
            }
        }

        
        $data=array();
		$this->load->model('Menu_model');
		$data['designation']=$this->Menu_model->designation();
		$this->load->view('register',$data);


	}

    public function userValidate(){
        $data=array();
		$this->load->model('Menu_model');
        $data['username']=$this->Menu_model->user();
		$this->load->view('register',$data);

    }
}
