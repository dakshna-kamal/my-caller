<?php
$lang['tele_caller_application'] = 'Tele Caller Application';

$lang['TelecallerApp'] = 'CCT Tele Caller App';

$lang['SignIn'] = 'Sign In';
$lang['SignIn2'] = 'Sign In';
$lang['Username'] = 'Username';
$lang['Password'] = 'Password';
$lang['TeleCallerDashboard'] = 'Tele Caller Dashboard';

$lang['Dashboard'] = 'Dashboard';

$lang['AssignedTaskforToday'] = 'Assigned Task for Today';

$lang['PastPendingTask'] = 'Past Pending Task'; 

$lang['PaymentDetails'] = 'Payment Details'; 

$lang['ReminderCalls'] = 'Reminder Calls'; 
$lang['Reports2'] = 'Reports';
$lang['BranchInformation'] = 'Branch Information';

$lang['ReminderCalls2'] = 'Reminder Calls'; 

$lang['AssignedTaskforToday2'] = 'Assigned Task for Today';


$lang['PastPendingTask2'] = 'Past Pending Task';  
$lang['CompletedTaskToday'] = 'Completed Task Today';  
 


$lang['ReminderCallList'] = 'Reminder Call List';

$lang['Reports2'] = 'Reports'; 
$lang['Info'] = 'Info';
$lang['Moreinfo'] = 'More info';

$lang['Tasks'] = 'Tasks';

$lang['CustomerNumber'] = 'Customer Number';
$lang['CallStatus'] = 'Call Status';
$lang['Assigneddate'] = 'Assigned date';
$lang['Actions'] = 'Actions';

$lang['PhoneNumber'] = 'Phone Number';
$lang['PaymentId'] = 'Payment Id';
$lang['PaymentDetails'] = 'Payment Details';
$lang['Paymentdate'] = 'Payment Date';

$lang['CallonDate'] = 'Call on Date';
$lang['TaskReport'] = 'Task Report';

$lang['SelectDate'] = 'Select Date';
$lang['MonthlyReport'] = 'Monthly Report';
$lang['DateRangereport'] = 'Date Range report';

$lang['SelectMonth'] = 'Select Month';

$lang['StartDate'] = 'Start Date';
$lang['EndDate'] = 'End Date';

$lang['Submit'] = 'Submit';


$lang['Completed'] = 'Completed';
$lang['InCompleted'] = 'InCompleted';
$lang['Payment'] = 'Payment';

$lang['RemindercallsnotificationssentManager'] = 'Reminder calls notifications sent Manager';
$lang['UpdateCallTaskManagement'] = 'Update Call Task Management';
$lang['UpdatePaymentDetails'] = 'Update Payment Details';

$lang['PaymentInfo'] = 'Payment Info';








?>