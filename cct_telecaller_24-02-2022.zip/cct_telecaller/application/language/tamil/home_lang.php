<?php
$lang['tele_caller_application'] = 'தொலைபேசி அழைப்பாளர் செயலி';

$lang['TelecallerApp'] = 'CCT செயலி';

$lang['SignIn'] = 'உள்நுழையவும்';
$lang['Username'] = 'பயனர்பெயர்';
$lang['Password'] = 'கடவுச்சொல்';

$lang['SignIn2'] = 'உள்நுழை';

$lang['TeleCallerDashboard'] = 'தொலைபேசி அழைப்பாளர் தகவல் பலகை';

$lang['Dashboard'] = 'தகவல் பலகை';


$lang['AssignedTaskforToday'] = 'இன்றைய ஒதுக்கப்பட்ட<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; பணிகள்';
$lang['AssignedTaskforToday2'] = 'இன்றைய ஒதுக்கப்பட்ட பணிகள்';

$lang['PastPendingTask'] = 'நிறைவுப்பெறாதப்<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; பணிகள்';
$lang['PastPendingTask2'] = 'நிறைவுப்பெறாதப் பணிகள்';  
$lang['CompletedTaskToday'] = 'இன்றைய நிறைவுப்பெற்றப் பணிகள்';  
 

$lang['PaymentDetails'] = 'கட்டண விவரங்கள்'; 

$lang['ReminderCalls'] = 'நினைவூட்டல்<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; தொலைபேசி';

$lang['ReminderCallList'] = 'நினைவூட்டல் தொலைபேசி விவரங்கள்';

$lang['Reports2'] = 'அறிக்கை'; 


$lang['BranchInformation'] = ' கிளை விவரங்கள்';

$lang['Moreinfo'] = 'மேலும் தகவல் அறிய';
$lang['Info'] = 'தகவல்';


$lang['Tasks'] = 'வரிசை எண்';

$lang['CustomerNumber'] = 'வாடிக்கையாளர் எண்';

$lang['CallStatus'] = 'அழைப்பு நிலை';

$lang['Assigneddate'] = 'ஒதுக்கப்பட்ட நாள்';

$lang['Actions'] = 'செயல்கள்';
$lang['PhoneNumber'] = 'தொலைபேசி எண்';

$lang['PaymentId'] = 'கட்டண எண்';
$lang['PaymentDetails'] = 'கட்டண விவரங்கள்';
$lang['Paymentdate'] = 'கட்டண நாள்';
$lang['CallonDate'] = 'அழைக்க வேண்டிய நாள்';

$lang['ReminderCalls2'] = 'நினைவூட்டல் தொலைபேசி';

$lang['TaskReport'] = 'பணி அறிக்கை';

$lang['SelectDate'] = 'தேதியைத் தேர்ந்தெடு';

$lang['MonthlyReport'] = 'மாதாந்திர';
$lang['DateRangereport'] = 'தேதி வரம்பு';

$lang['SelectMonth'] = 'மாதங்கள்';

$lang['StartDate'] = 'தொடக்க தேதி';
$lang['EndDate'] = 'முடிவு தேதி';

$lang['Submit'] = 'சமர்ப்பிக்கவும்';

$lang['Completed'] = 'நிறைவு';
$lang['InCompleted'] = 'முழுமையடையாத';
$lang['Payment'] = 'கட்டணம்';


$lang['RemindercallsnotificationssentManager'] = 'நினைவூட்டல் அழைப்புகள் மேலாளருக்கு அறிவிக்கப்பட்டது';

$lang['UpdateCallTaskManagement'] = 'அழைப்பு பணிப் புதுப்பிக்கவும்';

$lang['UpdatePaymentDetails'] = 'கட்டண விவரங்களைப் புதுப்பிக்கவும்';

$lang['PaymentInfo'] = 'கட்டண விவரங்கள்';
























/*$lang['UploadedTaskDetails'] = 'பதிவேற்றப்பட்ட பணிகளின் விவரங்கள்';
$lang['RequestTaskDetails'] = 'கோரிக்கை பணிகளின் விவரங்கள்';
$lang['EscalatedTask'] = 'செறிவு நிலை பணிகளின் விவரங்கள்';
$lang['AssignedTask'] = 'ஒதுக்கப்பட்ட பணிகளின் விவரங்கள்';
$lang['CompletedTask'] = 'முழுமைப்பெற்ற பணிகளின் விவரங்கள்';
$lang['Reports'] = 'அறிக்கை விவரங்கள் பற்றிய';
$lang['Info'] = 'தகவல்';


$lang['UploadedTasks'] = 'பதிவேற்றப்பட்ட<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; பணிகள்';

$lang['RequestTasks'] = 'கோரிக்கை <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;பணிகள்';
$lang['EscalatedTasks'] = 'செறிவு நிலை<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; பணிகள்';
$lang['Report'] = 'அறிக்கை';

$lang['Moreinfo'] = 'மேலும் தகவல் அறிய';*/


?>