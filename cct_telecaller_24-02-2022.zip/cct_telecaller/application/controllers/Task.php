<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Task extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Task_model');
        $this->load->model('User_model');
        
        $this->isLoggedIn(); 
        date_default_timezone_set('asia/kolkata');
        $branchId = 0;
       
    }


    function taskListing($branchId = NULL){
        
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){

            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            $branchId = $this->security->xss_clean($this->input->post('branch_Id'));

            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
           
            $this->load->library('pagination');

            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
             
            $data['branchRecords'] = $this->User_model->branchListing1();
            
            $this->global['pageTitle'] = 'CCT |  Task Details';   
        
            $count = $this->Task_model->taskListingCount($searchText); 

            $returns = $this->paginationCompress("taskListing/", $count, 10);

            $data['taskRecords'] = $this->Task_model->taskListing($searchText, $returns['page'], $returns['segment']);
           
            $this->loadViews("taskList", $this->global, $data, NULL);

        }
    }


    function searchTaskListing(){
        
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){

            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            
            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
                      
                         
            $this->load->library('pagination');

            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
             
            $data['branchRecords'] = $this->User_model->branchListing1();
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
        
            $count = $this->Task_model->searchTaskListingCount($searchText); 
            
            $returns = $this->paginationCompress("searchTaskListing/", $count, 10);

            $data['serachRecords'] = $this->Task_model->searchTaskListing($searchText, $returns['page'], $returns['segment']);
           
            $this->loadViews("serachTask", $this->global, $data, NULL);

        }
    }


    function assignedTeleTask(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                        
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->assignedTeleTaskCount($searchText, $branchId,$getDate);

			$returns = $this->paginationCompress ( "assignedTeleTask/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->assignedTeleTask($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Deatils';
            
            $this->loadViews("assignedTeleTask", $this->global, $data, NULL);

        }
    }

    function submittedTask(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                                     
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->submittedTaskCount($searchText, $branchId,  $getDate);

			$returns = $this->paginationCompress ( "submittedTask/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->submittedTask($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("submittedTask", $this->global, $data, NULL);

        }
    }

    function requestedTask(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                        
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->requestedTaskCount($searchText, $branchId, $getDate);

			$returns = $this->paginationCompress ( "requestedTask/", $count, 10 );
            
            $data['requestTask'] = $this->Task_model->requestedTask($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Deatils';
            
            $this->loadViews("requestTask", $this->global, $data, NULL);

        }
    }

    function responseTask(){
        
        if($this->isDataEntry() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                        
            $this->load->library('pagination');
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            $branchId = $this->session->branchId;
            
            $count = $this->Task_model->responseTaskCount($searchText);

			$returns = $this->paginationCompress ( "responseTask/", $count, 10 );
            
            $data['requestTask'] = $this->Task_model->responseTask($searchText, $branchId, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT |  Task Deatils';
            
            $this->loadViews("responseTask", $this->global, $data, NULL);

        }
    }




    function reminderTaskListingToday(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');


            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->reminderTaskListingTodayCount($searchText, $branchId,  $getDate);

			$returns = $this->paginationCompress ( "reminderTaskListingToday/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->reminderTaskListingToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("todayReminderTasks", $this->global, $data, NULL);

        }
    }

    function escalatedTask(){
        
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){

            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->escalatedTaskCount($searchText, $getDate);

			$returns = $this->paginationCompress ( "escalatedTask/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->escalatedTask($searchText, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("escalatedTask", $this->global, $data, NULL);

        }
    }


    function teleTaskListingToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());

            $count = $this->Task_model->teleTaskListingTodayCount($searchText, $branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "teleTaskListingToday/", $count, 10 );
            
            $data['teleTaskReminderToday'] = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            $data['teleTaskReminderSent'] = $this->User_model->getTeleTaskReminderSent($branchId, $getDate, $userId);
            
            $data['notificationTask'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $data['taskRecords'] = $this->Task_model->teleTaskListingToday($searchText, $returns["page"], $returns["segment"], $branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedTasks", $this->global, $data, NULL);
        }

    } 


    function teleTaskCompletedToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
            
            $count = $this->User_model->getTeleTaskCompleteToday($branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "teleAssignedCompleted/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskCompletedToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedCompleted", $this->global, $data, NULL);
        }

    }


    function telePendingTask(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');

            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->Task_model->teleTaskInCompletedTodayCount($searchText, $branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "telePendingTask/", $count, 10 );

            $data['teleTaskReminderToday'] = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            $data['teleTaskReminderSent'] = $this->User_model->getTeleTaskReminderSent($branchId, $getDate, $userId);
            
            $data['notificationTask'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $data['taskRecords'] = $this->Task_model->teleTaskInCompletedToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("telePendingTask", $this->global, $data, NULL);
        }

    }


    function teleTaskPayment(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());            
           
            $count = $this->Task_model->teleTaskPaymentCount($searchText, $branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "teleTaskPayment/", $count, 10 );

            $data['teleTaskReminderToday'] = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
            $data['teleTaskReminderSent'] = $this->User_model->getTeleTaskReminderSent($branchId, $getDate, $userId);
            
            $data['notificationTask'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $data['taskRecords'] = $this->Task_model->teleTaskPayment($searchText, $returns["page"], $returns["segment"], $branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleTaskPayment", $this->global, $data, NULL);
        }

    }
    
    function telePaymentAssign(){

        if($this->isManager() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());            
           
            $count = $this->Task_model->telePaymentAssignCount($searchText, $branchId, $getDate);

			$returns = $this->paginationCompress ( "telePaymentAssign/", $count, 10 );
            
                        
            $data['taskRecords'] = $this->Task_model->telePaymentAssign($searchText, $returns["page"], $returns["segment"], $branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("telePaymentAssign", $this->global, $data, NULL);
        }

        
    } 


    function telePaymentStatus(){

        if($this->isManager() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());            
           
            $count = $this->Task_model->telePaymentStatusCount($searchText, $branchId, $getDate);

			$returns = $this->paginationCompress ( "telePaymentStatus/", $count, 10 );
            
                        
            $data['taskRecords'] = $this->Task_model->telePaymentStatus($searchText, $returns["page"], $returns["segment"], $branchId,  $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("telePaymentStatus", $this->global, $data, NULL);
        }

    } 


    function accountPaymentProcess(){

        if($this->isAccountant() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;

            $branchId = $this->security->xss_clean($this->input->post('branch_Id'));
                         
            $this->load->library('pagination');

            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url()); 

            $data['branchRecords'] = $this->User_model->branchListing1();           
           
            $count = $this->Task_model->accountPaymentProcessCount($branchId, $getDate);

			$returns = $this->paginationCompress ( "accountPaymentProcess/", $count, 10 );
                        
            $data['taskRecords'] = $this->Task_model->accountPaymentProcess($branchId, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Payment Details';
            
            $this->loadViews("accountPaymentProcess", $this->global, $data, NULL);
        }
    }


    function accountSearchProcess(){

        if($this->isAccountant() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $this->load->library('form_validation'); 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');

            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url()); 

            $data['branchRecords'] = $this->User_model->branchListing1();           
           
            $count = $this->Task_model->accountSearchProcessCount($searchText, $getDate);

			$returns = $this->paginationCompress ( "accountSearchProcess/", $count, 10 );
                        
            $data['taskRecords'] = $this->Task_model->accountSearchProcess($searchText, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Payment Details';
            
            $this->loadViews("accountSerachProcess", $this->global, $data, NULL);
        }
    }
    
    
    function accountPaymentStatus(){

        if($this->isAccountant() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;

            $branchId = $this->security->xss_clean($this->input->post('branch_Id'));
            $data['branchRecords'] = $this->User_model->branchListing1();
                         
            $this->load->library('pagination');
 
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());            
           
            $count = $this->Task_model->accountPaymentStatusCount($branchId, $getDate);

			$returns = $this->paginationCompress ( "accountPaymentStatus/", $count, 10 );
            
                        
            $data['taskRecords'] = $this->Task_model->accountPaymentStatus($branchId, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("accountPaymentStatus", $this->global, $data, NULL);
        }
    }
    
    
    function accountSearchStatus(){

        if($this->isAccountant() == TRUE){
            $this->loadThis();
        }
        else{
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $getDate = date('Y-m-d');
           
            $this->session->set_userdata('previous_url', current_url());            
           
            $count = $this->Task_model->accountSearchStatusCount($searchText, $getDate);

			$returns = $this->paginationCompress ( "accountSearchStatus/", $count, 10 );
            
                        
            $data['taskRecords'] = $this->Task_model->accountSearchStatus($searchText, $returns["page"], $returns["segment"], $getDate);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("accountSearchStatus", $this->global, $data, NULL);
        }
    } 




    function editOldPaymentstatus($p_Id = NULL){

        if($this->isAccountant() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($p_Id == null)
            {
                redirect('accountPaymentProcess');
            }

            $data['paymentStatus'] = $this->Task_model->getPaymentStatus($p_Id);
            $data['paymentStatusList'] = $this->Task_model->getPaymentList();
            
            $this->global['pageTitle'] = 'CCT | Edit Payment Status';
            
            $this->loadViews("editPaymentstatus", $this->global, $data, NULL);
        }
        

    }

    function editPaymentstatus(){

        if($this->isAccountant() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $p_id = $this->input->post('p_id');
            
            $this->form_validation->set_rules('p_id','p_id','trim|required|max_length[128]');

            if($this->form_validation->run() == FALSE)
            {
                $this->editOldPaymentstatus($p_id);
            }
            else
            {
                $status_id = $this->input->post('status_id');
                $notes = $this->input->post('notes');

                if($status_id == 3){

                     $paymentInfo = array('status_id'=> $status_id, 'remarks' => $notes);

                }
                else{

                    $paymentInfo = array('status_id'=> $status_id);
                }

                $result = $this->Task_model->editPaymentStatus($paymentInfo, $p_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
            }
        }



    }



    function submitVerify(){

        if($this->isManager() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $payment_id = $this->input->post('paymentArray');
                       
            $updateArray = array();

                for($i = 0; $i < sizeof($payment_id); $i++)
                {
                    $updateArray[] = array (

                        'payment_id' => $payment_id[$i],
                        'status_id'=> 1,
                        'isSubmitted' => 1

                    );
                }
					
            $result = $this->db->update_batch('payment_details', $updateArray, 'payment_id'); 

            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }

    }


    function teleTaskReminderToday(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            $branchId = $this->session->branchId;
            $userId= $this->session->u_id;
            $getDate = date('Y-m-d');
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->User_model->getTeleTaskReminderToday($branchId, $getDate, $userId);

			$returns = $this->paginationCompress ( "teleAssignedReminder/", $count, 10 );
            
            $data['taskRecords'] = $this->Task_model->teleTaskReminderToday($searchText, $returns["page"], $returns["segment"],$branchId,  $getDate, $userId);
            
            $this->global['pageTitle'] = 'CCT |  Task Details';
            
            $this->loadViews("teleAssignedReminder", $this->global, $data, NULL);
        }

    }


    function teleTaskReports(){

        if($this->isEmployee() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }
            
            $data['records'] = $this->Task_model->tempfun();

            $this->global['pageTitle'] = 'CCT | Report Details';
            $this->loadViews("teleTaskReports", $this->global, $data, NULL);  
        }

    }


    function chartView(){

        $branchId = $this->session->branchId;
        $userId = $this->session->u_id;
        
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'completed';
        $ref2 = 'incompleted';
        $ref3 = 'payment';

        if($dateId == 1)
        {
            
            $completed = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref1);
            $incompleted = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref2);
            $payment = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref3);           
            
        }
        else if($dateId == 2){

            $completed  = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref1);
            $incompleted = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref2);
            $payment = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref3);

        }
        else{

            $completed  = $this->Task_model->teleReportRecords($branchId, $userId, $ref1);
            $incompleted = $this->Task_model->teleReportRecords($branchId, $userId, $ref2);
            $payment = $this->Task_model->teleReportRecords($branchId, $userId, $ref3);
        }
        
        $langCompleted = $this->lang->line('Completed');
        $langInCompleted = $this->lang->line('InCompleted');
        $langPayment = $this->lang->line('Payment');

		$data = array();
            
            $data[0] = array(
				'call'	 =>	$langCompleted,
				'total'	 =>	$completed,
				'color'	 =>	'#006400'
			);
            $data[1] = array(
				'call'	 =>	$langInCompleted,
				'total'	 =>	$incompleted,
				'color'	 =>	'#ff0000'
			);
            $data[2] = array(
				'call'	 =>	$langPayment,
				'total'	 =>	$payment,
				'color'	 =>	'#0000ff'
			);
        
		echo json_encode($data);
	}


    function managerTaskReports(){

        if($this->isManager() == TRUE){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }
            
            $data['records'] = $this->Task_model->tempfun();

            $this->global['pageTitle'] = 'CCT | Report Details';
            $this->loadViews("managerTaskReports", $this->global, $data, NULL);  
        }

    }


    function chartManagerView(){

        $branchId = $this->session->branchId;
                
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'completed';
        $ref2 = 'incompleted';
        $ref3 = 'payment';

        if($dateId == 1)
        {
            
            $completed = $this->Task_model->managerReportRecordsByMonth($branchId, $month, $year, $ref1);
            $incompleted = $this->Task_model->managerReportRecordsByMonth($branchId, $month, $year, $ref2);
            $payment = $this->Task_model->managerReportRecordsByMonth($branchId,  $month, $year, $ref3);           
            
        }
        else if($dateId == 2){

            $completed  = $this->Task_model->managerReportRecordsByDate($branchId, $startdate, $enddate, $ref1);
            $incompleted = $this->Task_model->managerReportRecordsByDate($branchId, $startdate, $enddate, $ref2);
            $payment = $this->Task_model->managerReportRecordsByDate($branchId, $startdate, $enddate, $ref3);

        }
        else{

            $completed  = $this->Task_model->managerReportRecords($branchId, $ref1);
            $incompleted = $this->Task_model->managerReportRecords($branchId, $ref2);
            $payment = $this->Task_model->managerReportRecords($branchId, $ref3);
        }
        

		$data = array();
            
            $data[0] = array(
				'call'	 =>	'Completed',
				'total'	 =>	$completed,
				'color'	 =>	'#006400'
			);
            $data[1] = array(
				'call'	 =>	'InCompleted',
				'total'	 =>	$incompleted,
				'color'	 =>	'#ff0000'
			);
            $data[2] = array(
				'call'	 =>	'Payment',
				'total'	 =>	$payment,
				'color'	 =>	'#0000ff'
			);
        
		echo json_encode($data);
	}


    function chartManagerAssignedView(){

        $branchId = $this->session->branchId;
                
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'assigned';
        $ref2 = 'submitted';

        if($dateId == 1)
        {
            
            $assigned= $this->Task_model->managerAssignedRecordsByMonth($branchId, $month, $year, $ref1);
            $submitted = $this->Task_model->managerAssignedRecordsByMonth($branchId, $month, $year, $ref2);          
            
        }
        else if($dateId == 2){

            $assigned  = $this->Task_model->managerAssignedRecordsByDate($branchId, $startdate, $enddate, $ref1);
            $submitted = $this->Task_model->managerAssignedRecordsByDate($branchId, $startdate, $enddate, $ref2);

        }
        else{

            $assigned  = $this->Task_model->managerAssignedRecords($branchId, $ref1);
            $submitted = $this->Task_model->managerAssignedRecords($branchId, $ref2);
        }
        

		$data = array();
            
            $data[0] = array(
				'call'	 =>	'Assigned',
				'total'	 =>	$assigned,
				'color'	 =>	'#006400'
			);
            $data[1] = array(
				'call'	 =>	'Submitted',
				'total'	 =>	$submitted,
				'color'	 =>	'#ff0000'
			);
        
        
		echo json_encode($data);
	}



    function multiChartManagerView(){

        $branchId = $this->session->branchId;
                
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'completed';
        $ref2 = 'incompleted';
        $ref3 = 'payment';

		$data = array();
        $result = array();

        if($dateId == 1)
        {

            $data['count'] = $this->Task_model->getTelecallerCountByMonth($branchId, $month, $year);
            $result = $this->Task_model->getTelecallerNameByMonth($branchId, $month, $year);

            $i=0;
            foreach ($result as $row)
            {   
                $userId                   = $row->emp_id;
                $data['users'][$i]        = '(' . $row->emp_id .') ' .$row->emp_name;
                $data['completed'][$i]    = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref2);
                $data['payment'][$i]      = $this->Task_model->teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref3);
                $i++;
            }  
        }

        else if($dateId == 2)
        {
            $data['count'] = $this->Task_model->getTelecallerCountByDate($branchId, $startdate, $enddate);
            $result = $this->Task_model->getTelecallerNameByDate($branchId, $startdate, $enddate);

            $i=0;
            foreach ($result as $row)
            {   
                $userId                   = $row->emp_id;
                $data['users'][$i]        = '(' . $row->emp_id .') ' .$row->emp_name;
                $data['completed'][$i]    = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref2);
                $data['payment'][$i]      = $this->Task_model->teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref3);
                $i++;
            }    
        }


        else{

            $data['count'] = $this->Task_model->getTelecallerCount($branchId);
            $result = $this->Task_model->getTelecallerName($branchId);


            $i=0;
            foreach ($result as $row)
            {   
                $userId                   = $row->emp_id;
                $data['users'][$i]        = '(' . $row->emp_id .') ' .$row->emp_name;
                $data['completed'][$i]    = $this->Task_model->teleReportRecords($branchId, $userId, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->teleReportRecords($branchId, $userId, $ref2);
                $data['payment'][$i]      = $this->Task_model->teleReportRecords($branchId, $userId, $ref3);
                $i++;
            }  

        }   
        
		echo json_encode($data);
	}


    // Admin Reports view

    function adminTaskReports(){

        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE ){
            $this->loadThis();
        }
        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }
            
            $data['records'] = $this->Task_model->tempfun();

            $this->global['pageTitle'] = 'CCT | Report Details';
            $this->loadViews("adminTaskReports", $this->global, $data, NULL);  
        }

    }


    function chartAdminView(){
                   
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'completed';
        $ref2 = 'incompleted';
        $ref3 = 'payment';

        if($dateId == 1)
        {
            
            $completed = $this->Task_model->adminReportRecordsByMonth($month, $year, $ref1);
            $incompleted = $this->Task_model->adminReportRecordsByMonth($month, $year, $ref2);
            $payment = $this->Task_model->adminReportRecordsByMonth($month, $year, $ref3);           
            
        }
        else if($dateId == 2){

            $completed  = $this->Task_model->adminReportRecordsByDate($startdate, $enddate, $ref1);
            $incompleted = $this->Task_model->adminReportRecordsByDate($startdate, $enddate, $ref2);
            $payment = $this->Task_model->adminReportRecordsByDate($startdate, $enddate, $ref3);

        }
        else{

            $completed  = $this->Task_model->adminReportRecords($ref1);
            $incompleted = $this->Task_model->adminReportRecords($ref2);
            $payment = $this->Task_model->adminReportRecords($ref3);
        }
        

		$data = array();
            
            $data[0] = array(
				'call'	 =>	'Completed',
				'total'	 =>	$completed,
				'color'	 =>	'#006400'
			);
            $data[1] = array(
				'call'	 =>	'InCompleted',
				'total'	 =>	$incompleted,
				'color'	 =>	'#ff0000'
			);
            $data[2] = array(
				'call'	 =>	'Payment',
				'total'	 =>	$payment,
				'color'	 =>	'#0000ff'
			);
        
		echo json_encode($data);
	}


    function chartAdminSubmittedView(){

                     
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'assigned';
        $ref2 = 'submitted';


		$data = array();
        $result = array();

        if($dateId == 1)
        {

            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId               = $row->b_id;
                $data['branch'][$i]     = $row->b_name;
                $data['assigned'][$i]   = $this->Task_model->managerAssignedRecordsByMonth($branchId, $month, $year, $ref1);         
                $data['submitted'][$i]  = $this->Task_model->managerAssignedRecordsByMonth($branchId, $month, $year, $ref2);
                $i++;
            }  
        }

        else if($dateId == 2)
        {
            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId               = $row->b_id;
                $data['branch'][$i]     = $row->b_name;
                $data['assigned'][$i]   = $this->Task_model->managerAssignedRecordsByDate($branchId, $startdate, $enddate, $ref1);          
                $data['submitted'][$i]  = $this->Task_model->adminBranchRecordsByDate($branchId, $startdate, $enddate, $ref2);
                $i++;
            }    
        }


        else {

            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId               = $row->b_id;
                $data['branch'][$i]     = $row->b_name;
                $data['assigned'][$i]   = $this->Task_model->managerAssignedRecords($branchId, $ref1);         
                $data['submitted'][$i]  = $this->Task_model->managerAssignedRecords($branchId, $ref2);
                $i++;
            }  

        }
        
        
		echo json_encode($data);
	}



    function multiChartAdminView(){

                       
        $dateId = $this->security->xss_clean($this->input->post('dateId'));

        $monthpick = $this->security->xss_clean($this->input->post('monthpicker'));
        $month = date("m",strtotime($monthpick));
        $year = date("Y",strtotime($monthpick));

        $startdate1 = $this->security->xss_clean($this->input->post('startdate'));
        $startdate = date('Y-m-d', strtotime($startdate1));

        $enddate1 = $this->security->xss_clean($this->input->post('enddate'));
        $enddate = date('Y-m-d', strtotime($enddate1));

        $ref1 = 'completed';
        $ref2 = 'incompleted';
        $ref3 = 'payment';

		$data = array();
        $result = array();

        if($dateId == 1)
        {

            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId                 = $row->b_id;
                $data['branch'][$i]       = $row->b_name;
                $data['completed'][$i]    = $this->Task_model->adminBranchRecordsByMonth($branchId, $month, $year, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->adminBranchRecordsByMonth($branchId, $month, $year, $ref2);
                $data['payment'][$i]      = $this->Task_model->adminBranchRecordsByMonth($branchId, $month, $year, $ref3);
                $i++;
            }  
        }

        else if($dateId == 2)
        {
            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId                 = $row->b_id;
                $data['branch'][$i]       = $row->b_name;
                $data['completed'][$i]    = $this->Task_model->adminBranchRecordsByDate($branchId, $startdate, $enddate, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->adminBranchRecordsByDate($branchId, $startdate, $enddate, $ref2);
                $data['payment'][$i]      = $this->Task_model->adminBranchRecordsByDate($branchId, $startdate, $enddate, $ref3);
                $i++;
            }    
        }


        else {

            $data['count'] = $this->Task_model->getBranchCount();
            $result = $this->Task_model->getBranchNameList();

            $i=0;
            foreach ($result as $row)
            {   
                $branchId                 = $row->b_id;
                $data['branch'][$i]       = $row->b_name;
                $data['completed'][$i]    = $this->Task_model->adminBranchRecords($branchId, $ref1);          
                $data['incompleted'][$i]  = $this->Task_model->adminBranchRecords($branchId, $ref2);
                $data['payment'][$i]      = $this->Task_model->adminBranchRecords($branchId, $ref3);
                $i++;
            }  

        }   
        
		echo json_encode($data);
	}




    function branchDetails(){
        
        if($this->isManager() == TRUE){
            $this->loadThis();
        }

        else{

            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            } 

            $branchId = $this->session->branchId;
            
            $data['branchInfo'] = $this->Task_model->getBranchInfo($branchId);
            
            $this->global['pageTitle'] = 'CCT | Branch Details';
            
            $this->loadViews("branchesDetails", $this->global,  $data, NULL);

        }
    }

    function addNewTask()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Task_model');
            $branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo5();
                        
            $this->global['pageTitle'] = 'CCT | Add New Branch';

            $this->loadViews("addNewTask", $this->global, $data, NULL);
        }
    }

     
    function addingTasks()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('customer_number','Customer Number','trim|required|max_length[128]');

            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewTask();
            }
            else
            {
                $branch_id = $this->input->post('b_id');
                $base_id = $this->input->post('base_id');
                $customer_number = $this->security->xss_clean($this->input->post('customer_number'));
                $assignDate = $this->input->post('assignDate');
                $date = date('Y-m-d', strtotime($assignDate));

                $sql2 = "SELECT c_id FROM call_status where c_status = 'Submitted'";
                $query2 = $this->db->query($sql2);
                $user2 = $query2->row();
                   
                $call_status = $user2->c_id;

                $taskInfo = array('branch_id'=> $branch_id,'customer_number'=>$customer_number, 'submitted_date'=>$date, 'call_status'=> $call_status, 'base'=> $base_id );           
                
                $this->load->model('Task_model');
                $result = $this->Task_model->addNewTask($taskInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Task created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task creation failed');
                }
                
                redirect('addNewTask');
            }
        }
    }


    function addSubmitTask()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Task_model');
            //$branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo5();
            $data['baseCount'] = $this->Task_model->getBaseTaskCountData();
            $data['nonbaseCount'] = $this->Task_model->getNonBaseTaskCountData();
                        
            $this->global['pageTitle'] = 'CCT | Add Submit Task';

            $this->loadViews("addSubmitTask", $this->global, $data, NULL);
        }
    }


    function checkRequestTask(){

        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Task_model');
            
            $branch_id = $this->input->post('branch_id');
            $base_id = $this->input->post('base_id');

            $sql = "SELECT request_task, r_id FROM request_details where request_branch = '".$branch_id."' AND r_base = '".$base_id."' AND r_status = 1  ORDER BY r_id DESC LIMIT 1";
            $query = $this->db->query($sql);
            $user = $query->row();
            $requestCount = $user->request_task;
            $requestId = $user->r_id;

            $data = array(
                
				'requestCount' =>	$requestCount,
				'requestId'	   =>	$requestId
	
			);

            echo json_encode($data); 
            
            

        }
        
    }
    

    function addNewRequest()
    {
        if($this->isManager() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Task_model');
            $branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo5();
                        
            $this->global['pageTitle'] = 'CCT | Add New Branch';

            $this->loadViews("addNewRequest", $this->global, $data, NULL);
        }
    }

     
    function requestingTasks()
    {
        if($this->isManager() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('task_count','Task Count','trim|required|max_length[10]');

            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewTask();
            }
            else
            {
                $branch_id = $this->input->post('b_id');
                $base_id = $this->input->post('base_id');
                $role_id = $this->input->post('role');
                $taskCount= $this->security->xss_clean($this->input->post('task_count'));
                $date = date('Y-m-d H:i:sP');

                $taskInfo = array('request_branch'=> $branch_id,'request_date'=>$date, 'request_task'=>$taskCount, 'r_base'=> $base_id, 'requested_by'=> $role_id, 'r_status'=>1);           
                
                $this->load->model('Task_model');
                $result = $this->Task_model->addNewRequest($taskInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Request Task created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Request Task creation failed');
                }
                
                redirect('addNewRequest');
            }
        }
    }



    function assignTasks()
    {
        if($this->isManager() == TRUE) 
        {
            $this->loadThis();
        }

        else
        {
            $this->load->model('Task_model');
            $branchId = $this->session->branchId;
            $data['userInfo'] = $this->Task_model->getTaskInfo($branchId);

            $data['taskInfo'] = $this->Task_model->getAssignTaskInfo($branchId);
            $data['branchId'] = $branchId;

            $data['baseInfo'] = $this->Task_model->getBaseTaskCount($branchId);
            $data['nonbaseInfo'] = $this->Task_model->getNonBaseTaskCount($branchId);
            
                        
            $this->global['pageTitle'] = 'CCT | Assign Tasks';

            $this->loadViews("assignTasks", $this->global, $data, NULL);
        }
    }

    function assigningTasks()
    {
        if($this->isManager() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
           
                $sql2 = "SELECT c_id FROM call_status where c_status = 'Assigned'";
                $query2 = $this->db->query($sql2);
                $user2 = $query2->row();
                $call_status = $user2->c_id;
				
                $emp_id = $this->input->post('e_id');
                $base_id = $this->input->post('base_id');
                $taskValue = $this->input->post('taskValue');

                $assignDate = $this->input->post('assignDate');
                $date = date('Y-m-d', strtotime($assignDate));
                $branchId = $this->session->branchId;

                $taskId = array();

                $tval = 2;

                $sql = "SELECT t_id FROM cct_task_details where emp_id IS NULL AND branch_id = '".$branchId."' AND base = '".$base_id."' ORDER BY t_id ASC LIMIT ".$taskValue;
                $query = $this->db->query($sql);
                $task = $query->result();

                foreach($task as $row)
                {
                    $taskId[] = $row->t_id;
                }

                $updateArray = array();
                
                for($i = 0; $i < sizeof($taskId); $i++)
                {
                    $updateArray[] = array (
                        't_id' => $taskId[$i],
                        'emp_id' => $emp_id,
                        'assigned_date' => $date,
                        'call_status'=> $call_status
                    );
                }

               $result = $this->db->update_batch('cct_task_details',$updateArray, 't_id');
                echo $result; 

                if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
                else { echo(json_encode(array('status'=>FALSE))); }
            
        }
    }


    function submittingTasks()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
                $sql2 = "SELECT c_id FROM call_status where c_status = 'Submitted'";
                $query2 = $this->db->query($sql2);
                $user2 = $query2->row();
                $call_status = $user2->c_id;
				
                $r_id = $this->input->post('request_id');
                
                $base_id = $this->input->post('task');
                $taskValue = $this->input->post('taskValue');
                $branchId = $this->input->post('branch_id');
                $update = $this->input->post('update');
                $date = date('Y-m-d H:i:sP');
                $roldId = $this->input->post('roldId');

                

                if($update == 1){
                    $updateInfo = array('response_task'=>$taskValue,  'response_date'=> $date, 'r_status'=> 2 );
                    $result = $this->Task_model->updateTask($r_id, $updateInfo);
                }
                else{
                    $taskInfo = array('request_branch'=> $branchId, 'request_task'=>$taskValue, 'request_date'=> $date, 'r_base'=>$base_id, 'response_task'=>$taskValue, 'response_date'=> $date, 'requested_by'=> $roldId, 'r_status'=> 2 );
                    $result = $this->Task_model->addNewRequest($taskInfo);
                }

                $sql = "SELECT t_id FROM cct_task_details where emp_id IS NULL AND branch_id IS NULL AND base = '".$base_id."' ORDER BY t_id ASC LIMIT ".$taskValue;
                $query = $this->db->query($sql);
                $task = $query->result();

                foreach($task as $row)
                {
                    $taskId[] = $row->t_id;
                }

                $updateArray = array();
                
                for($i = 0; $i < sizeof($taskId); $i++)
                {
                    $updateArray[] = array (
                        't_id' => $taskId[$i],
                        'emp_id' => $emp_id,
                        'submitted_date' => $date,
                        'call_status'=> $call_status,
                        'branch_id' => $branchId
                    );
                }
             
            if ($this->db->update_batch('cct_task_details',$updateArray, 't_id')){
                
                print json_encode(array("status"=>"success","message"=>"Your message here"));
                
             }
           

                //redirect ( 'responseTask' );      
               //$result2 = $this->db->update_batch('cct_task_details',$updateArray, 't_id');
            
        }
    }

    

    function editOldTask($taskId = NULL)
    {
        if($this->isManager() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('taskListing');
            }

            $branchId = $this->session->branchId;
            $data['taskInfo'] = $this->Task_model->getTaskInfo($branchId);
            $data['taskInfo2'] = $this->Task_model->getTaskInfo2($taskId);
            
            $this->global['pageTitle'] = 'CCT | Edit Task';
            
            $this->loadViews("editOldTask", $this->global, $data, NULL);
        }
    }


    function submitRequestTask($taskId = NULL)
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('responseTask');
            }

            $data['getRequestInfo'] = $this->Task_model->getRequestInfo($taskId);
            $data['baseCount'] = $this->Task_model->getBaseTaskCountData();
            $data['nonbaseCount'] = $this->Task_model->getNonBaseTaskCountData();
            
            $this->global['pageTitle'] = 'CCT | Submit Task';
            
            $this->loadViews("editRequestTask", $this->global, $data, NULL);
        }
    }


    function editAdminTask($taskId = NULL)
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('taskListing');
            }

            $data['branchRecords'] = $this->User_model->branchListing1();
            $data['taskRecords'] = $this->Task_model->getTaskAdminInfo($taskId);
            
            $this->global['pageTitle'] = 'CCT | Edit Task';
            
            $this->loadViews("editAdminTask", $this->global, $data, NULL);
        }
    }

    function editAdminTask2(){

        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');

            
            $this->form_validation->set_rules('base_id','base_id','trim|required|max_length[128]');
           
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editAdminTask($t_id);
            }
            else
            {

               
                $b_id = $this->input->post('base_id');
                $number = $this->input->post('number');
                
                $taskInfo = array('base'=> $b_id, 'customer_number'=>$number);
                
                $this->load->model('Task_model');

                $result = $this->Task_model->editAdminTask($taskInfo, $t_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
            }
        }

    }
    
    function editOldCallTask($taskId = NULL)
    {
        if($this->isEmployee() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('teleAssignedTasks');
            }

            $data['taskInfo3'] = $this->Task_model->getTaskInfo3($taskId);
            $data['taskInfo4'] = $this->Task_model->getTaskInfo4();

            $this->global['pageTitle'] = 'CCT |  Edit Task';
            
            $this->loadViews("editOldCallTask", $this->global, $data,NULL);
        }
    }


    function editTask()
    {
        if($this->isManager() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');
            
            $this->form_validation->set_rules('emp_id','emp_id','trim|required|max_length[128]');

            if($this->form_validation->run() == FALSE)
            {
               
                $this->editOldTask($t_id);
            }
            else
            {
                $emp_id = $this->input->post('emp_id');
                $assigned_date = $this->input->post('assigned_date');

                $date = date('Y-m-d', strtotime($assigned_date));

                $taskInfo = array('emp_id'=> $emp_id,'assigned_date'=>$date);
                
                $this->load->model('Task_model');
                $result = $this->Task_model->editTask($taskInfo, $t_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
            }
        }
    }

    function editTeleCallTask(){

        if($this->isManager() == FALSE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');          
            $this->form_validation->set_rules('t_id','t_id','trim|required|max_length[128]');
           
            if($this->form_validation->run() == FALSE)
            {             
                $this->editOldTask($t_id);
            }
            else
            {

                $call_status = $this->input->post('call_status');

                $this->db->select('c_status');
                $this->db->from('call_status');
                $this->db->where('c_id', $call_status);
                $query = $this->db->get();
                $call = $query->row();
                $c_status = $call->c_status;

                
                $date1 = $this->input->post('callDate');
                $payment = $this->input->post('payment');

                $complete =  date('Y-m-d H:i:sP');
                
                $callDate = date('Y-m-d H:i:sP', strtotime($date1));
                
                if($c_status == 'Call on date'){

                $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status,'call_on_date'=>$callDate);

                }
                else if( $c_status == 'In-Progress'  || $c_status == 'Line Busy'  || $c_status == 'Switched off' || $c_status == 'Call not picked' || $c_status == 'Invalid Number') {
                   
                    $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status);
                }
                else if($c_status == 'Call Completed') {

                    $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status, 'completed_date'=>$complete);
                }
                else if($c_status == 'Payment Received') {
                
                    $paymentInfo = array('payment_info'=>$payment, 'payment_date'=>date('Y-m-d H:i:s'));
                    $result1 = $this->Task_model->addPayment($paymentInfo);

                    if($result1 > 0){

                        $sql = 'SELECT payment_id  FROM payment_details ORDER BY payment_id DESC LIMIT 1';
                        $query = $this->db->query($sql);
                        $payment = $query->row();
                        $data = ($payment->payment_id);
                        $p_id = $data;

                        $taskInfo = array('t_id'=> $t_id,'call_status'=>$call_status, 'payment_id'=>$p_id);

                    }
                   
                }

                
                else{

                    $this->session->set_flashdata('error', 'change the call status');
                }

                $result = $this->Task_model->editTask($taskInfo, $t_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
                  
            }
        }
    }


    function editTaskPayment($taskId = NULL)
    {
        if($this->isEmployee() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($taskId == null)
            {
                redirect('editTaskPayment');
            }
            
            $data['paymentInfo'] = $this->Task_model->getPaymentInfo($taskId);

            $this->global['pageTitle'] = 'CCT |  Edit Task';
            
            $this->loadViews("editTaskPayment", $this->global, $data,NULL);
        }
    }


    function editTaskPayment2()
    {
        if($this->isEmployee() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $t_id = $this->input->post('t_id');
            $payment_id = $this->input->post('payment_id');

            
            $this->form_validation->set_rules('t_id','t_id','trim|required|max_length[128]');
            $payment = $this->input->post('payment');

            
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editTaskPayment($t_id);
            }
            else
            {
                $paymentInfo = array('payment_id'=> $payment_id,'payment_info'=>$payment);
            }

            $result = $this->Task_model->editTaskPayment($paymentInfo, $payment_id);

                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Task Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Task updated failed');
                }
                
                $myData = $this->session->userdata('previous_url');
                redirect($myData);
                $this->session->unset_userdata('previous_url');
        }    

    }



    function deleteTask()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $t_id = $this->input->post('taskid');
            $taskInfo = array('isDeleted'=>1);
            
            $result = $this->Task_model->deleteTask($t_id, $taskInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    } 

    function cancelTask()
    {
        if($this->isAdmin() == TRUE && $this->isDataEntry() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $rid = $this->input->post('rId');
            $requestInfo = array('r_status'=>3);
            
            $result = $this->Task_model->cancelTask($rid, $requestInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    } 
   
}

?>