<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Branches extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        date_default_timezone_set('asia/kolkata');
        
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
   
    
    /**
     * This function is used to load the user list
     */
    function branchListing(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->branchListingCount($searchText);

			$returns = $this->paginationCompress ( "branchListing/", $count, 10 );
            
            $data['branchRecords'] = $this->user_model->branchListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT : Branch Listing';
            
            $this->loadViews("branches", $this->global, $data, NULL);

        }
    }
    function branchDetails(){
        
        if($this->isManager() == TRUE && $this->isEmployee() == TRUE){
            $this->loadThis();
        }

        else{



            $branchId = $this->session->branchId;
            
           // $data['branchRecords'] = $this->user_model->branchInfo($branchId);

            $data['branchInfo'] = $this->user_model->getBranchInfo($branchId);
            
            $this->global['pageTitle'] = 'CCT : Branch Details';

           // $data['branchRecords'] = $this->user_model->getBranchInfo($branch);
            
            $this->loadViews("branchesDetails", $this->global,  $data, NULL);

        }
    }

    function addNewBranch()
    {
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
                        
            $this->global['pageTitle'] = 'CCT : Add New Branch';

            $this->loadViews("addNewBranch", $this->global, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
   

    /**
     * This function is used to check whether email already exist or not
     */
    
     
    function addingBranches()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('bname','Branch Name','trim|required|max_length[128]');
            $this->form_validation->set_rules('baddress','Branch Address','trim|required|max_length[128]');
            $this->form_validation->set_rules('bmobile','Branch Number','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewBranch();
            }
            else
            {
                $name = ucwords(strtolower($this->security->xss_clean($this->input->post('bname'))));
                $mobile = $this->security->xss_clean($this->input->post('bmobile'));
                $address = $this->security->xss_clean($this->input->post('baddress'));


                $branchInfo = array('b_name'=> $name,'b_phonenum'=>$mobile, 'b_address'=>$address);
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewBranch($branchInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Branch created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Branch creation failed');
                }
                
                redirect('addNewBranch');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldBranch($branchId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($branchId == null)
            {
                redirect('branchListing');
            }
            
            //$data['roles'] = $this->user_model->getUserRoles();
            $data['branchInfo'] = $this->user_model->getBranchInfo($branchId);
            
            $this->global['pageTitle'] = 'CCT : Edit Branch';
            
            $this->loadViews("editOldBranch", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function editBranch()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $b_id = $this->input->post('b_id');

            
            $this->form_validation->set_rules('bname','Branch Name','trim|required|max_length[128]');
            $this->form_validation->set_rules('baddress','Branch Address','trim|required|max_length[2000]');
            $this->form_validation->set_rules('bmobile','Branch Number','required|max_length[20]');
            
            if($this->form_validation->run() == FALSE)
            {
               
                $this->editOldBranch($b_id);
            }
            else
            {
                $name = ucwords(strtolower($this->security->xss_clean($this->input->post('bname'))));
                $mobile = $this->security->xss_clean($this->input->post('bmobile'));
                $address = $this->security->xss_clean($this->input->post('baddress'));


                $branchInfo = array('b_name'=> $name,'b_phonenum'=>$mobile, 'b_address'=>$address);
                
                $this->load->model('user_model');
                $result = $this->user_model->editBranch($branchInfo, $b_id);
                                
                if($result ==  TRUE)
                {
                    $this->session->set_flashdata('success', ' Branch Updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Branch updated failed');
                }
                
                redirect('branchListing');
            }
        }
    }


    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteBranch()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $b_id = $this->input->post('branchId');
            $branchInfo = array('isDeleted'=>1);
            
            $result = $this->user_model->deleteBranch($b_id, $branchInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    
   
}

?>