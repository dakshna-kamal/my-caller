<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Task_model extends CI_Model
{
   
    function taskListing($searchText, $page, $segment)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.uploaded_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date,TaskTbl.base, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where( "TaskTbl.isDeleted", 0 );
        $this->db->where('call.c_status', 'Default');

        if(!empty($searchText)) {
            
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);

        }
                
        $this->db->limit($page, $segment);

        $query = $this->db->get();
        $result = $query->result();   
        return $result;
       
    }

    function tempfun(){
        $sql = "SELECT COUNT(t_id), SUM( IF( (call_status >= 1 AND call_status <= 6) || call_status =10, 1 ,0 ) ) as Incompelted, SUM( IF( call_status = 7 OR call_status = 8 , 1, 0 ) ) as Compelted FROM cct_task_details";
        $query = $this->db->query($sql);    
        $result = $query->result();
        return $result;

    }

    function taskListingCount($searchText)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.uploaded_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date,TaskTbl.base, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where( "TaskTbl.isDeleted", 0 );
        $this->db->where('call.c_status', 'Default');

        if(!empty($searchText)) {
            
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);

        }
        
        $query = $this->db->get();  

        return $query->num_rows();
        
    }

    function searchTaskListingCount($searchText)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('call.c_status', 'Submitted');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);

        }

        $query = $this->db->get();

        return $query->num_rows();
        
    }

    function searchTaskListing($searchText, $page, $segment)
    {

        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('call.c_status', 'Submitted');
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $this->db->limit($page, $segment);

        $query = $this->db->get();
        $result = $query->result();   
        return $result;
    }


    function submittedTask($searchText, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.base');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');
		$where = 'TaskTbl.emp_id IS NULL';
		$this->db->where($where);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }              
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function submittedTaskCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');
		
		$where = 'TaskTbl.emp_id IS NULL';
		$this->db->where($where);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
         }
        
      
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }
 
    function assignedTeleTaskCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id,Emp.emp_name, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');    
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Assigned');
		

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
         }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

    function assignedTeleTask($searchText, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id,Emp.emp_name, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.submitted_date, TaskTbl.base');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Assigned');


        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function requestedTask($searchText, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.r_id, TaskTbl.request_date, TaskTbl.request_task, TaskTbl.r_base, TaskTbl.response_date, TaskTbl.response_task, role.rolename, status.request_status');
        $this->db->from('request_details as TaskTbl');
        $this->db->join('cct_roles as role', 'role.roleId = TaskTbl.requested_by','inner');
        $this->db->join('request_status as status', 'status.request_id = TaskTbl.r_status','inner');

        $this->db->where('TaskTbl.request_branch', $branchId);

        $where = "(TaskTbl.request_date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now()) ";
        $this->db->where( $where);


        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function requestedTaskCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.r_id, TaskTbl.request_date, TaskTbl.request_task, TaskTbl.r_base, TaskTbl.response_date, TaskTbl.response_task, role.rolename, status.request_status');
        $this->db->from('request_details as TaskTbl');
        $this->db->join('cct_roles as role', 'role.roleId = TaskTbl.requested_by','inner');
        $this->db->join('request_status as status', 'status.request_id = TaskTbl.r_status','inner');

        $this->db->where('TaskTbl.request_branch', $branchId);

        $where = "(TaskTbl.request_date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now()) ";
        $this->db->where( $where);



        $this->db->where( "TaskTbl.isDeleted", 0 );
        
    
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function responseTask($searchText,$branchId, $page, $segment)
    {
        $this->db->select('TaskTbl.r_id, branch.b_name, TaskTbl.request_date,  TaskTbl.request_task, TaskTbl.r_base, TaskTbl.response_date, TaskTbl.response_task, role.rolename, status.request_status');
        $this->db->from('request_details as TaskTbl');
        $this->db->join('cct_branch_details as branch', 'branch.b_id = TaskTbl.request_branch','inner');
        $this->db->join('cct_roles as role', 'role.roleId = TaskTbl.requested_by','inner');
        $this->db->join('request_status as status', 'status.request_id = TaskTbl.r_status','inner');

        $where = "(TaskTbl.request_date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now()) ";
        $this->db->where( $where);
        
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        $this->db->order_by('TaskTbl.request_date','DESC');
        $this->db->limit($page, $segment);
        
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

     function responseTaskCount($searchText)
    {
        $this->db->select('TaskTbl.r_id, TaskTbl.request_date, TaskTbl.request_task, TaskTbl.r_base, TaskTbl.response_date, TaskTbl.response_task, role.rolename, status.request_status');
        $this->db->from('request_details as TaskTbl');
        $this->db->join('cct_roles as role', 'role.roleId = TaskTbl.requested_by','inner');
        $this->db->join('request_status as status', 'status.request_id = TaskTbl.r_status','inner');

        $where = "(TaskTbl.request_date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now()) ";
        $this->db->where( $where);

        
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
    
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    
    function reminderTaskListingToday($searchText, $page, $segment, $branchId, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        $this->db->where( "TaskTbl.isDeleted", 0 );
       

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
    }



    function reminderTaskListingTodayCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
       
            $query = $this->db->get();
            return $query->num_rows();       
    }


    function escalatedTask($searchText, $page, $segment, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, b_name, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        $this->db->where('call.c_status', 'Call on date');
       
       $this->db->where( "TaskTbl.isDeleted", 0 );
       

       if(!empty($searchText)) {
        $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
        $this->db->where($likeCriteria);
    }
        
      
        $this->db->limit($page, $segment);
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
       

    }


    function escalatedTaskCount($searchText, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        $this->db->where('call.c_status', 'Call on date');
       
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        return $query->num_rows();

    }

    function taskTeleListingTodayCount($searchText,$branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where( "TaskTbl.isDeleted", 0 ); 
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $getDate);
        $this->db->where('call.c_status !=', 'Assigned');


        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function teleTaskListingToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date' , $getDate);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
    
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskListingTodayCount($searchText, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
       
        $this->db->where('TaskTbl.assigned_date' , $getDate);
        $this->db->where('call.c_status', 'Assigned');

        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
        


        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $getDate);
      
        $this->db->where('call.c_status', 'Call Completed');


        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskInCompletedTodayCount($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        //$this->db->where('TaskTbl.assigned_date', $getDate);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
        $this->db->where( "TaskTbl.isDeleted", 0 );

       if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskInCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date <', $getDate);
        $where = "call.c_status != 'Call on date' AND call.c_status != 'Call Completed' AND call.c_status != 'Payment Received' AND call.c_status != 'Submitted' " ;
        $this->db->where($where);
        $this->db->where( "TaskTbl.isDeleted", 0 );

       if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function teleTaskPayment($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskPaymentCount($searchText, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function telePaymentAssign($searchText, $page, $segment, $branchId, $getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 0);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function telePaymentAssignCount($searchText, $branchId, $getDate)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 0);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }

    function telePaymentStatus($searchText, $page, $segment, $branchId, $getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');

        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function telePaymentStatusCount($searchText, $branchId, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountPaymentProcess($branchId, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('TaskTbl.branch_id' , $branchId);
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountPaymentProcessCount($branchId, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('TaskTbl.branch_id' , $branchId);
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountSearchProcess($searchText, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
            

        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountSearchProcessCount($searchText, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountPaymentStatus($branchId, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('TaskTbl.branch_id' , $branchId);
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountPaymentStatusCount($branchId, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('TaskTbl.branch_id' , $branchId);
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );
                
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountSearchStatus($searchText, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountSearchStatusCount($searchText, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.branch_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
                
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function submitVerify($branchId, $getDate)
    {
    
        $this->db->select('payment.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.status_id' , 0);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        
    }




    function teleTaskReminderToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $myDate = date("Y-m-d H:i:s");
        $this->db->where('call.c_status', 'Call on date');  
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
    
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function taskListingCount1($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date ', $getDate);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        

        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function getTelecallerCount($branchId) {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where ( "branch_id", $branchId );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getTelecallerName($branchId) {
		$this->db->select ( "emp_id, emp_name" );
        $this->db->from('cct_emp_details');
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where ( "branch_id", $branchId );
		$query = $this->db->get ();
		
        $result = $query->result();   
        return $result;
	}

    function teleReportRecords($branchId, $userId,$ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $query = $this->db->get();      
        return count ( $query->result () );

    }

    function getTelecallerCountByMonth($branchId, $month, $year) {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where ( "branch_id", $branchId );
        $this->db->where('YEAR(created_date) <=', $year);
        $this->db->where('MONTH(created_date) <=', $month);
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}
    
    function getTelecallerNameByMonth($branchId, $month, $year) {
		$this->db->select ( "emp_id, emp_name" );
        $this->db->from('cct_emp_details');
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where('YEAR(created_date) <=', $year);
        $this->db->where('MONTH(created_date) <=', $month);
        $this->db->where ( "branch_id", $branchId );
		$query = $this->db->get ();
		
        $result = $query->result();   
        return $result;
	}

    function teleReportRecordsByMonth($branchId, $userId, $month, $year, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
        $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
        

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
        $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
        

        $query = $this->db->get();      
        return count ( $query->result () );
        
    }


    function getTelecallerCountByDate($branchId, $startdate, $enddate) {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where ( "branch_id", $branchId );

        $where = "(created_date <='{$startdate}' OR created_date <= '{$enddate}') ";
        $this->db->where($where);

		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}
    
    function getTelecallerNameByDate($branchId, $startdate, $enddate) {
		$this->db->select ( "emp_id, emp_name" );
        $this->db->from('cct_emp_details');
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $where = "(created_date <='{$startdate}' OR created_date <= '{$enddate}') ";
        $this->db->where($where);
        $this->db->where ( "branch_id", $branchId );
		$query = $this->db->get ();
		
        $result = $query->result();   
        return $result;
	}


    function teleReportRecordsByDate($branchId, $userId, $startdate, $enddate, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);

        $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);

        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        $query = $this->db->get();      
        return count ( $query->result () );

    }

    //Manager Reports

    function managerReportRecords($branchId, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);

        $this->db->where('TaskTbl.branch_id', $branchId);
        $query = $this->db->get();      
        return count ( $query->result () );

    }

    function managerReportRecordsByMonth($branchId, $month, $year, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);
        
        $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
        $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
        

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
        $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
        

        $query = $this->db->get();      
        return count ( $query->result () );
        
    }



    function managerReportRecordsByDate($branchId, $startdate, $enddate, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);

        $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        if($ref =='incompleted' ){
            $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
        }
        else if($ref == 'completed'){
            $where = "call.c_status = 'Call Completed'"; 
        } 
        else{
            $where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);

        $this->db->where('TaskTbl.branch_id', $branchId);

        $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        $query = $this->db->get();      
        return count ( $query->result () );

    }


    function managerAssignedRecords($branchId, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);

        if($ref =='assigned' ){
            $where = "TaskTbl.assigned_date IS NOT NULL"; 
        }
        else if($ref == 'submitted'){
            $where = "call.c_status = 'Submitted'"; 
        } 
        else{
            //$where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);

        $this->db->where('TaskTbl.branch_id', $branchId);
        $query = $this->db->get();      
        return count ( $query->result () );

    }

    function managerAssignedRecordsByMonth($branchId, $month, $year, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);

        $this->db->where('YEAR(TaskTbl.submitted_date)', $year);
        $this->db->where('MONTH(TaskTbl.submitted_date)', $month);


        if($ref =='assigned' ){
            $where = "TaskTbl.assigned_date IS NOT NULL"; 
        }
        else if($ref == 'submitted'){

            $where = "call.c_status = 'Submitted'"; 
        } 
        else{
            //$where = "call.c_status = 'Submitted'";  
        }
        $this->db->where($where);

        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('YEAR(TaskTbl.submitted_date)', $year);
        $this->db->where('MONTH(TaskTbl.submitted_date)', $month);




        $query = $this->db->get();      
        return count ( $query->result () );
        
    }



    function managerAssignedRecordsByDate($branchId, $startdate, $enddate, $ref){

        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('TaskTbl.branch_id', $branchId);

        $where = "(TaskTbl.submitted_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        if($ref =='assigned' ){
            $where = "TaskTbl.assigned_date IS NOT NULL"; 
        }
        else if($ref == 'submitted'){
            $where = "call.c_status = 'Submitted'"; 
        } 
        else{
            //$where = "call.c_status = 'Payment Received'";  
        }
        $this->db->where($where);
        $this->db->where('TaskTbl.branch_id', $branchId);

        $where = "(TaskTbl.submitted_date BETWEEN '{$startdate}' AND '{$enddate}') ";
        $this->db->where($where);

        $query = $this->db->get();      
        return count ( $query->result () );

    }



// Admin records


function getBranchCount() {
    $this->db->select ( "b_id" );
    $this->db->where ( "isDeleted", 0 );
    $query = $this->db->get ( "cct_branch_details" );
    
    return count ( $query->result () );
}

function getBranchNameList() {
    $this->db->select ( "b_id, b_name" );
    $this->db->where ( "isDeleted", 0 );
    $this->db->from('cct_branch_details');
    
    $query = $this->db->get ();
    
    $result = $query->result();   
    return $result;
}


function adminReportRecords($ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);

    $query = $this->db->get();      
    return count ( $query->result () );

}

function adminReportRecordsByMonth($month, $year, $ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
    
    $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
    $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
    

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);
    $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
    $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
    

    $query = $this->db->get();      
    return count ( $query->result () );
    
}



function adminReportRecordsByDate($startdate, $enddate, $ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 

    $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
    $this->db->where($where);

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);

    $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
    $this->db->where($where);

    $query = $this->db->get();      
    return count ( $query->result () );

}


function adminBranchRecords($branchId, $ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
    $this->db->where('TaskTbl.branch_id', $branchId); 

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);
    $this->db->where('TaskTbl.branch_id', $branchId);

    $query = $this->db->get();      
    return count ( $query->result () );

}

function adminBranchRecordsByMonth($branchId, $month, $year, $ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
    
    $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
    $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
    $this->db->where('TaskTbl.branch_id', $branchId);
    

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);
    $this->db->where('YEAR(TaskTbl.assigned_date)', $year);
    $this->db->where('MONTH(TaskTbl.assigned_date)', $month);
    $this->db->where('TaskTbl.branch_id', $branchId);
    

    $query = $this->db->get();      
    return count ( $query->result () );
    
}



function adminBranchRecordsByDate($branchId, $startdate, $enddate, $ref){

    $this->db->select('TaskTbl.t_id');
    $this->db->from('cct_task_details as TaskTbl');
    $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
    $this->db->where('TaskTbl.branch_id', $branchId); 

    $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
    $this->db->where($where);

    if($ref =='incompleted' ){
        $where = "call.c_status != 'Call Completed' && call.c_status != 'Payment Received' && call.c_status != 'Submitted'";
    }
    else if($ref == 'completed'){
        $where = "call.c_status = 'Call Completed'"; 
    } 
    else{
        $where = "call.c_status = 'Payment Received'";  
    }
    $this->db->where($where);

    $where = "(TaskTbl.assigned_date BETWEEN '{$startdate}' AND '{$enddate}') ";
    $this->db->where($where);
    $this->db->where('TaskTbl.branch_id', $branchId);

    $query = $this->db->get();      
    return count ( $query->result () );

}


       
    function getUserRoles()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getUserRoles1()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }


    function getUserBranches()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
       
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function userNameCreation()
    {
        $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
        $query = $this->db->query($sql);
        $user = $query->row();
        return $user;
    }


    function getManagerUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 3 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getEmployeeUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 2 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function checkEmailExists($email, $userId = 0)
    {
        $this->db->select("email");
        $this->db->from("tbl_users");
        $this->db->where("email", $email);   
        $this->db->where("isDeleted", 0);
        if($userId != 0){
            $this->db->where("userId !=", $userId);
        }
        $query = $this->db->get();

        return $query->result();
    }
    
    function addNewTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('cct_task_details', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function addNewRequest($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('request_details', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

   

    function getUserInfo($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
		$this->db->where('role_id !=', 1);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getBranchInfo($branchId)
    {
        $this->db->select('b_name, b_address, b_id, b_phonenum');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo($branchId)
    {
        $this->db->select('emp_id, emp_name');
        $this->db->from('cct_emp_details');
        $this->db->where('role_id !=', 1);
        $this->db->where('role_id !=', 2);
        $this->db->where('isDeleted', 0);
        $this->db->where('branch_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo2($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, Emp.emp_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'TaskTbl.emp_id  = Emp.emp_id ','inner');  
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }


    function getAssignTaskInfo($branchId){
        $this->db->select('t_id, customer_number');
        $this->db->from('cct_task_details');
		$where = 'emp_id IS NULL';
		$this->db->where($where);
		
        $this->db->where('branch_id', $branchId);

        $query = $this->db->get();
        
        return $query->result();
    }

    function getBaseTaskCount($branchId){
        
        $this->db->select('t_id');
        $this->db->from('cct_task_details');
		$where = 'emp_id IS NULL';
        $base_id = 'B';
		$this->db->where($where);
        $this->db->where('base', $base_id);
		
        $this->db->where('branch_id', $branchId);

        $query = $this->db->get();
        
        return count ( $query->result () );

    }

    function getNonBaseTaskCount($branchId){
        
        $this->db->select('t_id');
        $this->db->from('cct_task_details');
		$where = 'emp_id IS NULL';
        $base_id = 'NB';
		$this->db->where($where);
        $this->db->where('base', $base_id);
		
        $this->db->where('branch_id', $branchId);

        $query = $this->db->get();
        
        return count ( $query->result () );

    }


    function getBaseTaskCountData(){
        
        $this->db->select('t_id');
        $this->db->from('cct_task_details');
		$where = 'emp_id IS NULL AND branch_id IS NULL';
        
        $base_id = 'B';
		$this->db->where($where);
        $this->db->where('base', $base_id);

        $query = $this->db->get();
        
        return count ( $query->result () );

    }

    function getNonBaseTaskCountData(){
        
        $this->db->select('t_id');
        $this->db->from('cct_task_details');
        $where = 'emp_id IS NULL AND branch_id IS NULL';
        
        $base_id = 'NB';
		$this->db->where($where);
        $this->db->where('base', $base_id);

        $query = $this->db->get();
        
        return count ( $query->result () );

    }


    function getTaskAdminInfo($taskId){
        $this->db->select('TaskTbl.t_id,  TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, TaskTbl.branch_id, TaskTbl.base');
        $this->db->from('cct_task_details as TaskTbl');
      
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    
    function getRequestInfo($taskId){
        $this->db->select('TaskTbl.r_id,  Branch.b_name, TaskTbl.request_date, TaskTbl.request_task, TaskTbl.r_base, TaskTbl.request_branch');
        $this->db->from('request_details as TaskTbl');
        
        $this->db->join('cct_branch_details as Branch', 'TaskTbl.request_branch  = Branch.b_id ','inner');    
        $this->db->where('r_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }





    function getPaymentInfo($taskId){
        $this->db->select('TaskTbl.t_id,  TaskTbl.customer_number, Call.c_status, Payment.payment_date, Payment.payment_info, Payment.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as Call', 'Call.c_id = TaskTbl.call_status ','inner');  
        $this->db->join('payment_details as Payment', 'Payment.payment_id = TaskTbl.payment_id ','inner');   
 
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }
    
    function getPaymentStatus($p_id){

        $this->db->select('payment_id, payment_date, payment_info, status_id');
        $this->db->from('payment_details');
        $this->db->where('payment_id', $p_id);

        $query = $this->db->get();
        
        return $query->result();
    }

    function getPaymentList(){

        $this->db->select('p_id, p_status');
        $this->db->from('payment_status');
        $query = $this->db->get();
        
        return $query->result();
    }


    function getTaskInfo3($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, TaskTbl.assigned_date, TaskTbl.call_status, TaskTbl.call_on_date, TaskTbl.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->where('TaskTbl.t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo4()
    {
        $this->db->select('c_id, c_status');
        $this->db->where('c_status !=', 'Submitted');
        $this->db->where('c_status !=', 'Assigned');
        $this->db->from('call_status');
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo5()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
        $query = $this->db->get();
        
        return $query->result();

    }




    function getBranchName($branchId){
        $this->db->select('b_name');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }
    
    

    function editUser($userInfo, $userId)
    {
        $this->db->where('emp_id', $userId);
        $this->db->update('cct_emp_details', $userInfo);
        
        return TRUE;
    }

    function editBranch($branchInfo, $b_Id)
    {
        $this->db->where('b_id', $b_Id);
        $this->db->update('cct_branch_details', $branchInfo);
        
        return TRUE;
    }

    function editTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }

    


    function editPaymentStatus($paymentInfo, $p_Id)
    {
        $this->db->where('payment_id', $p_Id);
        $this->db->update('payment_details', $paymentInfo);
        
        return TRUE;
    }


    function editTaskPayment($paymentInfo, $payment_id){
        
        $this->db->where('payment_id', $payment_id);
        $this->db->update('payment_details', $paymentInfo);
        
        return TRUE; 
    }
    

    function editAdminTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }


    function deleteTask($t_id, $taskInfo)
    {
        $this->db->where('t_id', $t_id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return $this->db->affected_rows();
    }

    

    function cancelTask($rid, $requestInfo)
    {
        $this->db->where('r_id', $rid);
        $this->db->update('request_details', $requestInfo);
        
        return $this->db->affected_rows();
    }

    function updateTask($rid, $updateInfo)
    {
        $this->db->where('r_id', $rid);
        $this->db->update('request_details', $updateInfo);
        
        return $this->db->affected_rows();
    }



    function assigningTask($taskValue, $base_id, $branchId)
    {
        $this->db->select('t_id');
        $this->db->where('branch_id', $branchId);
        $this->db->where('base', $base_id);
        $this->db->order_by('t_id', 'asc');
        $this->db->limit($taskValue);
        $this->db->from('cct_task_details');
        $query = $this->db->get();
       
        return $query->result();
        
    }


    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('u_id, password');
        $this->db->where('u_id', $userId);        
        $query = $this->db->get('cct_login');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    
    function changePassword($userId, $userInfo)
    {
        $this->db->where('u_id', $userId);
        $this->db->update('cct_login', $userInfo);
        
        return $this->db->affected_rows();
    }

    function loginHistoryCount($userId, $searchText, $fromDate, $toDate)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->from('tbl_last_login as BaseTbl');
        $query = $this->db->get();
        
        return $query->num_rows();
    }


    function loginHistory($userId, $searchText, $fromDate, $toDate, $page, $segment)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        $this->db->from('tbl_last_login as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    function getUserInfoById($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    function branchInfo($branchId)
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->row();

    }

    function addPayment($paymentInfo)
    {
        $this->db->trans_start();
        $this->db->insert('payment_details', $paymentInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    

}

  