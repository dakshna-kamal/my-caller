<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class User extends BaseController
{
   
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');

        $this->isLoggedIn();   
        date_default_timezone_set('asia/kolkata');

    }
    public function index()
    {
        $this->global['pageTitle'] = 'CCT | Dashboard';

        $branchId = $this->session->branchId;
        

        $data ["managerUserCount"] = $this->user_model->getManagerUsersCount ();
        $data ["employeeUserCount"] = $this->user_model->getEmployeeUsersCount ();
        
        $data ["totalbranches"] = $this->user_model->branchListingCount();

        $data ["volunteerCount"] = $this->Volunteer_model->volunteerListingCount1();
        
        $getDate = date('Y-m-d');
        $userId= $this->session->u_id;
      
        $data['branchTelecallerInfo'] = $this->user_model->getTelecallerCount($branchId);
        $data['assignedTeleTaskCount'] = $this->user_model->getAssignedTeleTask($branchId, $getDate);
        $data['submittedTaskCount'] = $this->user_model->getSubmittedTask($branchId, $getDate);
        $data['assignedTaskCount'] = $this->user_model->getAssignedTask($branchId, $getDate);
        $data['completedTaskCount'] = $this->user_model->getCompletedTask($branchId, $getDate);

        $data['teleTaskCountToday'] = $this->user_model->getTeleTaskCountToday($branchId, $getDate, $userId);
        $data['teleTaskCompleteToday'] = $this->user_model->getTeleTaskCompleteToday($branchId, $getDate, $userId);
        $data['teleTaskInCompleteToday'] = $this->user_model->getTeleTaskInCompleteToday($branchId, $getDate, $userId);
        
        $data['teleTaskReminderToday'] = $this->user_model->getTeleTaskReminderToday($branchId, $getDate, $userId);
        $data['teleTaskPaymentDetails'] = $this->user_model->getTeleTaskPaymentDetails($branchId, $getDate, $userId);

        
        

        $data['telePaymentAssignCount'] = $this->user_model->getTelePaymentAssign($branchId, $getDate);
        $data['teleTaskPaymentstatus'] = $this->user_model->getTeleTaskPaymentStatus($branchId, $getDate);

        $data['accountPaymentProcess'] = $this->user_model->getAccountPaymentProcess($branchId, $getDate);
        $data['accountPaymentStatus'] = $this->user_model->getAccountPaymentStatus($branchId, $getDate);

        $data['taskReminderToday'] = $this->user_model->getTaskReminderToday($branchId, $getDate);
        $data['escalatedTask'] = $this->user_model->getescalatedTask($getDate);

        $data['teleTaskCount'] = $this->user_model->getTeleTaskCount();
        $data['requestTask'] = $this->user_model->getrequestTask();
        $data['requestTaskBranch'] = $this->user_model->getrequestTaskBranch($branchId);

        $data ["branchName"] = $this->user_model->getBranchName($branchId);

        $this->loadViews("dashboard", $this->global, $data, NULL);

    }


    function dashboard1(){
        $this->loadViews("dashboard1");
    }

    function branchListing(){
        
        if($this->isAdmin() == TRUE){
            $this->loadThis();
        }

        else{

            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->branchListingCount($searchText);

			$returns = $this->paginationCompress ( "branchListing/", $count, 10 );
            
            $data['branchRecords'] = $this->user_model->branchListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT | Branch Details';
            
            $this->loadViews("branches", $this->global, $data, NULL);

        }
    }

    function volunteerListing()
    {
       
                
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->Volunteer_model->volunteerListingCount($searchText);

			$returns = $this->paginationCompress( "volunteerListing/", $count, 10 );
            
            
            $data['volunteerRecords'] = $this->Volunteer_model->volunteerListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CCT | Volunteer Details';
            
            $this->loadViews("volunteerList", $this->global, $data, NULL);
        
    }


    function viewPdf($v_id = NULL)
	{
            $this->load->library('pdf');
			
			$html_content = "<div><br><h1 align='center'>Volunteer Agreement Details</h2>
            <p>This Volunteer Agreement is a description of the arrangement between us, (AnyOrg), and you (the volunteer) in relation to your voluntary work.  The intention of this agreement is to assure you that we appreciate your volunteering with us and to indicate our commitment to do the best we can to make your volunteer experience with us a positive and rewarding one.<p>
            <h2 align='center'>Part 1 AnyOrg</h2>
            <p>We, AnyOrg, accept the voluntary service of (name of volunteer) beginning (date).</p>
            <p>Your role as a volunteer is (state nature and components of the work).  This work is designed to (state purpose of work in relation to its benefit to the organisation).</p>
            <p>We commit to the following:</p>
            
            <p><b>1. Induction and training</b></p>
            <ul><li>To provide thorough induction on the work of AnyOrg, its staff, your volunteering role and the training necessary to assist you in meeting the responsibilities of your volunteering role, The Volunteers Handbook provides full details of the organisation.
            </li></ul>

            <p><b>2. Supervision, support and flexibility</b></p>
            <ul><li>To define appropriate standards of our services, to communicate them to you, and to encourage and support you to achieve and maintain them as part of your voluntary work
            </li><li>To provide a personal supervisor who will meet with you regularly to discuss your volunteering and any associated problems</li></ul>
            

            <div>";
			$html_content .= $this->Volunteer_model->volunteerPdf($v_id);
            $this->pdf->setPaper('A4', 'portrait');
			$this->pdf->loadHtml($html_content);
			$this->pdf->render();
			$this->pdf->stream("".$v_id.".pdf", array("Attachment"=>0));
		
	}

    function userListing()
    {
        
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {   
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }   

            $role = 3; 
            
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;

            $branchId = $this->security->xss_clean($this->input->post('branch_Id'));

            $data['branchRecords'] = $this->user_model->branchListing1();
            $this->session->set_userdata('previous_url', current_url());
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($branchId, $role);

			$returns = $this->paginationCompress ( "userListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->userListing($branchId, $returns["page"], $returns["segment"], $role);
            
            $this->global['pageTitle'] = 'CCT | TeleCaller Details';
            
            $this->loadViews("users", $this->global, $data, NULL);
        }
    }


    function searchUsers()
    {
        
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
            

        }
        else
        {   
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }   

            $role = 3; 
            
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $searchOption = $this->input->post('searchOption');
            $data['searchText'] = $searchText;
            $data['searchOption'] = $searchOption;
                         
            $this->load->library('pagination');
            $data['branchRecords'] = $this->user_model->branchListing1();
            $this->session->set_userdata('previous_url', current_url());
            
            $count = $this->user_model->searchUsersCount($searchText,$searchOption, $role);

			$returns = $this->paginationCompress ( "searchUsers/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->searchUsers($searchText, $searchOption, $returns["page"], $returns["segment"], $role);
            
            $this->global['pageTitle'] = 'CCT | TeleCaller Details';
            
            $this->loadViews("searchUsers", $this->global, $data, NULL);
        }
    }


    function teleCallerListing()
    {
        
        if($this->isManager() == TRUE) 
        {
            $this->loadThis();
            

        }
        else
        {   
            
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
            
            $role = 3; 
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            
            $branchId = $this->session->branchId;

            $count = $this->user_model->teleCallerListingCount($searchText, $role, $branchId);

			$returns = $this->paginationCompress ( "teleCallerListing/", $count, 10 );

            $branchId = $this->session->branchId;
            
            $data['teleCallerRecords'] = $this->user_model->teleCallerListing($searchText, $returns["page"], $returns["segment"], $role, $branchId);


            
            $this->global['pageTitle'] = 'CCT | TeleCaller Details';
            
            $this->loadViews("telecallers", $this->global, $data, NULL);
        }
    }


    
    function managerListing()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE) 
        {
            $this->loadThis();
           
        }
        else
        {   
         
            if(isset($this->session->success)){
                $this->session->unset_userdata('success');
            } 
            if(isset($this->session->error)){
                $this->session->unset_userdata('error');
            }  
        
            $role = 2;         
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
                         
            $this->load->library('pagination');
            
            $count = $this->user_model->managerListingCount($searchText);

			$returns = $this->paginationCompress ( "mangerListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->managerListing($searchText, $returns["page"], $returns["segment"], $role);
            
            $this->global['pageTitle'] = 'CCT | User Details';
            
            $this->loadViews("managers", $this->global, $data, NULL);
        }
    }



    function logout1()
    {
         
        session_destroy();
        redirect('login');

    }

    function addNew()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['branches'] = $this->user_model->getUserBranches();
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'CCT | Add New User';

            $this->loadViews("addNew", $this->global, $data, NULL);
        }
    }


    function addNewManager()
    {
        if($this->isAdmin() == TRUE) 
        {
            $this->loadThis();
        }
        else
        {
            $data['branches'] = $this->user_model->getUserBranches();
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'CCT | Add New Manager';
            

            $this->loadViews("addNewManager", $this->global, $data, NULL);
        }
    }


    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }

    function addNewUser()
    {
        if($this->isManager() == TRUE && $this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else

            {

                $username = 'CCT_';
                $password = 'admin';
               
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                $fname = $this->input->post('fname');
                $roleId = 3;
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');
                
                $userInfo1 = array('username'=>$username, 'password'=>getHashedPassword($password), 'created_date'=>date('Y-m-d H:i:s'));
                $result1 = $this->user_model->addNewUser($userInfo1);
               

                
                if($result1 > 0)
                {
                    
                    $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
                    $query = $this->db->query($sql);
                    $user = $query->row();
                    $data = ($user->u_id);
                    $emp_id = $data;

                    $username = 'CCT_'.$data;
                    $userInfo3 = array('username'=>$username);
                    $result3 = $this->user_model->updateUserName($userInfo3, $emp_id);

                    
                    $userInfo2 = array('emp_id'=>$emp_id,'emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches,  'created_date'=>date('Y-m-d H:i:s'));
                    $result2 = $this->user_model->addUserDetails($userInfo2);

                   $this->session->set_flashdata('success', 'New User created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }
                
                redirect('addNew');
            }
        }
    }


    function addNewManager1()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else

            {

                $username = 'CCT_';
                $password = 'admin';
               
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                $result3 = $this->user_model->checkManagerList($roleId, $branches);

                if($result3 == 0)
                {
                        

                $userInfo1 = array('username'=>$username, 'password'=>getHashedPassword($password), 'created_date'=>date('Y-m-d H:i:s'));

                $this->load->model('user_model');
                $result1 = $this->user_model->addNewUser($userInfo1);
               
                 
               
                
                
                if($result1 > 0)
                {
                    
                    $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
                    $query = $this->db->query($sql);
                    $user = $query->row();
                    $data = ($user->u_id);
                    $emp_id = $data;

                    $username = 'CCT_'.$data;
                    $userInfo3 = array('username'=>$username);
                    $result3 = $this->user_model->updateUserName($userInfo3, $emp_id);

                    
                    $userInfo2 = array('emp_id'=>$emp_id,'emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches,  'created_date'=>date('Y-m-d H:i:s'));
                    $result2 = $this->user_model->addUserDetails($userInfo2);

                    $this->session->set_flashdata('success', 'New Manager created successfully');               }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }

            }

            else{
                $this->session->set_flashdata('error', 'This Branch Manager already created, Please check Manager Listing Page'); 
            }
                
                redirect('addNewManager');
            }
        }
    }

    function editOld($userId = NULL)
    {
        if($this->isAdmin() == TRUE &&  $this->isManager() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($userId == null)
            {
                redirect('userListing');
            }
            
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['branches'] = $this->user_model->getUserBranches();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);

            
            
            $this->global['pageTitle'] = 'CCT | Edit User';
            
            $this->loadViews("editOld", $this->global, $data, NULL);
        }
    }


    function editOldManager($userId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($userId == null)
            {
                redirect('managerListing');
            }
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['branches'] = $this->user_model->getUserBranches();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);

            
            
            $this->global['pageTitle'] = 'CCT | Edit User';
            
            $this->loadViews("editOldManager", $this->global, $data, NULL);
        }
    }


    function editManager()
    {
        
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            $rollId = $this->session->role;
     
            
            
                echo '<script> new </script>';
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                $result3 = $this->user_model->checkManagerList($roleId, $branches);

               
              
                $userInfo = array('emp_name'=>$fname,'role_id'=>$roleId, 'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches, 'updated_date'=>date('Y-m-d H:i:s'));
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Manager updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Manager updation failed');
                }
               
                 
             
            
                redirect('editOldManager');
            
                
    }

    function editUser()
    {
        
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            $rollId = $this->session->role;
     
            
            
                echo '<script> new </script>';
                $fname = $this->input->post('fname');
                $roleId = $this->input->post('role');
                $gender = $this->input->post('gender');
                $mobile = $this->input->post('mobile');
                $branches = $this->input->post('branches');

                
               
                $userInfo = array('emp_name'=>$fname,'role_id'=>$roleId,'gender'=>$gender, 'mobile_num'=>$mobile,'branch_id'=>$branches, 'updated_date'=>date('Y-m-d H:i:s'));
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'User updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User updation failed');
                }
                
                if($this->isAdmin() == FALSE )
                {
                    redirect('userListing'); 
                }
                else{
                    
                    redirect('teleCallerListing');
                }
            
        
    }


    function inActiveUser()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>1);
            
            $result = $this->user_model->deleteUser($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    function activeUser()
    {
        if($this->isAdmin() == TRUE && $this->isManager() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>0);
            
            $result = $this->user_model->deleteUser($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
    

    
    function loadChangePass()
    {
        $this->global['pageTitle'] = 'CCT | Change Password';
        
        $this->loadViews("changePassword", $this->global, NULL, NULL);
    }
    
    function changePassword()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('oldPassword','Old password','required|max_length[20]');
        $this->form_validation->set_rules('newPassword','New password','required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword','Confirm new password','required|matches[newPassword]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->loadChangePass();
        }
        else
        {
            $u_id = $this->session->u_id;
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');
            
            $resultPas = $this->user_model->matchOldPassword($u_id, $oldPassword);
            
            if(empty($resultPas))
            {
                $this->session->set_flashdata('nomatch', 'Your old password not correct');
                redirect('loadChangePass');
            }
            else
            {
                $usersData = array('password'=>getHashedPassword($newPassword)
                                );
                
                $result = $this->user_model->changePassword($u_id, $usersData);
                
                if($result > 0) { $this->session->set_flashdata('success', 'Password updation successful'); }
                else { $this->session->set_flashdata('error', 'Password updation failed'); }
                
                redirect('loadChangePass');
            }
        }
    }

    function pageNotFound()
    {
        $this->global['pageTitle'] = 'CCT : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }

    function loginHistoy($userId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $userId = ($userId == NULL ? $this->session->userdata("userId") : $userId);

            $searchText = $this->input->post('searchText');
            $fromDate = $this->input->post('fromDate');
            $toDate = $this->input->post('toDate');

            $data["userInfo"] = $this->user_model->getUserInfoById($userId);

            $data['searchText'] = $searchText;
            $data['fromDate'] = $fromDate;
            $data['toDate'] = $toDate;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->loginHistoryCount($userId, $searchText, $fromDate, $toDate);

            $returns = $this->paginationCompress ( "login-history/".$userId."/", $count, 5, 3);

            $data['userRecords'] = $this->user_model->loginHistory($userId, $searchText, $fromDate, $toDate, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'CodeInsect : User Login History';
            
            $this->loadViews("loginHistory", $this->global, $data, NULL);
        }        
    }

    

}

?>