<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Profile_model extends CI_Model
{
    function addNewProfile($profileInfo)
    {
        $this->db->trans_start();
        $this->db->insert('profile', $profileInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    function addContactInfo($addContactInfo)
    {
        $this->db->trans_start();
        $this->db->insert('profile_address', $addContactInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    


    function getUsers($postData){

     $response = array();

     if(isset($postData['search']) ){
       // Select record
       $this->db->select('*');
       $this->db->where("name  LIKE '%".$postData['search']."%' ");

       $records = $this->db->get('profile')->result();

       foreach($records as $row ){
         
          $response[] = array("id"=>$row->id, "label"=> $row->name. ', ' .$row->fathername. ', ' .$row->mothername, 'name'=>$row->name, 'fname'=>$row->fathername, 'image'=>$row->image_name );
       }

     }

     return $response;
  }


  function updateImageInfo($imageInfo, $profileId){
    
     $this->db->where('id', $profileId);
     $this->db->update('profile', $imageInfo);   
     return TRUE; 
  }

}