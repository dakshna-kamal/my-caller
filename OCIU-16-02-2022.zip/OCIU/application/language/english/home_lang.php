<?php
$lang['tele_caller_application'] = 'Tele Caller Application';
?>