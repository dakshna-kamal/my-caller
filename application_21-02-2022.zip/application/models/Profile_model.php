<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Profile_model extends CI_Model
{
    function addNewProfile($profileInfo)
    {
        $this->db->trans_start();
        $this->db->insert('profile', $profileInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    function addContactInfo($addContactInfo)
    {
        $this->db->trans_start();
        $this->db->insert('profile_address', $addContactInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    


    function getUsers($postData){

     $response = array();

     if(isset($postData['search']) ){
       // Select record
       $this->db->select('BaseTbl.id, BaseTbl.name, BaseTbl.fathername, BaseTbl.mothername, BaseTbl.nickname, BaseTbl.number, BaseTbl.age, BaseTbl.a_number, BaseTbl.image_name, Address.birth, Address.street, Address.landmark, Address.area, Address.city, Address.state, Address.pcode');
       $this->db->from('profile as BaseTbl');
       $this->db->join('profile_address as Address', 'Address.profile_id = BaseTbl.id ','inner');
       
       $this->db->where("BaseTbl.name  LIKE '%".$postData['search']."%' ");

       $query = $this->db->get();
       
       $records = $query->result();  

       foreach($records as $row ){
         
          $response[] = array("id"=>$row->id, "label"=> $row->name. ', ' .$row->fathername. ', ' .$row->mothername, 'name'=>$row->name, 'fname'=>$row->fathername, 
          'mname'=>$row->mothername, 'nickname'=>$row->nickname,  'number'=>$row->number,'age'=>$row->age, 'a_number'=>$row->a_number, 'birth'=>$row->birth, 
          'area'=>$row->area, 'city'=>$row->city, 'street'=>$row->street, 'landmark'=>$row->landmark, 'state'=>$row->state, 'pcode'=>$row->pcode, 'image'=>$row->image_name );
       }

     }
  
     return $response;
  }


  function updateImageInfo($imageInfo, $profileId){
    
     $this->db->where('id', $profileId);
     $this->db->update('profile', $imageInfo);   
     return TRUE; 
  }

  function updateProfile($profileInfo, $update){
    
     $this->db->where('id', $update);
     $this->db->update('profile', $profileInfo);   
     return TRUE; 
  }

    function updateContact($contactInfo, $update){
    
     $this->db->where('id', $update);
     $this->db->update('profile_address', $contactInfo);   
     return TRUE; 
  }

  function imageRecords($imageData)
	{
		$this->db->trans_start();
		$this->db->insert_batch("image_details", $imageData);
        
		$this->db->trans_complete();
  }

   function videoRecords($videoData)
    {
        $this->db->trans_start();
        $this->db->insert('video_details', $videoData);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return TRUE;
    }

    function audioRecords($audioData)
    {
        $this->db->trans_start();
        $this->db->insert('audio_details', $audioData);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return TRUE;
    }

    function otherRecords($otherInfo)
    {
        $this->db->trans_start();
        $this->db->insert('other_details', $otherInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return TRUE;
    }

    function getOtherDetails($update){

       $this->db->select('id, vehicle_no, vehicle_info, property_details, property_location, linkwith, profile_id');
       $this->db->from('other_details');
       $this->db->where('profile_id', $update);
       $query = $this->db->get();
       
       $result = $query->result();        
       return $result;
         
    }
    function updateRecords($updateInfo, $updateid){
    
     $this->db->where('id', $updateid);
     $this->db->update('other_details', $updateInfo);   
     return TRUE; 
    }
    





}