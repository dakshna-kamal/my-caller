<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model
{
    function userListingCount($branchId, $role)
    {
        
        $this->db->select('BaseTbl.emp_id, BaseTbl.emp_name,BaseTbl.mobile_num, BaseTbl.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted, BaseTbl.branch_id');
        $this->db->from('cct_emp_details as BaseTbl');
        $this->db->join('cct_roles as Role', 'Role.roleId  = BaseTbl.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id  = BaseTbl.branch_id ','inner');
        $this->db->where('BaseTbl.branch_id', $branchId);
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.role_id', $role);

        if(!empty($branchId)) {
            $likeCriteria = "(BaseTbl.branch_id  LIKE '%".$branchId."%')";
            $this->db->where($likeCriteria);
        }
 
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    function userListing($branchId, $page, $segment, $role)
    {
  
        $this->db->select('BaseTbl.emp_id, BaseTbl.emp_name,BaseTbl.mobile_num, BaseTbl.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted, BaseTbl.branch_id');
        $this->db->from('cct_emp_details as BaseTbl');
        $this->db->join('cct_roles as Role', 'Role.roleId  = BaseTbl.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id  = BaseTbl.branch_id ','inner');
        $this->db->where('BaseTbl.branch_id', $branchId);
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.role_id', $role);
  
        if(!empty($branchId)) {
            $likeCriteria = "(BaseTbl.branch_id  LIKE '%".$branchId."%')";
            $this->db->where($likeCriteria);
        }
      
       
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function searchUsersCount($searchText, $searchOption, $role)
    {
        
        $this->db->select('BaseTbl.emp_id, BaseTbl.emp_name,BaseTbl.mobile_num, BaseTbl.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted, BaseTbl.branch_id');
        $this->db->from('cct_emp_details as BaseTbl');
        $this->db->join('cct_roles as Role', 'Role.roleId  = BaseTbl.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = BaseTbl.branch_id ','inner');
       
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.role_id', $role);

        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
            }
         }
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.emp_name  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }
        }
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.mobile_num  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }
         }
         else if($searchOption == 4){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.gender  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
             }
        }

        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    function searchUsers($searchText, $searchOption, $page, $segment, $role)
    {
  
        $this->db->select('BaseTbl.emp_id, BaseTbl.emp_name,BaseTbl.mobile_num, BaseTbl.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted, BaseTbl.branch_id');
        $this->db->from('cct_emp_details as BaseTbl');
        $this->db->join('cct_roles as Role', 'Role.roleId  = BaseTbl.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = BaseTbl.branch_id ','inner');
       
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.role_id', $role);
  
        if($searchOption == 1){
            if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
            }
         }
        else if($searchOption == 2){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.emp_name  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }
        }
        else if($searchOption == 3){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.mobile_num  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
            }
         }
         else if($searchOption == 4){
            if(!empty($searchText)) {
                $likeCriteria = "(BaseTbl.gender  LIKE '%".$searchText."%')";
                $this->db->where($likeCriteria);
             }
        }

        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    


    function managerListingCount($searchText)
    {
        $this->db->select('BaseTbl.u_id, Emp.emp_id, BaseTbl.username, Emp.emp_name,Emp.mobile_num, Emp.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = BaseTbl.u_id','inner');
        $this->db->join('cct_roles as Role', 'Role.roleId  = Emp.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = Emp.branch_id ','inner');
  
        if(!empty($searchText)) {
            $likeCriteria = "(Emp.emp_name  LIKE '%".$searchText."%'
                            OR  Branches.b_name  LIKE '%".$searchText."%'
                            OR  Emp.mobile_num  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('Emp.role_id ', 2);
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function managerListing($searchText, $page, $segment, $role)
    {

        $this->db->select('BaseTbl.u_id, Emp.emp_id, BaseTbl.username, Emp.emp_name,Emp.mobile_num, Emp.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = BaseTbl.u_id','inner');
        $this->db->join('cct_roles as Role', 'Role.roleId  = Emp.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = Emp.branch_id ','inner');
  
        if(!empty($searchText)) {
            $likeCriteria = "(Emp.emp_name  LIKE '%".$searchText."%'
                            OR  Branches.b_name  LIKE '%".$searchText."%'
                            OR  Emp.mobile_num  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
      
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('Emp.role_id ', 2);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function teleCallerListingCount($searchText, $role, $branchId)
    {
       
        $this->db->select('BaseTbl.u_id, Emp.emp_id, BaseTbl.username, Emp.emp_name,Emp.mobile_num, Emp.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = BaseTbl.u_id','inner');
        $this->db->join('cct_roles as Role', 'Role.roleId  = Emp.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = Emp.branch_id ','inner');

        if(!empty($searchText)) {
            $likeCriteria = "(Emp.emp_name  LIKE '%".$searchText."%'
                            OR  Branches.b_name  LIKE '%".$searchText."%'
                            OR  Emp.mobile_num  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
      
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('Emp.role_id ', 3);

        $this->db->where('Emp.branch_id', $branchId);
        $query = $this->db->get();
        
        return $query->num_rows();
        
        
    }


    function teleCallerListing($searchText, $page, $segment, $role, $branchId)
    {
       
        $this->db->select('BaseTbl.u_id, Emp.emp_id, BaseTbl.username, Emp.emp_name,Emp.mobile_num, Emp.gender, Role.rolename, Branches.b_name, BaseTbl.isDeleted');
        $this->db->from('cct_login as BaseTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = BaseTbl.u_id','inner');
        $this->db->join('cct_roles as Role', 'Role.roleId  = Emp.role_id ','inner');
        $this->db->join('cct_branch_details as Branches', 'Branches.b_id = Emp.branch_id ','inner');

        if(!empty($searchText)) {
            $likeCriteria = "(Emp.emp_name  LIKE '%".$searchText."%'
                            OR  Branches.b_name  LIKE '%".$searchText."%'
                            OR  Emp.mobile_num  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
      
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('Emp.role_id', 3);

        $this->db->where('Emp.branch_id', $branchId);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
        
    }

    function checkManagerList($roleId, $branches)
    {

        $this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id ", $roleId );
        $this->db->where ( "branch_id ", $branches );
		$query = $this->db->get ( "cct_emp_details" );
		
		$result = $query->result();        
        return $query->num_rows();

    }

    


    function branchListingCount($searchText = '')
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BranchTbl.b_name  LIKE '% ".$searchText." %' 
                            OR BranchTbl.b_id LIKE '% ".$searchText."%' )";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

    function branchListing($searchText, $page, $segment)
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        if(!empty($searchText)) {
            $likeCriteria = "(BranchTbl.b_name  LIKE '% ".$searchText." %' 
                            OR BranchTbl.b_id LIKE '% ".$searchText."%' )";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function branchListing1()
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function getUserRoles()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getUserRoles1()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }


    function getUserBranches()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
       
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function userNameCreation()
    {
        $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
        $query = $this->db->query($sql);
        $user = $query->row();
        return $user;
    }


    function getManagerUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );

        $this->db->where ( "role_id ", 2 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getEmployeeUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
        $this->db->where ( "role_id ", 3);
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getTelecallerCount($branchId) {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id", 3 );
        $this->db->where ( "branch_id", $branchId );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}


    function checkEmailExists($email, $userId = 0)
    {
        $this->db->select("email");
        $this->db->from("tbl_users");
        $this->db->where("email", $email);   
        $this->db->where("isDeleted", 0);
        if($userId != 0){
            $this->db->where("userId !=", $userId);
        }
        $query = $this->db->get();

        return $query->result();
    }
    
    function addNewUser($userInfo1)
    {
        $this->db->trans_start();
        $this->db->insert('cct_login', $userInfo1);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function addUserDetails($userInfo2){

        $this->db->trans_start();
        $this->db->insert('cct_emp_details', $userInfo2);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;

    }

    function addNewBranch($branchInfo)
    {
        $this->db->trans_start();
        $this->db->insert('cct_branch_details', $branchInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    

    function getUserInfo($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
		$this->db->where('role_id !=', 1);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getBranchInfo($branchId)
    {
        $this->db->select('b_name, b_address, b_id, b_phonenum');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getBranchName($branchId){
        $this->db->select('b_name');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }
    

    function editUser($userInfo, $userId)
    {
        $this->db->where('emp_id', $userId);
        $this->db->update('cct_emp_details', $userInfo);
        
        return TRUE;
    }

    function updateUserName($userInfo3, $emp_id)
    {
        $this->db->where('u_id', $emp_id);
        $this->db->update('cct_login', $userInfo3);
        
        return TRUE;
    }

    

    function editBranch($branchInfo, $b_Id)
    {
        $this->db->where('b_id', $b_Id);
        $this->db->update('cct_branch_details', $branchInfo);
        
        return TRUE;
    }
    


    function deleteUser($userId, $userInfo)
    {
        $this->db->where('u_id', $userId);
        $this->db->update('cct_login', $userInfo);
        $this->db->where('emp_id', $userId);
        $this->db->update('cct_emp_details', $userInfo);
        
        return $this->db->affected_rows();
    }

    function deleteBranch($b_id, $branchInfo)
    {
        $this->db->where('b_id', $b_id);
        $this->db->update('cct_branch_details', $branchInfo);
        
        return $this->db->affected_rows();
    }

    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('u_id, password');
        $this->db->where('u_id', $userId);        
        $query = $this->db->get('cct_login');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    
    function changePassword($userId, $userInfo)
    {
        $this->db->where('u_id', $userId);
        $this->db->update('cct_login', $userInfo);
        
        return $this->db->affected_rows();
    }


    function loginHistoryCount($userId, $searchText, $fromDate, $toDate)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->from('tbl_last_login as BaseTbl');
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function loginHistory($userId, $searchText, $fromDate, $toDate, $page, $segment)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        $this->db->from('tbl_last_login as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    function getUserInfoById($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    function branchInfo($branchId)
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->row();

    }

    function getAssignedTeleTask($branchId, $date ){
 
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Assigned');
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }
    function getSubmittedTask($branchId, $date){
 
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('call.c_status', 'Submitted');
        $this->db->where('TaskTbl.branch_id', $branchId);
		$where = 'TaskTbl.emp_id IS NULL';
		$this->db->where($where);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }

    function getAssignedTask($branchId, $date){
 
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('call.c_status', 'Assigned');
        $this->db->where('TaskTbl.assigned_date', $date);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }

    function getCompletedTask($branchId, $date){
 
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('call.c_status', 'Call Completed');
        $this->db->where('TaskTbl.completed_date >=', $date);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }

    function getTeleTaskCountToday($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $date);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where( "TaskTbl.isDeleted", 0 );    

		$query = $this->db->get();
		return count ( $query->result () );
        
    }


    function getTeleTaskCount(){
 
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');

        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  

        $this->db->where('call.c_status' , 'Submitted' );
        $this->db->where( "TaskTbl.isDeleted", 0 );
      
		$query = $this->db->get();
		return count ( $query->result () );
        
    }

    function getTeleTaskCompleteToday($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('call.c_status', 'Call Completed');
        $this->db->where('TaskTbl.completed_date >=', $date);
        

        
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }

    
    function getTeleTaskInCompleteToday($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date <', $date);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);

        $this->db->where('Emp.emp_id', $userId);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }


    function getTeleTaskReminderToday($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();

		return count ( $query->result () );
        
    }

    function getTeleTaskReminderSent($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        $myDate = date("Y-m-d H:i:s");
      
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);

        
		$query = $this->db->get();

		return count ( $query->result () );
        
    }


    function getTeleTaskPaymentDetails($branchId, $date, $userId){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'TaskTbl.payment_id  = payment.payment_id ','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();

		return count ( $query->result () );
        
    }

    

    function getTelePaymentAssign($branchId, $date){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'TaskTbl.payment_id  = payment.payment_id ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('payment.isSubmitted' , 0);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
        return count ( $query->result () );
        
    }

    function getTeleTaskPaymentstatus($branchId, $date){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'TaskTbl.payment_id  = payment.payment_id ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
		return count ( $query->result () );
        
    }


    function getAccountPaymentProcess($date){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner'); 
        $this->db->join('payment_details as payment', 'TaskTbl.payment_id  = payment.payment_id ','inner'); 
        $this->db->join('payment_status as status', 'status.p_id  = payment.status_id ','inner'); 
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where('status.p_status' , 'Payment Processed');
        

        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
        return count ( $query->result () );
        
    }  

    function getAccountPaymentStatus($date){
 
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner'); 
        $this->db->join('payment_details as payment', 'TaskTbl.payment_id  = payment.payment_id ','inner');  
        $this->db->join('payment_status as status', 'status.p_id  = payment.status_id ','inner'); 
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
		$query = $this->db->get();
        return count ( $query->result () );
        
    }  

    function getTaskReminderToday($branchId, $date){
 
      
        $this->db->select('TaskTbl.emp_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );
        

        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
       
            $query = $this->db->get();
            return count ( $query->result () );

		
        
        
    }

    function getescalatedTask($date){
               
        $this->db->select('TaskTbl.t_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id  = TaskTbl.call_status ','inner');  
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        $this->db->where('call.c_status', 'Call on date');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
       
            $query = $this->db->get();
            return count ( $query->result () );
        
    }

    
    

}

  