<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Task_model extends CI_Model
{
   
    function taskListing($branchId, $page, $segment)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where( "TaskTbl.isDeleted", 0 );
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');

        if(!empty($branchId)){

            $likeCriteria = "(TaskTbl.branch_id  LIKE '%".$branchId."%')";
            $this->db->where($likeCriteria);
 
        }
                
        $this->db->limit($page, $segment);

        $query = $this->db->get();
        $result = $query->result();   
        return $result;
       
    }

    function taskListingCount($branchId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');
                
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($branchId)){

            $likeCriteria = "(TaskTbl.branch_id  LIKE '%".$branchId."%')";
            $this->db->where($likeCriteria);
           
        }
        
        $query = $this->db->get();  

        return $query->num_rows();
        
    }

    function searchTaskListingCount($searchText)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('call.c_status', 'Submitted');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            
            $likeCriteria = "(TaskTbl.emp_id  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);

        }

        $query = $this->db->get();

        return $query->num_rows();
        
    }

    function searchTaskListing($searchText, $page, $segment)
    {

        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Branch.b_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_branch_details as Branch', 'Branch.b_id = TaskTbl.branch_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->where('call.c_status', 'Submitted');
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $this->db->limit($page, $segment);

        $query = $this->db->get();
        $result = $query->result();   
        return $result;
    }


    function submittedTask($searchText, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');
		$where = 'TaskTbl.emp_id IS NULL';
		$this->db->where($where);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }              
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function submittedTaskCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, call.c_status, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Submitted');
		
		$where = 'TaskTbl.emp_id IS NULL';
		$this->db->where($where);

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
         }
        
      
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }
 
    function assignedTeleTaskCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id,Emp.emp_name, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');    
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Assigned');
		

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
         }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

    function assignedTeleTask($searchText, $page, $segment, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id,Emp.emp_name, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.submitted_date');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');  
        $this->db->where('TaskTbl.branch_id', $branchId);
        $this->db->where('call.c_status', 'Assigned');


        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }
    
    function reminderTaskListingToday($searchText, $page, $segment, $branchId, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        $this->db->where( "TaskTbl.isDeleted", 0 );
       

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
    }



    function reminderTaskListingTodayCount($searchText, $branchId, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status', 'Call on date');
        
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 1 HOUR) <', $myDate);
       
            $query = $this->db->get();
            return $query->num_rows();       
    }


    function escalatedTask($searchText, $page, $segment, $getDate){

        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, b_name, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        $this->db->where('call.c_status', 'Call on date');
       
       $this->db->where( "TaskTbl.isDeleted", 0 );
       

       if(!empty($searchText)) {
        $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
        $this->db->where($likeCriteria);
    }
        
      
        $this->db->limit($page, $segment);
        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
       

    }


    function escalatedTaskCount($searchText, $getDate)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->join('cct_branch_details as branch', 'Emp.branch_id  = branch.b_id ','inner');  
        $this->db->where('call.c_status', 'Call on date');
       
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }

        $myDate = date("Y-m-d H:i:s");
        
        $this->db->where('DATE_ADD(TaskTbl.call_on_date, INTERVAL 2 HOUR) <', $myDate);
        $query = $this->db->get();
        return $query->num_rows();

    }

    function taskTeleListingTodayCount($searchText,$branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where( "TaskTbl.isDeleted", 0 ); 
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $getDate);
        $this->db->where('call.c_status !=', 'Assigned');


        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    function teleTaskListingToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date' , $getDate);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
    
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskListingTodayCount($searchText, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
       
        $this->db->where('TaskTbl.assigned_date' , $getDate);
        $this->db->where('call.c_status', 'Assigned');

        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
        


        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $getDate);
      
        $this->db->where('call.c_status', 'Call Completed');


        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskInCompletedTodayCount($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date', $getDate);
        $where = "call.c_status != 'Call on date' AND  call.c_status !=  'Call Completed' AND  call.c_status != 'Payment Received'  AND  call.c_status != 'Submitted' " ;
        $this->db->where($where);
        $this->db->where( "TaskTbl.isDeleted", 0 );

       if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleTaskInCompletedToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date <', $getDate);
        $where = "call.c_status != 'Call on date' AND call.c_status != 'Call Completed' AND call.c_status != 'Payment Received' AND call.c_status != 'Submitted' " ;
        $this->db->where($where);
        $this->db->where( "TaskTbl.isDeleted", 0 );

       if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function teleTaskPayment($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');

        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }

    function teleTaskPaymentCount($searchText, $branchId, $getDate, $userId)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function telePaymentAssign($searchText, $page, $segment, $branchId, $getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 0);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function telePaymentAssignCount($searchText, $branchId, $getDate)
    {
 
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 0);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }

    function telePaymentStatus($searchText, $page, $segment, $branchId, $getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');

        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function telePaymentStatusCount($searchText, $branchId, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountPaymentProcess($searchText, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountPaymentProcessCount($searchText, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function accountPaymentStatus($searchText, $page, $segment,$getDate)
    {
    
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, status.p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {

            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    
    function accountPaymentStatusCount($searchText, $getDate)
    {
         $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, payment.payment_id, payment.payment_info, payment.payment_date, Emp.emp_id, Emp.emp_name, p_status, payment.remarks');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->join('payment_status as status', 'payment.status_id = status.p_id','inner');
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('status.p_status !=' , 'Payment Processed');
        $this->db->where('payment.isSubmitted' , 1);
      
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        
        $query = $this->db->get();
        
        return $query->num_rows();
        
    }



    function submitVerify($branchId, $getDate)
    {
    
        $this->db->select('payment.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('payment_details as payment', 'payment.payment_id = TaskTbl.payment_id','inner');
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('call.c_status' , 'Payment Received');
        $this->db->where('payment.status_id' , 0);
        $this->db->where( "TaskTbl.isDeleted", 0 );
        
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        
    }




    function teleTaskReminderToday($searchText, $page, $segment, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $myDate = date("Y-m-d H:i:s");
        $this->db->where('call.c_status', 'Call on date');  
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
    
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        
    }


    function taskListingCount1($searchText, $branchId, $getDate, $userId)
    {
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, call.c_status, TaskTbl.assigned_date, TaskTbl.completed_date, TaskTbl.call_on_date, Emp.emp_name');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner');  
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId);
        $this->db->where('TaskTbl.assigned_date ', $getDate);
        $this->db->where( "TaskTbl.isDeleted", 0 );

        if(!empty($searchText)) {
            $likeCriteria = "(TaskTbl.customer_number  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        

        $query = $this->db->get();
        
        return $query->num_rows();
        
    }


    function teleReportRecords($branchId, $userId){

        $select = array(

            //"count(TaskTbl.t_id) as Total",
            "TaskTbl.t_id",
            "call.c_status"
            
        );  
        $this->db->select($select);
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as call', 'call.c_id = TaskTbl.call_status ','inner'); 
        $this->db->join('cct_emp_details as Emp', 'Emp.emp_id = TaskTbl.emp_id','inner');
        $this->db->where('Emp.emp_id', $userId);
        $this->db->where('Emp.branch_id', $branchId); 
        //$this->db->group_by('call.c_status');

        $query = $this->db->get();

        $result = $query->result();        
        return $result;

    }

    

    
    function getUserRoles()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getUserRoles1()
    {
        $this->db->select('roleId, rolename');
        $this->db->from('cct_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }


    function getUserBranches()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
       
        $query = $this->db->get();
        
        return $query->result();
    }
    
    function userNameCreation()
    {
        $sql = 'SELECT u_id FROM cct_login ORDER BY u_id DESC LIMIT 1';
        $query = $this->db->query($sql);
        $user = $query->row();
        return $user;
    }


    function getManagerUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 3 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function getEmployeeUsersCount() {
		$this->db->select ( "emp_id" );
		$this->db->where ( "isDeleted", 0 );
		$this->db->where ( "role_id  !=", 1 );
        $this->db->where ( "role_id  !=", 2 );
		$query = $this->db->get ( "cct_emp_details" );
		
		return count ( $query->result () );
	}

    function checkEmailExists($email, $userId = 0)
    {
        $this->db->select("email");
        $this->db->from("tbl_users");
        $this->db->where("email", $email);   
        $this->db->where("isDeleted", 0);
        if($userId != 0){
            $this->db->where("userId !=", $userId);
        }
        $query = $this->db->get();

        return $query->result();
    }
    
    function addNewTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('cct_task_details', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

   

    function getUserInfo($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
		$this->db->where('role_id !=', 1);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getBranchInfo($branchId)
    {
        $this->db->select('b_name, b_address, b_id, b_phonenum');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo($branchId)
    {
        $this->db->select('emp_id, emp_name');
        $this->db->from('cct_emp_details');
        $this->db->where('role_id !=', 1);
        $this->db->where('role_id !=', 2);
        $this->db->where('isDeleted', 0);
        $this->db->where('branch_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo2($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.emp_id, TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, Emp.emp_name, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('cct_emp_details as Emp', 'TaskTbl.emp_id  = Emp.emp_id ','inner');  
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }


    function getAssignTaskInfo($branchId){
        $this->db->select('t_id, customer_number');
        $this->db->from('cct_task_details');
		$where = 'emp_id IS NULL';
		$this->db->where($where);
		
        $this->db->where('branch_id', $branchId);

             

        $query = $this->db->get();
        
        return $query->result();
    }


    function getTaskAdminInfo($taskId){
        $this->db->select('TaskTbl.t_id,  TaskTbl.customer_number, TaskTbl.call_status, TaskTbl.assigned_date, TaskTbl.branch_id');
        $this->db->from('cct_task_details as TaskTbl');
        
        $this->db->join('cct_branch_details as Branch', 'TaskTbl.branch_id  = Branch.b_id ','inner');    
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }


    function getPaymentInfo($taskId){
        $this->db->select('TaskTbl.t_id,  TaskTbl.customer_number, Call.c_status, Payment.payment_date, Payment.payment_info, Payment.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->join('call_status as Call', 'Call.c_id = TaskTbl.call_status ','inner');  
        $this->db->join('payment_details as Payment', 'Payment.payment_id = TaskTbl.payment_id ','inner');   
 
        $this->db->where('t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }
    
    function getPaymentStatus($p_id){

        $this->db->select('payment_id, payment_date, payment_info, status_id');
        $this->db->from('payment_details');
        $this->db->where('payment_id', $p_id);

        $query = $this->db->get();
        
        return $query->result();
    }

    function getPaymentList(){

        $this->db->select('p_id, p_status');
        $this->db->from('payment_status');
        $query = $this->db->get();
        
        return $query->result();
    }


    function getTaskInfo3($taskId){
        $this->db->select('TaskTbl.t_id, TaskTbl.customer_number, TaskTbl.assigned_date, TaskTbl.call_status, TaskTbl.call_on_date, TaskTbl.payment_id');
        $this->db->from('cct_task_details as TaskTbl');
        $this->db->where('TaskTbl.t_id', $taskId);
       

        $query = $this->db->get();
        
        return $query->result();
    }

    function getTaskInfo4()
    {
        $this->db->select('c_id, c_status');
        $this->db->where('c_status !=', 'Submitted');
        $this->db->where('c_status !=', 'Assigned');
        $this->db->from('call_status');
        $query = $this->db->get();
        
        return $query->result();

    }

    function getTaskInfo5()
    {
        $this->db->select('b_id, b_name');
        $this->db->from('cct_branch_details');
        $query = $this->db->get();
        
        return $query->result();

    }




    function getBranchName($branchId){
        $this->db->select('b_name');
        $this->db->from('cct_branch_details');
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->result();

    }
    
    

    function editUser($userInfo, $userId)
    {
        $this->db->where('emp_id', $userId);
        $this->db->update('cct_emp_details', $userInfo);
        
        return TRUE;
    }

    function editBranch($branchInfo, $b_Id)
    {
        $this->db->where('b_id', $b_Id);
        $this->db->update('cct_branch_details', $branchInfo);
        
        return TRUE;
    }

    function editTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }

    


    function editPaymentStatus($paymentInfo, $p_Id)
    {
        $this->db->where('payment_id', $p_Id);
        $this->db->update('payment_details', $paymentInfo);
        
        return TRUE;
    }


    function editTaskPayment($paymentInfo, $payment_id){
        
        $this->db->where('payment_id', $payment_id);
        $this->db->update('payment_details', $paymentInfo);
        
        return TRUE; 
    }
    

    function editAdminTask($taskInfo, $t_Id)
    {
        $this->db->where('t_id', $t_Id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return TRUE;
    }


    function deleteTask($t_id, $taskInfo)
    {
        $this->db->where('t_id', $t_id);
        $this->db->update('cct_task_details', $taskInfo);
        
        return $this->db->affected_rows();
    }

    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('u_id, password');
        $this->db->where('u_id', $userId);        
        $query = $this->db->get('cct_login');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    
    function changePassword($userId, $userInfo)
    {
        $this->db->where('u_id', $userId);
        $this->db->update('cct_login', $userInfo);
        
        return $this->db->affected_rows();
    }

    function loginHistoryCount($userId, $searchText, $fromDate, $toDate)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->from('tbl_last_login as BaseTbl');
        $query = $this->db->get();
        
        return $query->num_rows();
    }


    function loginHistory($userId, $searchText, $fromDate, $toDate, $page, $segment)
    {
        $this->db->select('BaseTbl.userId, BaseTbl.sessionData, BaseTbl.machineIp, BaseTbl.userAgent, BaseTbl.agentString, BaseTbl.platform, BaseTbl.createdDtm');
        $this->db->from('tbl_last_login as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.email  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if(!empty($fromDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) >= '".date('Y-m-d', strtotime($fromDate))."'";
            $this->db->where($likeCriteria);
        }
        if(!empty($toDate)) {
            $likeCriteria = "DATE_FORMAT(BaseTbl.createdDtm, '%Y-%m-%d' ) <= '".date('Y-m-d', strtotime($toDate))."'";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.userId', $userId);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }


    function getUserInfoById($userId)
    {
        $this->db->select('emp_id, emp_name, mobile_num, gender, role_id, branch_id');
        $this->db->from('cct_emp_details');
        $this->db->where('isDeleted', 0);
        $this->db->where('emp_id', $userId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    function branchInfo($branchId)
    {
        $this->db->select('BranchTbl.b_id, BranchTbl.b_name, BranchTbl.b_address, BranchTbl.b_phonenum');
        $this->db->from('cct_branch_details as BranchTbl');
        $this->db->where ( "isDeleted", 0 );
        $this->db->where('b_id', $branchId);
        $query = $this->db->get();
        
        return $query->row();

    }

    function addPayment($paymentInfo)
    {
        $this->db->trans_start();
        $this->db->insert('payment_details', $paymentInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    

}

  