<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = "login";

$route['volunteer'] = "volunteer";
$route['isVolunteer'] = "volunteer/isVolunteer";
$route['signUp'] = "volunteer/signUp";
$route['insertSignature'] = "volunteer/insertSignature";
$route['otpCheck'] = "volunteer/otpCheck";
$route['verifyOTP1'] = "volunteer/verifyOTP1";
$route['verifyOTP'] = "volunteer/verifyOTP";

$route['deleteVolunteer'] = "volunteer/deleteVolunteer";




$route['volunteerListing'] = "user/volunteerListing";
$route['volunteerListing/(:num)'] = "user/volunteerListing/$1";
$route['viewPdf/(:num)'] = "user/viewPdf/$1";

$route['donor'] = "donor";
$route['isDonor'] = "donor/isDonor";
$route['verifyEmail'] = "donor/verifyEmail";
$route['donorView'] = "donor/donorView";
$route['checkOTP'] = "donor/checkOTP";
$route['checkOTP2'] = "donor/checkOTP2";

$route['donorPdf/(:num)'] = "donor/donorPdf/$1";


$route['404_override'] = 'error';


/*********** USER DEFINED ROUTES *******************/

$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['dashboard1'] = 'user/dashboard1';
$route['logout1'] = 'user/logout1';

$route['userListing'] = 'user/userListing';
$route['userListing/(:num)'] = "user/userListing/$1";

$route['searchUsers'] = 'user/searchUsers';
$route['searchUsers/(:num)'] = "user/searchUsers/$1";

$route['addNew'] = "user/addNew";

$route['managerListing'] = 'user/managerListing';
$route['managerListing/(:num)'] = "user/managerListing/$1";

$route['teleCallerListing'] = "user/teleCallerListing";
$route['teleCallerListing/(:num)'] = "user/teleCallerListing/$1";

$route['addNewUser'] = "user/addNewUser";
$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";
$route['deleteUser'] = "user/deleteUser";

$route['addNewManager'] = "user/addNewManager";
$route['addNewManager1'] = "user/addNewManager1";

$route['editOldManager'] = "user/editOldManager";
$route['editOldManager/(:num)'] = "user/editOldManager/$1";
$route['editManager'] = "user/editManager";

$route['branchListing'] = 'branches/branchListing';
$route['branchListing/(:num)'] = "branches/branchListing/$1";
$route['addNewBranch'] = "branches/addNewBranch";
$route['addingBranches'] = "branches/addingBranches";
$route['editOldBranch'] = "branches/editOldBranch";
$route['editOldBranch/(:num)'] = "branches/editOldBranch/$1";
$route['editBranch'] = "branches/editBranch";
$route['deleteBranch'] = "branches/deleteBranch";
$route['branchDetails'] = 'branches/branchDetails';


$route['taskListing'] = 'task/taskListing';
$route['taskListing/(:num)'] = 'task/taskListing/$1';

$route['taskListing/(:num)/(:num)'] = 'task/taskListing/$1/$1';

$route['addNewTask'] = "task/addNewTask";
$route['addingTasks'] = "task/addingTasks";
$route['editOldTask'] = "task/editOldTask";
$route['editOldTask/(:num)'] = "task/editOldTask/$1";
$route['editTask'] = "task/editTask";
$route['deleteTask'] = "task/deleteTask";
$route['taskDetails'] = 'task/taskDetails';

$route['assignTasks'] = "task/assignTasks";
$route['assigningTasks'] = "task/assigningTasks";


$route['searchTaskListing'] = 'task/searchTaskListing';
$route['searchTaskListing/(:num)'] = 'task/searchTaskListing/$1';




$route['editAdminTask'] = "task/editAdminTask";
$route['editAdminTask/(:num)'] = "task/editAdminTask/$1";

$route['editAdminTask2'] = "task/editAdminTask2";

$route ['assignedTeleTask'] =  'task/assignedTeleTask';
$route['assignedTeleTask/(:num)'] = "task/assignedTeleTask/$1";


$route['submittedTask'] =  'task/submittedTask';
$route['submittedTask/(:num)'] = "task/submittedTask/$1";

$route ['teleTaskListingToday'] =  'task/teleTaskListingToday';
$route['teleTaskListingToday/(:num)'] = "task/teleTaskListingToday/$1";


$route ['chartView'] =  'task/chartView ';




$route['reminderTaskListingToday'] =  "task/reminderTaskListingToday";
$route['reminderTaskListingToday/(:num)'] = "task/reminderTaskListingToday/$1";

$route['escalatedTask'] =  "task/escalatedTask";
$route['escalatedTask/(:num)'] = "task/escalatedTask/$1";


$route['editOldCallTask'] = 'task/editOldCallTask';
$route['editOldCallTask/(:num)'] = "task/editOldCallTask/$1";
$route['editTeleCallTask'] =  "task/editTeleCallTask";

$route['editOldPaymentstatus'] = 'task/editOldPaymentstatus';
$route['editOldPaymentstatus/(:num)'] = "task/editOldPaymentstatus/$1";
$route['editPaymentstatus'] =  "task/editPaymentstatus";    


$route['teleTaskCompletedToday'] =  "task/teleTaskCompletedToday";
$route['teleTaskCompletedToday/(:num)'] = "task/teleTaskCompletedToday/$1";

$route['telePendingTask'] =  "task/telePendingTask";
$route['telePendingTask/(:num)'] = "task/telePendingTask/$1";

$route['teleTaskReminderToday'] =  "task/teleTaskReminderToday";
$route['teleTaskReminderToday/(:num)'] = "task/teleTaskReminderToday/$1";


$route['teleTaskPayment'] =  "task/teleTaskPayment";
$route['teleTaskPayment/(:num)'] = "task/teleTaskPayment/$1";

$route['editTaskPayment'] =  "task/editTaskPayment";
$route['editTaskPayment/(:num)'] = "task/editTaskPayment/$1";

$route['editTaskPayment2'] =  "task/editTaskPayment2";


$route['telePaymentAssign'] =  "task/telePaymentAssign";
$route['telePaymentAssign/(:num)'] = "task/telePaymentAssign/$1";

$route['telePaymentStatus'] =  "task/telePaymentStatus";
$route['telePaymentStatus/(:num)'] = "task/telePaymentStatus/$1";

$route['accountPaymentProcess'] =  "task/accountPaymentProcess";
$route['accountPaymentProcess/(:num)'] = "task/accountPaymentProcess/$1";

$route['accountPaymentStatus'] =  "task/accountPaymentStatus";
$route['accountPaymentStatus/(:num)'] = "task/accountPaymentStatus/$1";



$route['submitVerify'] =  "task/submitVerify";


$route['teleTaskReports'] =  "task/teleTaskReports";
$route['teleTaskReports/(:num)'] = "task/teleTaskReports/$1";







$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkEmailExists'] = "user/checkEmailExists";
$route['login-history'] = "user/loginHistoy";
$route['login-history/(:num)'] = "user/loginHistoy/$1";
$route['login-history/(:num)/(:num)'] = "user/loginHistoy/$1/$2";

$route['forgotPassword'] = "login/forgotPassword";

$route['changePassword1'] = "login/changePassword1";
$route['loadChangePass1'] = "login/loadChangePass1";

$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";

$route ['import'] = "import/index";
$route ['import/(:num)'] = "import/index/$1";

$route ['uploadUserData'] = "import/uploadUserData";


$route ['importExcel'] = "import/importExcel";
$route ['importUserExcel'] = "import/importUserExcel";

$route ['importManagerExcel'] = "import/importManagerExcel";
$route ['uploadManagerData'] = "import/uploadManagerData";

$route ['importTaskExcel'] = "import/importTaskExcel";
$route ['importTaskExcel2'] = "import/importTaskExcel2";
$route ['uploadTaskData'] = "import/uploadTaskData";

$route ['importBranchTask'] = "import/importBranchTask";
$route ['uploadTaskData2'] = "import/uploadTaskData2";
