<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Donor extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    //var $email;
     public function __construct()
    {
        parent::__construct();
        $this->load->model('donor_model');
        date_default_timezone_set('asia/kolkata');    
    }

    /**
     * Index Page for this controller.
     */
    public function index()
    {
        $this->load->view('donor');
        
       
        //global $res;
    }

    function isDonor(){

        $this->load->library('form_validation');
        $this->load->library('session');
        $this->form_validation->set_rules('email', 'Email', 'required|max_length[60]');

        //global $email;
        $email= $this->security->xss_clean($this->input->post('email'));
        
       

        $result = $this->donor_model->checkEmailExist($email);
        

  
        if(!empty($result))
        {
        
            $sessionArray2 = array('donorEmail'=>$email,                    
                                    'd_id'=>$result->id,
                                    'fname'=>$result->fname
           
            );
        
            $this->session->set_userdata($sessionArray2);     
            redirect('verifyEmail');
               
        }

        else{

            $this->session->set_flashdata('error', 'Your Email id is not in our Database!');
            redirect('donor');
            session_destroy();
        }    

    }

    function verifyEmail(){

        

        $donorEmail = $this->session->donorEmail;
        $donorId = $this->session->d_id;
        $donorName = $this->session->fname;

        $result = $this->donor_model->sendEmail2($donorEmail, $donorId, $donorName);

        if($result > 0){

            redirect('checkOTP');
        }
        else{

        }
       
        
    }

    function checkOTP(){

        $this->load->view('verifyEmail');
    }
      

    function checkOTP2(){
        
        $OTP =  $_POST['OTP'];
        $donorId = $this->session->d_id;;

        $result = $this->donor_model->checkOTP($donorId, $OTP);

        if($result == TRUE){

           
            redirect('donorView'); 
            
            
            
        }
        else{
            $this->session->set_flashdata('error', 'Enter Valid OTP number!');
            redirect('checkOTP');
            
        }
        
        

    }

    function donorView(){

        $donorId = $this->session->d_id;
        $data['donorList'] = $this->donor_model->donationListing($donorId);
        //$this->global['pageTitle'] = 'CCT : Donation Listing';
        $this->load->view('donorView', $data, NULL);

    }

    function donorPdf($id = NULL)
	{
            $this->load->library('pdf');
			//header('Content-type : image/png');
			
			$html_content = "<div><br><h1 align='center'>Volunteer Agreement Details</h2>
            <p>This Volunteer Agreement is a description of the arrangement between us, (AnyOrg), and you (the volunteer) in relation to your voluntary work.  The intention of this agreement is to assure you that we appreciate your volunteering with us and to indicate our commitment to do the best we can to make your volunteer experience with us a positive and rewarding one.<p>
            <h2 align='center'>Part 1 AnyOrg</h2>
            <p>We, AnyOrg, accept the voluntary service of (name of volunteer) beginning (date).</p>
            <p>Your role as a volunteer is (state nature and components of the work).  This work is designed to (state purpose of work in relation to its benefit to the organisation).</p>
            <p>We commit to the following:</p>
            
            <p><b>1. Induction and training</b></p>
            <ul><li>To provide thorough induction on the work of AnyOrg, its staff, your volunteering role and the training necessary to assist you in meeting the responsibilities of your volunteering role, The Volunteers Handbook provides full details of the organisation.
            </li></ul>

            <p><b>2. Supervision, support and flexibility</b></p>
            <ul><li>To define appropriate standards of our services, to communicate them to you, and to encourage and support you to achieve and maintain them as part of your voluntary work
            </li><li>To provide a personal supervisor who will meet with you regularly to discuss your volunteering and any associated problems</li></ul>
            

            <div>";
			$html_content .= $this->donor_model->donorPdf($id);
            $this->pdf->setPaper('A4', 'portrait');
			$this->pdf->loadHtml($html_content);
			$this->pdf->render();
			$this->pdf->stream("".$id.".pdf", array("Attachment"=>0));
		
	}

    


    

    

    
}

?>